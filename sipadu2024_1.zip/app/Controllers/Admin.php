<?php
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\UserModel;
use App\Models\PimpinanModel;
use App\Models\PimpinanAcModel;
use App\Models\PimpinanRkModel;
use App\Models\AnggotaModel;
use App\Models\KeuanganModel;
use App\Models\SuratMasukModel;
use App\Models\SuratKeluarModel;
use App\Models\InventarisBarangModel;
use App\Models\PengaturanPimpinanModel;
use App\Models\DaftarKegiatanModel;
use App\Models\DataPendaftarModel;
use App\Models\PerpustakaanModel;

class Admin extends Controller
{
    public function logout()
    {
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }
        // Hapus data sesi yang menandakan pengguna sudah login
        $session = session();
        $session->destroy();

        // Redirect ke halaman utama setelah logout
        return redirect()->to('/');
    }

    public function about()
    {
        $session = session();

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        return view('template/headerTemplate', $data) .
            view('home/about') .
            view('template/footerTemplate');
    }

    public function dashboard()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['kec'] = $session->get('kec');
        $kec = $data['kec'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        //$data['kec'] = $userModel->where('kategori_user', $kat)->get()->getResultArray();
        //$kec = $data['kec'];


        // Hitung jumlah anggota
        $anggotaModel = new AnggotaModel();
        $data['anggota'] = $anggotaModel->where('kategori_data', $kat)->countAllResults();
        $data['anggotapc'] = $anggotaModel->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->whereNotIn('aktif_kepengurusan', ['PW'])->countAllResults();
        

        // Hitung jumlah anggota yang belum diverifikasi
        $data['belumverifikasi'] = $anggotaModel->where('kategori_data', $kat)->where('status_verifikasi', 'belum')->countAllResults();
        $data['belumverifikasipc'] = $anggotaModel->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->where('status_verifikasi', 'belum')->countAllResults();

        // Hitung jumlah pimpinan
        $pimpinanCount = $pimpinanModel->where('pimpinan', 'PC')->where('kategori_data', $kat)->countAllResults();
        $data['pc'] = $pimpinanCount;

        // Data PAC
        $pimpinanAcModel = new PimpinanAcModel();
        $pimpinanAcCount = $pimpinanAcModel->where('id_pimpinan', $pimp)->where('pimpinan_ac', 'PAC')->where('status_aktif', 'Aktif')->where('kategori_data', $kat)->countAllResults();
        $data['pac'] = $pimpinanAcCount;

        $data['id_pimpinan_ac'] = $session->get('id_pimpinan_ac');
        $pimp_ac = $data['id_pimpinan_ac'];


        $data['id_pimpinan_ac'] = $session->get('id_pimpinan_ac');
        $pimp5 = $data['id_pimpinan_ac'];
        $data['anggotapac'] = $anggotaModel->where('id_pimpinan_ac', $pimp)->where('kategori_data', $kat)->whereNotIn('aktif_kepengurusan', ['PW'])->countAllResults();
        $data['pimpinan_defaultpac'] = $pimpinanAcModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanAcCount = $pimpinanAcModel->where('id_pimpinan', $pimp)->where('pimpinan_ac', 'PAC')->where('kategori_data', $kat)->countAllResults();
        $data['paca'] = $pimpinanAcCount;

        $data['id_pimpinan_ac'] = $session->get('id_pimpinan_ac');
        $pimp1 = $data['id_pimpinan_ac'];

        // Data Ranting dan Komisariat
        $pimpinanRkModel = new PimpinanRkModel();

        $data['pimpinan_defaultrk'] = $pimpinanRkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanRkCount = $pimpinanRkModel->where('id_pimpinan', $pimp)->where('pimpinan_rk', 'PR')->where('status_aktif', 'Aktif')->where('kategori_data', $kat)->countAllResults();
        $data['pr'] = $pimpinanRkCount;

        $pimpinanRkCount = $pimpinanRkModel->where('id_pimpinan_ac', $pimp)->where('pimpinan_rk', 'PR')->where('status_aktif', 'Aktif')->where('kategori_data', $kat)->countAllResults();
        $data['prpr'] = $pimpinanRkCount;

        $data['id_pimpinan_rk'] = $session->get('id_pimpinan_rk');
        $pimprk = $data['id_pimpinan_rk'];

        $pimpinanRkCount = $pimpinanRkModel->where('id_pimpinan', $pimp)->where('pimpinan_rk', 'PR')->where('kategori_data', $kat)->countAllResults();
        $data['pra'] = $pimpinanRkCount;

        $pimpinanRkCount = $pimpinanRkModel->where('id_pimpinan_ac', $pimp)->where('pimpinan_rk', 'PR')->where('kategori_data', $kat)->countAllResults();
        $data['prapr'] = $pimpinanRkCount;

        $pimpinanRkCount = $pimpinanRkModel->where('id_pimpinan', $pimp)->where('pimpinan_rk', 'PK')->where('status_aktif', 'Aktif')->where('kategori_data', $kat)->countAllResults();
        $data['pk'] = $pimpinanRkCount;

        $pimpinanRkCount = $pimpinanRkModel->where('id_pimpinan_ac', $pimp)->where('pimpinan_rk', 'PK')->where('status_aktif', 'Aktif')->where('kategori_data', $kat)->countAllResults();
        $data['pkpk'] = $pimpinanRkCount;

        $pimpinanRkCount = $pimpinanRkModel->where('id_pimpinan', $pimp)->where('pimpinan_rk', 'PK')->where('kategori_data', $kat)->countAllResults();
        $data['pka'] = $pimpinanRkCount;

        $pimpinanRkCount = $pimpinanRkModel->where('id_pimpinan_ac', $pimp)->where('pimpinan_rk', 'PK')->where('kategori_data', $kat)->countAllResults();
        $data['pkapk'] = $pimpinanRkCount;

        // Hitung jumlah keuangan
        // $keuanganModel = new KeuanganModel();

        // // Memanggil method untuk menghitung total masuk dan keluar dari model
        // $totalMasuk = $keuanganModel->selectSum('masuk')->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->first();
        // $totalKeluar = $keuanganModel->selectSum('keluar')->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->first();

        // //$totalMasuk = isset($totalMasukResult['masuk']) ? $totalMasukResult['masuk'] : 0;
        // //$totalKeluar = isset($totalKeluarResult['keluar']) ? $totalKeluarResult['keluar'] : 0;

        // //$selisih = $totalMasuk - $totalKeluar;

        // // Menggabungkan total masuk, total keluar, dan selisih ke dalam satu array
        // $data['keuangan'] = ['masuk' => $totalMasuk, 'keluar' => $totalKeluar];


        //


        $keuanganModel = new KeuanganModel();

        // $data['keuangan'] = $keuanganModel->where('id_pimpinan', $pimp)
        //                                     ->where('kategori_data', $kat)
        //                                     ->orderBy('tanggal_transaksi')
        //                                     ->findAll();

        $masuk = $keuanganModel->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->selectSum('masuk')->first();
        $data['masuk'] = $masuk['masuk'];

        $keluar = $keuanganModel->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->selectSum('keluar')->first();
        $data['keluar'] = $keluar['keluar'];


        //$keuanganModel = new KeuanganModel();

        //$pimp = session('id_pimpinan');
        //$kat = session('kategori');


        //$totalMasuk = $keuanganModel->getTotalMasuk($pimp, $kat);
        //$totalKeluar = $keuanganModel->getTotalKeluar($pimp, $kat);

        //$saldo = $totalMasuk - $totalKeluar;

        // Hitung jumlah surat masuk
        $suratMasukModel = new SuratMasukModel();
        $data['sm'] = $suratMasukModel->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->countAllResults();

        if ($lev === 'superuser') {
            return view('template/headerTemplate', $data) .
            view('home/dashboard') .
            view('template/footerTemplate');
        } elseif ($lev === 'user') {
            return view('template/headerUser', $data) .
            view('operator/dashboard') .
            view('template/footerUser');
        } elseif ($lev === 'userpac') {
            return view('template/headerUser', $data) .
            view('operator/dashboard1') .
            view('template/footerUser');
        } elseif ($lev === 'ranting') {
            return view('template/headerKelurahan', $data) .
            view('desa/dashboard') .
            view('template/footerKelurahan');
        } else {
            // Jika status akun tidak valid, mungkin redirect ke halaman error atau tampilkan pesan kesalahan
            return 'Invalid role';
        }

        // return view('template/headerTemplate', $data) .
        //     view('home/dashboard') .
        //     view('template/footerTemplate');
    }

    public function anggotapw()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $anggotaModel = new AnggotaModel();
        $data['anggota'] = $anggotaModel->join('pimpinan', 'anggota.id_pimpinan = pimpinan.id_pimpinan')->where('anggota.kategori_data', $kat)->whereNotIn('status_alumni', ['ya'])->orderBy('id_anggota')->findAll();
        $anggota = $data['anggota'];

        return view('template/headerTemplate', $data) .
            view('home/anggotapw') .
            view('template/footerTemplate');

    }
    
    public function verifikasianggota()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $anggotaModel = new AnggotaModel();
        $data['anggota'] = $anggotaModel->join('pimpinan', 'anggota.id_pimpinan = pimpinan.id_pimpinan')->where('anggota.kategori_data', $kat)->where('status_verifikasi', 'belum')->orderBy('id_anggota')->findAll();
        $anggota = $data['anggota'];

        return view('template/headerTemplate', $data) .
            view('home/verifikasianggota') .
            view('template/footerTemplate');
        
    }

    public function editverifikasianggota()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        $id_anggota = $this->request->getPost('id');
        $state = [
              'status_verifikasi' => 'sudah'
        ];

        $model = new AnggotaModel();
        $model->update($id_anggota, $state);


    //     $email = $this->request->getGet('email');
    //     $nia = $this->request->getGet('nia');
    //     $nama = $this->request->getGet('nama');
    //     $password = $this->request->getGet('password');
    //     $emailConfig = [
    //       'protocol' =>'smtp',
    //       'smtp_host' =>'ssl://mail.sipadu.or.id',
    //       'smtp_port' => 465,
    //       'smtp_user' =>'admin@sipadu.or.id',
    //       'smtp_pass' =>'@ipnu2022',
    //       'mailtype' =>'html',
    //       'charset' =>'iso-8859-1'
    //     ];
    //     $email = \Config\Services::email();
    //     $email->initialize($emailConfig);

    //     $email->setFrom('admin@sipadu.or.id', 'SIPADU APP');
    //     $email->setTo($email);
    //     $email->setSubject('Pemberitahuan');

    //     // $this->load->library('email', $config);
    //     // $this->email->initialize($config);
    //     // $this->email->set_newline("\r\n");
    //     // $this->email->from('admin@sipadu.or.id', 'SIPADU APP');
    //     // $this->email->to($email);
    //     //$this->email->cc('ipnujawatengah@gmail.com');
    //    // $this->email->subject('Pemberitahuan');

    //     $message = '
    //     <div align="justify" style="color:#7f8c8d;">
    //     <h1>Halo '.$nama.'!</h1>
    //     <h3>Anda sudah terdaftar di SIPADU APP</h3>
    //     <br/>
    //     <br/>
    //     <img src="https://sipadu.or.id/sipadu-template/assets/img/responsive-device.png"/>
    //     <br/>
    //     <br/>
    //     Selamat datang di Sistem Informasi Pelajar dan Administrasi Terpadu (SIPADU) PW IPNU & IPPNU Provinsi Jawa Tengah.
    //     <br/> 
    //     Melalui email ini, kami menginformasikan terkait <b>Data Diri Anda</b> yang sudah terdaftar dan terverifikasi sebagai Anggota di
    //     <b>Sistem Informasi Pelajar dan Administrasi Terpadu (SIPADU)
    //     </b>.
    //     <br/>
    //     <br/>
    //     Untuk mengupdate data diri anda, silakan mengunjungi
    //     Aplikasi SIPADU atau melalui link berikut ini:</div> 
    //     <br/> 
    //     <br/>
    //     <div align="center"><a style="background:#3498db;color:#fff;padding:15px;padding-left:20px;padding-right:20px;border-radius:9px;" href="https://sipadu.or.id">Login Disini</a></div>
    //     <br/>
    //     <br/>
    //     <br/>
    //     Akses Masuk Anda :
    //     <br/>
    //     <i>(Informasi ini Bersifat Rahasia)</i>
    //     <br/>
    //     <br/>
    //     <table>
    //     <tr>
    //     <td>Username</td> <td>:</td> <td>' .$nia. '</td>
    //     </tr>
    //     <tr>
    //     <td>Password</td> <td>:</td> <td> sipaduipnujateng <td>
    //     </tr>
    //     </table> 
    //     <br/> 
    //     Keterangan : Password dibuat otomatis oleh sistem, silakan diubah!
    //     <br/>
    //     <br/>
    //     <div style="color:#7f8c8d;">Jika anda mengalami kendala dalam akses, dapat menghubungi Tim Database Cabang atau Anak Cabang di wilayah anda.
    //     <br/> 
    //     <br/>
    //     Terimakasih
    //     <br/>
    //     <br/>Tim Database Wilayah
    //     <br/>
    //     <br/>
    //     <img src="https://sipadu.or.id/sipadu-template/assets/img/logo-login.png" width="300px"/>
    //     <br/> 
    //     <br/>
    //     Jl. Dr. Cipto No.180 Kota Semarang<br/>admin@sipadu.or.id
    //     <br/>
    //     <a href="https://api.whatsapp.com/send?phone=6285174261954">+62 851-7426-1954</a>
    //     </div>';

    //     $email->setMessage($message);

    //     if (!$email->send()) {
    //         echo $email->printDebugger(['headers']);
    //     }

        // $this->session->setFlashdata('flash', 'Diedit');
        return redirect()->to('admin/verifikasianggota');

        
        // $this->email->send();

        // $this->session->set_flashdata('flash', 'Diedit');
        // redirect('admin/verifikasianggota');
    }
    
    public function penguruspw()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $anggotaModel = new AnggotaModel();
        $data['anggota'] = $anggotaModel->join('pimpinan', 'anggota.id_pimpinan = pimpinan.id_pimpinan')->where('anggota.kategori_data', $kat)->orderBy('id_anggota')->where('aktif_kepengurusan', 'PW')->findAll();
        $anggota = $data['anggota'];

        return view('template/headerTemplate', $data) .
            view('home/penguruspw') .
            view('template/footerTemplate');
    }
    
    public function anggotapc()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['cabang'] = $pimpinanModel->where('kategori_data', $kat)->where('pimpinan', 'PC')->orderBy('kd_pimpinan')->get()->getResultArray();
        $cabang = $data['cabang'];

        $data['get_pc'] = $pimpinanModel->where('id_pimpinan', $this->request->getGet('id'))->get()->getRowArray();
        $get_pc = $data['get_pc'];

        $anggotaModel = new AnggotaModel();
        $data['anggota'] = $anggotaModel->select('*')->join('pimpinan_ac', 'id_pimpinan_ac')->where('anggota.id_pimpinan', $this->request->getGet('id'))->orderBy('id_anggota')->whereNotIn('aktif_kepengurusan', ['PW'])->get()->getResultArray();
        $anggota = $data['anggota'];

        return view('template/headerTemplate', $data) .
            view('home/anggotapc') .
            view('template/footerTemplate');
    }
    
    public function anggotapac()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['cabang'] = $pimpinanModel->where('kategori_data', $kat)->where('pimpinan', 'PC')->orderBy('kd_pimpinan')->get()->getResultArray();
        $cabang = $data['cabang'];

        $pimpinanAcModel = new PimpinanAcModel();
        $data['kecamatan'] = $pimpinanAcModel->where('kategori_data', $kat)->where('pimpinan_ac', 'PAC')->orderBy('kd_pimpinan_ac')->findAll();
        $kecamatan = $data['kecamatan'];

        $pac = $this->request->getGet('id2');

        $data['ac'] = $pimpinanAcModel->where('id_pimpinan_ac', $pac)->first();

        $data['get_pc'] = $pimpinanModel->where('id_pimpinan', $this->request->getGet('id'))->get()->getRowArray();
        $get_pc = $data['get_pc'];

        $data['get_pac'] = $pimpinanAcModel->where('id_pimpinan_ac', $this->request->getGet('id2'))->get()->getRowArray();
        $get_pac = $data['get_pac'];


        $anggotaModel = new AnggotaModel();
        $data['anggota'] = $anggotaModel->select('*')->join('pimpinan_ac', 'id_pimpinan_ac')->where('anggota.id_pimpinan', $this->request->getGet('id'))->where('anggota.id_pimpinan_ac', $this->request->getGet('id2'))->orderBy('id_anggota')->whereNotIn('aktif_kepengurusan', ['PW'])->get()->getResultArray();
        $anggota = $data['anggota'];

        return view('template/headerTemplate', $data) .
            view('home/anggotapac') .
            view('template/footerTemplate');
    }

    public function anggotapr()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['cabang'] = $pimpinanModel->where('kategori_data', $kat)->where('pimpinan', 'PC')->orderBy('kd_pimpinan')->get()->getResultArray();
        $cabang = $data['cabang'];

        $pimpinanAcModel = new PimpinanAcModel();
        $data['kecamatan'] = $pimpinanAcModel->where('kategori_data', $kat)->where('pimpinan_ac', 'PAC')->orderBy('kd_pimpinan_ac')->findAll();
        $kecamatan = $data['kecamatan'];

        $pac = $this->request->getGet('id2');

        $data['ac'] = $pimpinanAcModel->where('id_pimpinan_ac', $pac)->first();

        $data['get_pc'] = $pimpinanModel->where('id_pimpinan', $this->request->getGet('id'))->get()->getRowArray();
        $get_pc = $data['get_pc'];

        $data['get_pac'] = $pimpinanAcModel->where('id_pimpinan_ac', $this->request->getGet('id2'))->get()->getRowArray();
        $get_pac = $data['get_pac'];

        $pimpinanRkModel = new PimpinanRkModel();
        $data['pr'] = $pimpinanRkModel->where('kategori_data', $kat)->where('pimpinan_rk', 'PR')->orderBy('kd_pimpinan_rk')->findAll();
        $pr = $data['pr'];

        $data['get_pr'] = $pimpinanRkModel->where('id_pimpinan_rk', $this->request->getGet('id3'))->get()->getRowArray();
        $get_pr = $data['get_pr'];

        $anggotaModel = new AnggotaModel();
        $data['anggota'] = $anggotaModel->select('*')->join('pimpinan_ac', 'id_pimpinan_ac')->join('pimpinan_rk', 'id_pimpinan_rk')->where('anggota.id_pimpinan', $this->request->getGet('id'))->where('anggota.id_pimpinan_ac', $this->request->getGet('id2'))->where('anggota.id_pimpinan_rk', $this->request->getGet('id3'))->orderBy('id_anggota')->whereNotIn('aktif_kepengurusan', ['PW'])->get()->getResultArray();
        $anggota = $data['anggota'];

        return view('template/headerTemplate', $data) .
            view('home/anggotapr') .
            view('template/footerTemplate');
    }

    public function anggotapk()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['cabang'] = $pimpinanModel->where('kategori_data', $kat)->where('pimpinan', 'PC')->orderBy('kd_pimpinan')->get()->getResultArray();
        $cabang = $data['cabang'];

        $pimpinanAcModel = new PimpinanAcModel();
        $data['kecamatan'] = $pimpinanAcModel->where('kategori_data', $kat)->where('pimpinan_ac', 'PAC')->orderBy('kd_pimpinan_ac')->findAll();
        $kecamatan = $data['kecamatan'];

        $pac = $this->request->getGet('id2');

        $data['ac'] = $pimpinanAcModel->where('id_pimpinan_ac', $pac)->first();

        $data['get_pc'] = $pimpinanModel->where('id_pimpinan', $this->request->getGet('id'))->get()->getRowArray();
        $get_pc = $data['get_pc'];

        $data['get_pac'] = $pimpinanAcModel->where('id_pimpinan_ac', $this->request->getGet('id2'))->get()->getRowArray();
        $get_pac = $data['get_pac'];

        $pimpinanRkModel = new PimpinanRkModel();
        $data['pk'] = $pimpinanRkModel->where('kategori_data', $kat)->where('pimpinan_rk', 'PK')->orderBy('kd_pimpinan_rk')->findAll();
        $pk = $data['pk'];

        $data['get_pk'] = $pimpinanRkModel->where('id_pimpinan_rk', $this->request->getGet('id3'))->get()->getRowArray();
        $get_pk = $data['get_pk'];

        $anggotaModel = new AnggotaModel();
        $data['anggota'] = $anggotaModel->select('*')->join('pimpinan_ac', 'id_pimpinan_ac')->join('pimpinan_rk', 'id_pimpinan_rk')->where('anggota.id_pimpinan', $this->request->getGet('id'))->where('anggota.id_pimpinan_ac', $this->request->getGet('id2'))->where('anggota.id_pimpinan_rk', $this->request->getGet('id3'))->orderBy('id_anggota')->whereNotIn('aktif_kepengurusan', ['PW'])->get()->getResultArray();
        $anggota = $data['anggota'];

        return view('template/headerTemplate', $data) .
            view('home/anggotapk') .
            view('template/footerTemplate');
    }

    public function inanggota()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['cabang'] = $pimpinanModel->where('kategori_data', $kat)->where('pimpinan', 'PC')->orderBy('kd_pimpinan')->get()->getResultArray();
        $cabang = $data['cabang'];

        //$data['cabang'] = $pimpinanModel->where('id_pimpinan', $ket)->where('kategori_data', $kat)->where('pimpinan', 'PC')->orderBy('kd_pimpinan')->get()->getResultArray();
       // $cabang = $data['cabang'];

        $pimpinanAcModel = new PimpinanAcModel();
        $data['kecamatan'] = $pimpinanAcModel->where('kategori_data', $kat)->where('pimpinan_ac', 'PAC')->orderBy('kd_pimpinan_ac')->findAll();
        $kecamatan = $data['kecamatan'];

        $pimpinanRkModel = new PimpinanRkModel();
        $data['ranting'] = $pimpinanRkModel->where('kategori_data', $kat)->orderBy('nama_pimpinan_rk')->findAll();
        $pk = $data['ranting'];

        $anggotaModel = new AnggotaModel();
        //$data['anggota'] = $anggotaModel->select('*')->join('pimpinan_ac', 'id_pimpinan_ac')->join('pimpinan_rk', 'id_pimpinan_rk')->where('anggota.id_pimpinan', $this->request->getGet('id'))->where('anggota.id_pimpinan_ac', $this->request->getGet('id2'))->where('anggota.id_pimpinan_rk', $this->request->getGet('id3'))->orderBy('id_anggota')->whereNotIn('aktif_kepengurusan', ['PW'])->get()->getResultArray();
        //$anggota = $data['anggota'];
        $data['anggota'] = $anggotaModel->where('kategori_data', $kat)->countAllResults();

        $id = $this->request->getGet('id'); // Menggunakan $this->request untuk mengakses data yang dikirimkan melalui request

        $jumlah = $anggotaModel->where('id_pimpinan', $id)->countAllResults(); // Menggunakan model untuk melakukan query


        return view('template/headerTemplate', $data) .
            view('home/inanggota') .
            view('template/footerTemplate');
    }

    public function getByPimpinanRkId($id)
    {
        return $this->where('id_pimpinan_rk', $id)->first(); // Use first() instead of get()
    }

    public function addanggota()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }
        $this->pimpinanRkModel = new PimpinanRkModel();
        $request = service('request');
        $id = $request->getGet('id');
        $model = new AnggotaModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];
        $pimpinanRkModel = new PimpinanRkModel();
        $data['pimpinanRkModel'] = $pimpinanRkModel->where('kategori_data', $kat)->orderBy('nama_pimpinan_rk')->findAll();
        $pimpinanRkModel = $data['pimpinanRkModel'];
        

        $validationRules = [
            'nik' => 'is_unique[anggota.nik]',
            'email' => 'is_unique[anggota.email]'
        ];

        // Validasi input
        if (!$this->validate($validationRules)) {
            $idPimpinan = $request->getPost('id_pimpinan');
            $idPimpinanAc = $request->getPost('id_pimpinan_ac');
            $session = \Config\Services::session();


            //$this->session->setFlashdata('flash', 'Terpakai');
            //$this->session->setFlashdata('pesan', 'Data Telah Digunakan');
            //$pesan = $this->session->getFlashdata('pesan');

           // $this->session->setFlashdata('pesan', 'Data Telah Digunakan');

                return redirect()->to('admin/inanggota?id=' . $idPimpinan);
        } else {
            // Lakukan proses insert data anggota
            $idPimpinan = $request->getPost('id_pimpinan');
            $data['jumlah'] = $model->where('id_pimpinan', $idPimpinan)->countAllResults();

            $jumlah = $data['jumlah'];
            $nia = $jumlah + 1;
            $niaurut = str_pad($nia, 5, "0", STR_PAD_LEFT);

            $pw = $this->request->getPost('pw');

            // $rkpost = $this->request->getPost('id_pimpinan_rk');
            // $A = $pimpinanRkModel->getByPimpinanRkId($rkpost);
            // $idP1 = $A['kd_pimpinan_rk'];

            // $acpost = $this->request->getPost('id_pimpinan_ac');
            // $B = $this->db->table('pimpinan_ac')->where('id_pimpinan_ac', $acpost)->get()->getRowArray();
            // $idP2 = $B['kd_pimpinan_ac'];

            $pcpost = $this->request->getPost('id_pimpinan');

            // Mengakses data dari tabel pimpinan menggunakan model
            $pimpinanModel = new PimpinanModel();
            $C = $pimpinanModel->where('id_pimpinan', $pcpost)->first();

            // Mendapatkan kd_pimpinan dari hasil query
            $pc = $C['kd_pimpinan'];


            $tgl_masuk = $this->request->getPost('tanggal_masuk');
            $th = substr($tgl_masuk, 2, 2);

            $tgl_lahir = $this->request->getPost('tanggal_lahir');
            $th_lahir = substr($tgl_lahir, 2, 2);

            $nia_jadi = $pw . '.' . $pc . '.' . $th_lahir . '.' . $niaurut;

            // $upload = $this->request->getFile('foto');
            // if ($upload->isValid() && !$upload->hasMoved()) {
            //     $upload->move('./upload/anggota/');
            //     $name = $upload->getName();
            // }

            //$datanonformal = implode(", ", $this->request->getPost('pelatihan_nonformal'));


            $data = [
                'nia' => $nia_jadi,
                'nama' => $request->getPost('nama'),
                'nik' => $request->getPost('nik'),
                'kategori_data' => $request->getPost('kategori_data'),
                'tempat_lahir' => $request->getPost('tempat_lahir'),
                'tanggal_lahir' => $request->getPost('tanggal_lahir'),
                'alamat_lengkap' => $request->getPost('alamat_lengkap'),
                'id_pw' => '18',
                'id_pimpinan' => $request->getPost('id_pimpinan'),
                'id_pimpinan_ac' => $request->getPost('id_pimpinan_ac'),
                'id_pimpinan_rk' => $request->getPost('id_pimpinan_rk'),
                'aktif_kepengurusan' => $request->getPost('aktif_kepengurusan'),
                'pelatihan_formal' => $request->getPost('pelatihan_formal'),
                'makesta' => $request->getPost('makesta'),
                'penyelenggara_makesta' => $request->getPost('penyelenggara_makesta'),
                'tempat_makesta' => $request->getPost('tempat_makesta'),
                'waktu_makesta' => $request->getPost('waktu_makesta'),
                'lakmud' => $request->getPost('lakmud'),
                'penyelenggara_lakmud' => $request->getPost('penyelenggara_lakmud'),
                'tempat_lakmud' => $request->getPost('tempat_lakmud'),
                'waktu_lakmud' => $request->getPost('waktu_lakmud'),
                'lakut' => $request->getPost('lakut'),
                'penyelenggara_lakut' => $request->getPost('penyelenggara_lakut'),
                'tempat_lakut' => $request->getPost('tempat_lakut'),
                'waktu_lakut' => $request->getPost('waktu_lakut'),
                'email' => $request->getPost('email'),
                'password' => '$2y$10$Logj899HwVPyNFXVLpThg.RLf2zlwh9NDGrXg8B2xEAuglbu48NrW',
                'status_verifikasi' => 'belum',
                'jabatan' => $request->getPost('jabatan'),
            ];
            
        
        $model->insert($data);

        // Set flashdata untuk notifikasi
        //$this->session->setFlashdata('pesan', 'Data berhasil disimpan');

        return redirect()->to('admin/anggotapw');
        }
        
    }

    public function deleteanggota()
    {
        $id_anggota = $this->request->getGet('id');

        // Membuat instance dari model AnggotaModel
        $anggotaModel = new AnggotaModel();

        // Menghapus data anggota berdasarkan id
        $anggotaModel->delete($id_anggota);

        // Set pesan flashdata
        $session = session();
        $session->setFlashdata('flash', 'Dihapus');

        // Redirect ke halaman anggotapw
        return redirect()->to(base_url('admin/anggotapw'));
    }
    
    public function viewanggota()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        // Mendapatkan data anggota berdasarkan id_anggota dari input
        $anggotaModel = new AnggotaModel();
        $data['anggota'] = $anggotaModel->find($this->request->getGet('id'));

        // Menampilkan view dengan data yang telah disiapkan
        return view('template/headerTemplate', $data) . 
            view('home/viewanggota') . 
            view('template/footerTemplate');
    }

    public function editanggota()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['cabang'] = $pimpinanModel->where('kategori_data', $kat)->where('pimpinan', 'PC')->orderBy('kd_pimpinan')->get()->getResultArray();
        $cabang = $data['cabang'];

        $pimpinanAcModel = new PimpinanAcModel();
        $data['kecamatan'] = $pimpinanAcModel->where('kategori_data', $kat)->where('pimpinan_ac', 'PAC')->orderBy('kd_pimpinan_ac')->findAll();
        $kecamatan = $data['kecamatan'];

        $pimpinanRkModel = new PimpinanRkModel();
        $data['ranting'] = $pimpinanRkModel->where('kategori_data', $kat)->orderBy('kd_pimpinan_rk')->findAll();
        $ranting = $data['ranting'];

        // Mendapatkan data cabang berdasarkan kategori_data dan pimpinan
        //$data['cabang'] = $pimpinanModel->where('kategori_data', $kat)->where('pimpinan', 'PC')->orderBy('kd_pimpinan')->findAll();

        // Mendapatkan data kecamatan berdasarkan kategori_data dan pimpinan_ac
        //$data['kecamatan'] = $pimpinanAcModel->where('kategori_data', $kat)->where('pimpinan_ac', 'PAC')->orderBy('kd_pimpinan_ac')->findAll();

        // Mendapatkan data ranting berdasarkan kategori_data
        //$data['ranting'] = $pimpinanRkModel->where('kategori_data', $kat)->orderBy('pimpinan_rk')->orderBy('kd_pimpinan_rk')->findAll();

        // Mendapatkan data anggota berdasarkan id_anggota dari input
        $anggotaModel = new AnggotaModel();
        $id_anggota = $this->request->getGet('id');
        $data['anggota'] = $anggotaModel->select('*')->join('pimpinan', 'id_pimpinan')->join('pimpinan_ac', 'id_pimpinan_ac')->join('pimpinan_rk', 'id_pimpinan_rk')->find($id_anggota);
        //$data['anggota'] = $anggotaModel->find($id_anggota);

        // Menampilkan view dengan data yang telah disiapkan
        return view('template/headerTemplate', $data) . view('home/editanggota') . view('template/footerTemplate');
    }

    public function updateanggota()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        $id_anggota = $this->request->getPost('id');
        //$datanonformal = implode(", ",$this->input->post('pelatihan_nonformal'));
        $state = [
            'nia' => $this->request->getPost('nia'),
            'nama' => $this->request->getPost('nama'),
            'nik' => $this->request->getPost('nik'),
            'tempat_lahir' => $this->request->getPost('tempat_lahir'),
            'tanggal_lahir' => $this->request->getPost('tanggal_lahir'),
            'alamat_lengkap' => $this->request->getPost('alamat_lengkap'),
            'nama_ayah' => $this->request->getPost('nama_ayah'),
            'nama_ibu' => $this->request->getPost('nama_ibu'),
            'aktif_kepengurusan' => $this->request->getPost('aktif_kepengurusan'),
            //'id_pimpinan' => $this->request->getPost('id_pimpinan'),
            //'id_pimpinan_ac' => $this->request->getPost('id_pimpinan_ac'),
            'id_pimpinan_rk' => $this->request->getPost('id_pimpinan_rk'),
            'pelatihan_formal' => $this->request->getPost('pelatihan_formal'),
            'makesta' => $this->request->getPost('makesta'),
            'penyelenggara_makesta' => $this->request->getPost('penyelenggara_makesta'),
            'tempat_makesta' => $this->request->getPost('tempat_makesta'),
            'waktu_makesta' => $this->request->getPost('waktu_makesta'),
            'lakmud' => $this->request->getPost('lakmud'),
            'penyelenggara_lakmud' => $this->request->getPost('penyelenggara_lakmud'),
            'tempat_lakmud' => $this->request->getPost('tempat_lakmud'),
            'waktu_lakmud' => $this->request->getPost('waktu_lakmud'),
            'lakut' => $this->request->getPost('lakut'),
            'penyelenggara_lakut' => $this->request->getPost('penyelenggara_lakut'),
            'tempat_lakut' => $this->request->getPost('tempat_lakut'),
            'waktu_lakut' => $this->request->getPost('waktu_lakut'),
            'pelatihan_nonformal' => $this->request->getPost('pelatihan_nonformal'),
            'status_cbp' => $this->request->getPost('status_cbp'),
            'tanggal_masuk' => $this->request->getPost('tanggal_masuk'),
            'pendidikan_terakhir' => $this->request->getPost('pendidikan_terakhir'),
            'pendidikan_sd' => $this->request->getPost('pendidikan_sd'),
            'pendidikan_smp' => $this->request->getPost('pendidikan_smp'),
            'pendidikan_sma' => $this->request->getPost('pendidikan_sma'),
            'pendidikan_pt' => $this->request->getPost('pendidikan_pt'),
            'pendidikan_nonformal' => $this->request->getPost('pendidikan_nonformal'),
            'email' => $this->request->getPost('email'),
            'no_hp' => $this->request->getPost('no_hp'),
            'fb' => $this->request->getPost('fb'),
            'ig' => $this->request->getPost('ig'),
            'jabatan' => $this->request->getPost('jabatan'),
            'bakat' => $this->request->getPost('bakat'),
            'twitter' => $this->request->getPost('twitter'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT)
        ];
        
        $model = new AnggotaModel();
        $model->update($id_anggota, $state);
        
        return redirect()->to('admin/viewanggota?id=' . $id_anggota)->with('flash', 'Diedit');
        
    }

    public function aplikasi()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $pengaturanpimpinanModel = new PengaturanPimpinanModel();
        if ($tingkatan === 'PW') {
            $data['aplikasi'] = $pengaturanpimpinanModel->join('pimpinan', 'id_pimpinan')->where('id_pimpinan', $pimp)->first();;
            $aplikasi = $data['aplikasi'];
        } elseif ($tingkatan === 'PC') {
            $data['aplikasi'] = $pengaturanpimpinanModel->join('pimpinan', 'id_pimpinan')->where('id_pimpinan', $pimp)->first();
            $aplikasi = $data['aplikasi'];
        } elseif ($tingkatan === 'PAC') {
            $data['pac'] = $pimpinanacModel->where('id_pimpinan_ac', $session->get('id_pimpinan'))->first();
            $data['aplikasi'] = $pengaturanpimpinanModel->where('id_pimpinan', $pimp)->first();
        }

        if ($tingkatan === 'PW') {
            return view('template/headerTemplate', $data) .
            view('home/aplikasi') .
            view('template/footerTemplate');
        } elseif ($tingkatan === 'PC') {
            return view('template/headerUser', $data) .
            view('operator/aplikasi') .
            view('template/footerUser');
        } else {
            // Jika status akun tidak valid, mungkin redirect ke halaman error atau tampilkan pesan kesalahan
            return 'Invalid role';
        }

        //return view('template/headerTemplate', $data) . view('home/aplikasi') . view('template/footerTemplate');
    }

    public function editaplikasi_text()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];
        
        $pengaturanpimpinanModel = new PengaturanPimpinanModel();
        $data['aplikasi'] = $pengaturanpimpinanModel->join('pimpinan', 'id_pimpinan')->where('id_pimpinan', $pimp)->first();;
        $aplikasi = $data['aplikasi'];

        return view('template/headerTemplate', $data) . view('home/editaplikasi_text') . view('template/footerTemplate');
    }

    public function updateaplikasi_text()
    {
        $id_pengaturan = $this->request->getPost('id');
        $kolom = $this->request->getPost('kolom');
        $namakolom = $this->request->getPost('namakolom');

        $model = new PengaturanPimpinanModel();

        $data = [
            $namakolom => $kolom
        ];

        $model->where('id_pengaturan_pimpinan', $id_pengaturan)
            ->set($data)
            ->update();

        $session = session();
        //$session->setFlashdata('flash', 'Diedit');

        return redirect()->to('admin/aplikasi');
    }

    public function editaplikasi_foto()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];
        
        $pengaturanpimpinanModel = new PengaturanPimpinanModel();
        $data['aplikasi'] = $pengaturanpimpinanModel->join('pimpinan', 'id_pimpinan')->where('id_pimpinan', $pimp)->first();;
        $aplikasi = $data['aplikasi'];

        return view('template/headerTemplate', $data) . view('home/editaplikasi_foto') . view('template/footerTemplate');
    }

    public function updateaplikasi_foto()
    {
        $id_pengaturan = $this->request->getPost('id');
        $kolom = $this->request->getPost('kolom');
        $namakolom = $this->request->getPost('namakolom');

        $config['upload_path'] = './upload/setting-app/';
        $config['allowed_types'] = 'jpg|png';

        $upload = $this->request->getFile($namakolom);
        $upload->move('./upload/setting-app/', $upload->getName());

        $model = new PengaturanPimpinanModel();

        $data = [
            $namakolom => $upload->getName()
        ];

        $model->where('id_pengaturan_pimpinan', $id_pengaturan)
            ->set($data)
            ->update();

        $session = session();
        //$session->setFlashdata('flash', 'Diedit');

        return redirect()->to('admin/aplikasi');
    }

    public function editaplikasi_dokumen()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];
        
        $pengaturanpimpinanModel = new PengaturanPimpinanModel();
        $data['aplikasi'] = $pengaturanpimpinanModel->join('pimpinan', 'id_pimpinan')->where('id_pimpinan', $pimp)->first();;
        $aplikasi = $data['aplikasi'];

        return view('template/headerTemplate', $data) . view('home/editaplikasi_dokumen') . view('template/footerTemplate');
    }

    public function updateaplikasi_dokumen()
    {
        $id_pengaturan = $this->request->getPost('id');
        $kolom = $this->request->getPost('kolom');
        $namakolom = $this->request->getPost('namakolom');

        // Konfigurasi upload
        $config = [
            'upload_path' => './upload/setting-app/',
            'allowed_types' => 'pdf'
        ];

        // Memuat library Upload dengan konfigurasi
        $upload = \Config\Services::upload($config);

        // Mengambil file yang diupload
        $file = $this->request->getFile($namakolom);

        // Lakukan proses upload
        if ($file->isValid() && !$file->hasMoved()) {
            // Pindahkan file ke lokasi yang ditentukan
            $file->move($config['upload_path']);

            // Dapatkan nama file yang diupload
            $name = $file->getName();

            // Persiapkan model untuk update
            $model = new PengaturanPimpinanModel();

            // Data yang akan diupdate
            $data = [
                $namakolom => $name
            ];

            // Lakukan update ke database
            $model->update($id_pengaturan, $data);

            // Atur pesan flash
            session()->setFlashdata('flash', 'Diedit');

            // Redirect ke halaman aplikasi
            return redirect()->to('admin/aplikasi');
        } else {
            // Jika upload gagal, tangani kesalahan
            $errors = $file->getErrorString();
            return redirect()->back()->with('errors', $errors);
        }
    }

    public function kodedaerah()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        // Ambil data pimpinan dengan kategori 'PC' dan kategori_data sesuai dengan session
        $data['pimpinan'] = $pimpinanModel->where('pimpinan', 'PC')
                                ->where('kategori_data', $kat)
                                ->orderBy('kd_pimpinan')
                                ->findAll();
        
        $pimpinan = $data['pimpinan'];

        return view('template/headerTemplate', $data) . view('home/kodedaerah') . view('template/footerTemplate');
    }

    public function editpc()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        // Ambil id_pimpinan dari query string
        $id_pimpinan_get = $this->request->getGet('id');

        // Ambil data kodedaerah berdasarkan id_pimpinan yang diberikan
        $data['kodedaerah'] = $pimpinanModel->find($id_pimpinan_get);
        $kodedaerah = $data['kodedaerah'];

        // Tampilkan view dengan data yang sudah disiapkan
        return view('template/headerTemplate', $data) . view('home/editpc') . view('template/footerTemplate');
    }

    public function updatepc()
    {
        // Ambil data yang dikirimkan melalui HTTP POST
        $id_pimpinan = $this->request->getPost('id_pimpinan');
        $nama_pimpinan = $this->request->getPost('nama_pimpinan');
        $kd_pimpinan = $this->request->getPost('kd_pimpinan');

        // Update data dalam database
        $pimpinanModel = new PimpinanModel();
        $pimpinanModel->update($id_pimpinan, [
            'nama_pimpinan' => $nama_pimpinan,
            'kd_pimpinan' => $kd_pimpinan
        ]);

        // Set flashdata untuk memberi tahu pengguna bahwa data telah diedit
        //session()->setFlashdata('flash', 'Diedit');

        // Redirect pengguna ke halaman kodedaerah
        return redirect()->to('admin/kodedaerah');
    }

    public function kodepac()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id_pimpinan = $this->request->getGet('id');
        $data['pimpinan_cabang'] = $pimpinanModel->find($id_pimpinan);

        $pimpinanAcModel = new PimpinanAcModel();
        // Ambil data pimpinan dengan kategori 'PAC' dan kategori_data sesuai dengan session
        $data['pimpinan'] = $pimpinanAcModel->where('id_pimpinan', $id_pimpinan)->where('pimpinan_ac', 'PAC')
                                ->where('kategori_data', $kat)
                                ->orderBy('kd_pimpinan_ac')
                                ->findAll();
        
        $pimpinan = $data['pimpinan'];

        return view('template/headerTemplate', $data) . view('home/kodepac') . view('template/footerTemplate');
    }

    public function deletekodepac()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        $id_user = $this->request->getGet('id');
        $id_pimp = $this->request->getGet('id2');

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $adminModel = new PimpinanAcModel();
        $adminModel->delete($id_user);

        // Set pesan flashdata
        $session = session();
        $session->setFlashdata('flash', 'Dihapus');

        //$this->session->setFlashdata('flash', 'Dihapus');
        return redirect()->to('admin/kodepac?id=' . $id_pimp);
    }

    public function deletekoderanting()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        $id_user = $this->request->getGet('id');
        $id_pimp = $this->request->getGet('id2');
        $id4 = $this->request->getGet('id4');

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $adminModel = new PimpinanAcModel();
        $adminrkModel = new PimpinanRkModel();
        $adminrkModel->delete($id_user);

        // Set pesan flashdata
        $session = session();
        $session->setFlashdata('flash', 'Dihapus');

        //$this->session->setFlashdata('flash', 'Dihapus');
        return redirect()->to('admin/koderanting?id='. $id_pimp .'&id2=' . $id4);
    }

    public function deletekodekomisariat()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        $id_user = $this->request->getGet('id');
        $id_pimp = $this->request->getGet('id2');
        $id4 = $this->request->getGet('id4');

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $adminModel = new PimpinanAcModel();
        $adminrkModel = new PimpinanRkModel();
        $adminrkModel->delete($id_user);

        // Set pesan flashdata
        $session = session();
        $session->setFlashdata('flash', 'Dihapus');

        //$this->session->setFlashdata('flash', 'Dihapus');
        return redirect()->to('admin/kodekomisariat?id='. $id_pimp .'&id2=' . $id4);
    }

    public function datapac()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        //$id_pimpinan = $this->request->getGet('id');
        //$data['pimpinan_cabang'] = $pimpinanModel->find($id_pimpinan);

        $pimpinanAcModel = new PimpinanAcModel();
        // Ambil data pimpinan dengan kategori 'PAC' dan kategori_data sesuai dengan session
        $data['data_pac'] = $pimpinanAcModel->join('pimpinan', 'id_pimpinan')->where('pimpinan_ac', 'PAC')->where('status_aktif', 'aktif')
                                ->where('pimpinan_ac.kategori_data', $kat)
                                ->orderBy('kd_pimpinan_ac')
                                ->findAll();
        
        $data_pac = $data['data_pac'];

        return view('template/headerTemplate', $data) . view('home/datapac') . view('template/footerTemplate');
    }

    public function datapr()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        //$id_pimpinan = $this->request->getGet('id');
        //$data['pimpinan_cabang'] = $pimpinanModel->find($id_pimpinan);

        $pimpinanAcModel = new PimpinanAcModel();
        $pimpinanRkModel = new PimpinanRkModel();
        // Ambil data pimpinan dengan kategori 'PR' dan kategori_data sesuai dengan session
        $data['data_pr'] = $pimpinanRkModel->join('pimpinan', 'id_pimpinan')->join('pimpinan_ac', 'id_pimpinan_ac')->where('pimpinan_rk', 'PR')->where('pimpinan_rk.status_aktif', 'aktif')
                                ->where('pimpinan_rk.kategori_data', $kat)
                                ->orderBy('kd_pimpinan_rk')
                                ->findAll();
        
        $data_pr = $data['data_pr'];

        return view('template/headerTemplate', $data) . view('home/datapr') . view('template/footerTemplate');
    }

    public function datapk()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        //$id_pimpinan = $this->request->getGet('id');
        //$data['pimpinan_cabang'] = $pimpinanModel->find($id_pimpinan);

        $pimpinanAcModel = new PimpinanAcModel();
        $pimpinanRkModel = new PimpinanRkModel();
        // Ambil data pimpinan dengan kategori 'PR' dan kategori_data sesuai dengan session
        $data['data_pk'] = $pimpinanRkModel->join('pimpinan', 'id_pimpinan')->join('pimpinan_ac', 'id_pimpinan_ac')->where('pimpinan_rk', 'PK')->where('pimpinan_rk.status_aktif', 'aktif')
                                ->where('pimpinan_rk.kategori_data', $kat)
                                ->orderBy('kd_pimpinan_rk')
                                ->findAll();
        
        $data_pk = $data['data_pk'];

        return view('template/headerTemplate', $data) . view('home/datapk') . view('template/footerTemplate');
    }

    public function anggotaformal()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $kaderisasi = $this->request->getGet('id');
        //$data['pimpinan_cabang'] = $pimpinanModel->find($id_pimpinan);

        $pimpinanAcModel = new PimpinanAcModel();
        $pimpinanRkModel = new PimpinanRkModel();
        $anggotaModel = new AnggotaModel();
        // Ambil data pimpinan dengan kategori 'PR' dan kategori_data sesuai dengan session
        $data['anggota'] = $anggotaModel->join('pimpinan', 'id_pimpinan')->where('pelatihan_formal', $kaderisasi)
                                ->where('anggota.kategori_data', $kat)
                                ->orderBy('id_anggota')
                                ->findAll();
        
        $anggota = $data['anggota'];

        return view('template/headerTemplate', $data) . view('home/anggotaformal') . view('template/footerTemplate');
    }

    public function anggotacbp()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        //$kaderisasi = $this->request->getGet('id');
        //$data['pimpinan_cabang'] = $pimpinanModel->find($id_pimpinan);

        $pimpinanAcModel = new PimpinanAcModel();
        $pimpinanRkModel = new PimpinanRkModel();
        $anggotaModel = new AnggotaModel();
        // Ambil data pimpinan dengan kategori 'PR' dan kategori_data sesuai dengan session
        $data['anggota'] = $anggotaModel->join('pimpinan', 'id_pimpinan')->where('status_cbp', 'ya')
                                ->where('anggota.kategori_data', $kat)
                                ->orderBy('id_anggota')
                                ->findAll();
        
        $anggota = $data['anggota'];

        return view('template/headerTemplate', $data) . view('home/anggotacbp') . view('template/footerTemplate');
    }

    public function inpac()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id_pimpinan = $this->request->getGet('id');
        $data['pimpinan_cabang'] = $pimpinanModel->find($id_pimpinan);

        $pimpinanAcModel = new PimpinanAcModel();
        // Ambil data pimpinan dengan kategori 'PAC' dan kategori_data sesuai dengan session
        $data['pimpinan'] = $pimpinanAcModel->where('id_pimpinan', $id_pimpinan)->where('pimpinan_ac', 'PAC')
                                ->where('kategori_data', $kat)
                                ->orderBy('kd_pimpinan_ac')
                                ->findAll();
        
        $pimpinan = $data['pimpinan'];

        return view('template/headerTemplate', $data) . view('home/inpac') . view('template/footerTemplate');
    }

    public function addpac()
    {
        $kategoriData = session()->get('kategori');
        $pimpinan = $this->request->getPost('id_pimpinan');

        $data = [
            'id_pimpinan' => $this->request->getPost('id_pimpinan'),
            'pimpinan_ac' => 'PAC',
            'kategori_data' => $kategoriData,
            'kd_pimpinan_ac' => $this->request->getPost('kd_pimpinan_ac'),
            'nama_pimpinan_ac' => $this->request->getPost('nama_pimpinan_ac')
        ];

        $pimpinanAcModel = new PimpinanAcModel();
        $pimpinanAcModel->insert($data);

        session()->setFlashdata('flash', 'Tersimpan');
        return redirect()->to('admin/kodepac?id=' . $pimpinan);
    }

    public function editpac()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $pimpinanAcModel = new PimpinanAcModel();

        // Ambil id_pimpinan dari query string
        $id_pimpinan_get = $this->request->getGet('id');

        // Ambil data kodedaerah berdasarkan id_pimpinan yang diberikan
        $data['kodedaerah'] = $pimpinanAcModel->find($id_pimpinan_get);
        $kodedaerah = $data['kodedaerah'];
        
        // Tampilkan view dengan data yang sudah disiapkan
        return view('template/headerTemplate', $data) . view('home/editpac') . view('template/footerTemplate');
    }

    public function updatepac()
    {
        // Ambil data yang dikirimkan melalui HTTP POST
        $id_pimpinan_ac = $this->request->getPost('id_pimpinan_ac');
        $id_pimpinan = $this->request->getPost('id_pimpinan');
        $nama_pimpinan_ac = $this->request->getPost('nama_pimpinan_ac');
        $kd_pimpinan_ac = $this->request->getPost('kd_pimpinan_ac');
        $status_aktif = $this->request->getPost('status_aktif');

        // Update data dalam database
        $pimpinanAcModel = new PimpinanAcModel();
        $pimpinanAcModel->update($id_pimpinan_ac, [
            'nama_pimpinan_ac' => $nama_pimpinan_ac,
            'kd_pimpinan_ac' => $kd_pimpinan_ac,
            'status_aktif' => $status_aktif,
        ]);

        // Set flashdata untuk memberi tahu pengguna bahwa data telah diedit
        //session()->setFlashdata('flash', 'Diedit');

        // Redirect pengguna ke halaman kodedaerah
        return redirect()->to('admin/kodepac?id=' .$id_pimpinan);
    }

    public function koderanting()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $pimpinanAcModel = new PimpinanAcModel();
        $pimpinanRkModel = new PimpinanRkModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id_pimpinan_ac = $this->request->getGet('id');
        $data['pac'] = $pimpinanAcModel->find($id_pimpinan_ac);

        $id_pimpinan = $this->request->getGet('id2');
        $data['pimpinan_cabang'] = $pimpinanModel->find($id_pimpinan);

        
        // Ambil data pimpinan dengan kategori 'PAC' dan kategori_data sesuai dengan session
        $data['pimpinan'] = $pimpinanRkModel->where('id_pimpinan', $id_pimpinan)->where('id_pimpinan_ac', $id_pimpinan_ac)->where('pimpinan_rk', 'PR')
                                ->where('kategori_data', $kat)
                                ->orderBy('kd_pimpinan_rk')
                                ->findAll();
        
        $pimpinan = $data['pimpinan'];

        return view('template/headerTemplate', $data) . view('home/koderanting') . view('template/footerTemplate');
    }

    public function kodekomisariat()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $pimpinanAcModel = new PimpinanAcModel();
        $pimpinanRkModel = new PimpinanRkModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id_pimpinan_ac = $this->request->getGet('id');
        $data['pac'] = $pimpinanAcModel->find($id_pimpinan_ac);

        $id_pimpinan = $this->request->getGet('id2');
        $data['pimpinan_cabang'] = $pimpinanModel->find($id_pimpinan);

        
        // Ambil data pimpinan dengan kategori 'PAC' dan kategori_data sesuai dengan session
        $data['pimpinan'] = $pimpinanRkModel->where('id_pimpinan', $id_pimpinan)->where('id_pimpinan_ac', $id_pimpinan_ac)->where('pimpinan_rk', 'PK')
                                ->where('kategori_data', $kat)
                                ->orderBy('kd_pimpinan_rk')
                                ->findAll();
        
        $pimpinan = $data['pimpinan'];

        return view('template/headerTemplate', $data) . view('home/kodekomisariat') . view('template/footerTemplate');
    }

    public function inranting()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $pimpinanAcModel = new PimpinanAcModel();
        $pimpinanRkModel = new PimpinanRkModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id_pimpinan_ac = $this->request->getGet('id');
        $data['pac'] = $pimpinanAcModel->find($id_pimpinan_ac);

        $id_pimpinan = $this->request->getGet('id2');
        $data['pimpinan_cabang'] = $pimpinanModel->find($id_pimpinan);

        
        // Ambil data pimpinan dengan kategori 'PAC' dan kategori_data sesuai dengan session
        $data['pimpinan'] = $pimpinanRkModel->where('id_pimpinan', $id_pimpinan)->where('id_pimpinan_ac', $id_pimpinan_ac)->where('pimpinan_rk', 'PK')
                                ->where('kategori_data', $kat)
                                ->orderBy('kd_pimpinan_rk')
                                ->findAll();
        
        $pimpinan = $data['pimpinan'];

        return view('template/headerTemplate', $data) . view('home/inranting') . view('template/footerTemplate');
    }

    public function addranting()
    {
        $kategoriData = session()->get('kategori');
        $idPimpinanAc = $this->request->getPost('id_pimpinan_ac');
        $idPimpinan = $this->request->getPost('id_pimpinan');
        $jenis = $this->request->getPost('pimpinan_rk');

        $data = [
            'id_pimpinan_ac' => $idPimpinanAc,
            'id_pimpinan' => $idPimpinan,
            'pimpinan_rk' => $jenis,
            'kategori_data' => $kategoriData,
            'kd_pimpinan_rk' => $this->request->getPost('kd_pimpinan_rk'),
            'nama_pimpinan_rk' => $this->request->getPost('nama_pimpinan_rk')
        ];

        $pimpinanRkModel = new PimpinanRkModel();
        $pimpinanRkModel->insert($data);

        $redirectUrl = ($jenis == 'PR') ? 'admin/koderanting?id2=' . $idPimpinan . '&id=' . $idPimpinanAc : 'admin/kodekomisariat?id2=' . $idPimpinan . '&id=' . $idPimpinanAc;

        session()->setFlashdata('flash', 'Tersimpan');
        return redirect()->to($redirectUrl);
    }

    public function editranting()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $pimpinanAcModel = new PimpinanAcModel();
        $pimpinanRkModel = new PimpinanRkModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        // Ambil id_pimpinan dari query string
        $id_pimpinan_get = $this->request->getGet('id4');

        // Ambil data kodedaerah berdasarkan id_pimpinan yang diberikan
        $data['kodedaerah'] = $pimpinanAcModel->find($id_pimpinan_get);
        $kodedaerah = $data['kodedaerah'];

        $id_pimpinan_rk = $this->request->getGet('id');
        $data['koderanting'] = $pimpinanRkModel->where('id_pimpinan_rk', $id_pimpinan_rk)->first();
        
        // Tampilkan view dengan data yang sudah disiapkan
        return view('template/headerTemplate', $data) . view('home/editranting') . view('template/footerTemplate');
    }

    public function updateranting()
    {
        // Ambil data yang dikirimkan melalui HTTP POST
        $id_pimpinan_ac = $this->request->getPost('id_pimpinan_ac');
        $id_pimpinan = $this->request->getPost('id_pimpinan');
        $id_pimpinan_rk = $this->request->getPost('id_pimpinan_rk');
        $nama_pimpinan_rk = $this->request->getPost('nama_pimpinan_rk');
        $kd_pimpinan_rk = $this->request->getPost('kd_pimpinan_rk');
        $jenis = $this->request->getPost('pimpinan_rk');
        $status_aktif = $this->request->getPost('status_aktif');

        $pimpinanModel = new PimpinanModel();
        //$id_pimpinan = $this->request->getGet('id2');
        //$id_pimpinan_ac = $this->request->getGet('id');
        $data['pimpinan_cabang'] = $pimpinanModel->find($id_pimpinan);

        // Update data dalam database
        $pimpinanAcModel = new PimpinanAcModel();
        $pimpinanRkModel = new PimpinanRkModel();
        $pimpinanRkModel->update($id_pimpinan_rk, [
            'nama_pimpinan_rk' => $nama_pimpinan_rk,
            'kd_pimpinan_rk' => $kd_pimpinan_rk,
            'status_aktif' => $status_aktif,
        ]);

        // Set flashdata untuk memberi tahu pengguna bahwa data telah diedit
        //session()->setFlashdata('flash', 'Diedit');

        // Redirect pengguna ke halaman kodedaerah
        if($jenis=='PR'){
            return redirect()->to('admin/koderanting?id=' .$id_pimpinan_ac.'&id2='.$id_pimpinan);
        }else{
            return redirect()->to('admin/kodekomisariat?id=' .$id_pimpinan_ac.'&id2='.$id_pimpinan);
        }
    }

    public function statistikorganisasi()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        // Hitung jumlah anggota
        $anggotaModel = new AnggotaModel();
        $data['anggota'] = $anggotaModel->where('kategori_data', $kat)->countAllResults();
        $data['anggotapc'] = $anggotaModel->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->countAllResults();

        // Hitung jumlah anggota yang belum diverifikasi
        $data['belumverifikasi'] = $anggotaModel->where('kategori_data', $kat)->where('status_verifikasi', 'belum')->countAllResults();
        $data['belumverifikasipc'] = $anggotaModel->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->where('status_verifikasi', 'belum')->countAllResults();

        // Hitung jumlah pimpinan
        $pimpinanCount = $pimpinanModel->where('pimpinan', 'PC')->where('kategori_data', $kat)->countAllResults();
        $data['statistik_pc'] = $pimpinanCount;

        // Data PAC
        $pimpinanAcModel = new PimpinanAcModel();
        $pimpinanAccCount = $pimpinanAcModel->where('pimpinan_ac', 'PAC')->where('status_aktif', 'Aktif')->where('kategori_data', $kat)->countAllResults();
        $data['statistik_ac_aktif'] = $pimpinanAccCount;

        $pimpinanAcCount = $pimpinanAcModel->where('pimpinan_ac', 'PAC')->where('kategori_data', $kat)->countAllResults();
        $data['statistik_ac'] = $pimpinanAcCount;

        $data['id_pimpinan_ac'] = $session->get('id_pimpinan_ac');
        $pimp1 = $data['id_pimpinan_ac'];

        // Data Ranting dan Komisariat
        $pimpinanRkModel = new PimpinanRkModel();
        $ranting_aktif = $pimpinanRkModel->where('kategori_data', $kat)->where('status_aktif', 'Aktif')->where('pimpinan_rk', 'PR')->countAllResults();
        $data['ranting_aktif'] = $ranting_aktif;

        $pimpinanRkkCount = $pimpinanRkModel->where('pimpinan_rk', 'PR')->where('kategori_data', $kat)->countAllResults();
        $data['ranting'] = $pimpinanRkkCount;

        $pimpinanRkCount = $pimpinanRkModel->where('pimpinan_rk', 'PK')->where('status_aktif', 'Aktif')->where('kategori_data', $kat)->countAllResults();
        $data['komisariat_aktif'] = $pimpinanRkCount;

        $pimpinanRktCount = $pimpinanRkModel->where('pimpinan_rk', 'PK')->where('kategori_data', $kat)->countAllResults();
        $data['komisariat'] = $pimpinanRktCount;

        // Hitung jumlah keuangan
        $keuanganModel = new KeuanganModel();

        // Memanggil method untuk menghitung total masuk dan keluar dari model
        $totalMasuk = $keuanganModel->selectSum('masuk')->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->first();
        $totalKeluar = $keuanganModel->selectSum('keluar')->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->first();

        $totalMasuk = isset($totalMasukResult['masuk']) ? $totalMasukResult['masuk'] : 0;
        $totalKeluar = isset($totalKeluarResult['keluar']) ? $totalKeluarResult['keluar'] : 0;

        $selisih = $totalMasuk - $totalKeluar;

        // Menggabungkan total masuk, total keluar, dan selisih ke dalam satu array
        $data['jumlah_keuangan'] = ['masuk' => $totalMasuk, 'keluar' => $totalKeluar, 'selisih' => $selisih];

        $suratMasukModel = new SuratMasukModel();
        $data['sm'] = $suratMasukModel->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->countAllResults();

        return view('template/headerTemplate', $data) . view('home/statistikorganisasi') . view('template/footerTemplate');
    }

    public function potensikader()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        // Hitung jumlah anggota
        $anggotaModel = new AnggotaModel();
        $data['anggota'] = $anggotaModel->where('kategori_data', $kat)->countAllResults();
        $data['makesta'] = $anggotaModel->where('pelatihan_formal', 'makesta')->where('kategori_data', $kat)->countAllResults();
        $data['lakmud'] = $anggotaModel->where('pelatihan_formal', 'lakmud')->where('kategori_data', $kat)->countAllResults();
        $data['lakut'] = $anggotaModel->where('pelatihan_formal', 'lakut')->where('kategori_data', $kat)->countAllResults();
        $data['cbp'] = $anggotaModel->where('status_cbp', 'ya')->where('kategori_data', $kat)->countAllResults();

        return view('template/headerTemplate', $data) . view('home/potensikader') . view('template/footerTemplate');
    }

    public function minatbakat()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level']; 

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        // Hitung jumlah anggota
        $anggotaModel = new AnggotaModel();
        $data['m1'] = $anggotaModel->where('minat_bakat', 'Seni dan Kreativitas')->where('kategori_data', $kat)->countAllResults();
        $data['m2'] = $anggotaModel->where('minat_bakat', 'Musik')->where('kategori_data', $kat)->countAllResults();
        $data['m3'] = $anggotaModel->where('minat_bakat', 'Tari dan Pertunjukan')->where('kategori_data', $kat)->countAllResults();
        $data['m4'] = $anggotaModel->where('minat_bakat', 'Penulisan dan Literasi')->where('kategori_data', $kat)->countAllResults();
        $data['m5'] = $anggotaModel->where('minat_bakat', 'Olahraga dan Kesehatan')->where('kategori_data', $kat)->countAllResults();
        $data['m6'] = $anggotaModel->where('minat_bakat', 'Ilmu Pengetahuan dan Teknologi')->where('kategori_data', $kat)->countAllResults();
        $data['m7'] = $anggotaModel->where('minat_bakat', 'Kepemimpinan dan Kepanitiaan')->where('kategori_data', $kat)->countAllResults();
        $data['m8'] = $anggotaModel->where('minat_bakat', 'Keterampilan Praktis')->where('kategori_data', $kat)->countAllResults();
        $data['m9'] = $anggotaModel->where('minat_bakat', 'Kepedulian Sosial dan Lingkungan')->where('kategori_data', $kat)->countAllResults();
        $data['m10'] = $anggotaModel->where('minat_bakat', 'Bisnis dan Kewirausahaan')->where('kategori_data', $kat)->countAllResults();
        $data['m11'] = $anggotaModel->where('minat_bakat', 'Budaya dan Bahasa')->where('kategori_data', $kat)->countAllResults();
        $data['m12'] = $anggotaModel->where('minat_bakat', 'Media')->where('kategori_data', $kat)->countAllResults();

        return view('template/headerTemplate', $data) . view('home/minatbakat') . view('template/footerTemplate');
    }

    public function manajemenuser()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        //$kaderisasi = $this->request->getGet('id');
        //$data['pimpinan_cabang'] = $pimpinanModel->find($id_pimpinan);

        //$pimpinanAcModel = new PimpinanAcModel();
        //$pimpinanRkModel = new PimpinanRkModel();
        //$anggotaModel = new AnggotaModel();
        // Ambil data pimpinan dengan kategori 'PR' dan kategori_data sesuai dengan session
        $data['manajemenuser'] = $userModel->where('aktif', 'Y')
                                ->where('kategori_user', $kat)
                                ->orderBy('email')
                                ->findAll();
        
        $manajemenuser = $data['manajemenuser'];

        return view('template/headerTemplate', $data) . view('home/user') . view('template/footerTemplate');
    }

    public function edituser()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id_user = $this->request->getGet('id');
        //$data['pimpinan_cabang'] = $pimpinanModel->find($id_pimpinan);

        //$pimpinanAcModel = new PimpinanAcModel();
        //$pimpinanRkModel = new PimpinanRkModel();
        //$anggotaModel = new AnggotaModel();
        // Ambil data pimpinan dengan kategori 'PR' dan kategori_data sesuai dengan session
        $data['user'] = $userModel->where('id_user', $id_user)
                                //->where('kategori_user', $kat)
                                //->orderBy('email')
                                ->first();
        
        $user = $data['user'];
        //$encryptedPassword = $userData['encrypted_password'];

        //$data['user_data'] = $userModel->select('password')->where('id_user', $id_user)->get()->getRow();
        //$userData = $data['user_data'];
        //return view('encrypted_password', ['encryptedPassword' => $userData->password]);

        return view('template/headerTemplate', $data) . view('home/edituser') . view('template/footerTemplate');
    }

    public function updateuser()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id_user = $this->request->getPost('id_user');
        $password = $this->request->getPost('password');
        $username = $this->request->getPost('username');
        $email = $this->request->getPost('email');
        $nama_lengkap = $this->request->getPost('nama_lengkap');
        $no_telpon = $this->request->getPost('no_telpon');
        $sekretariat = $this->request->getPost('sekretariat');

        // Lakukan pengecekan apakah ada perubahan pada password
        $encryptedPassword = password_hash($password, PASSWORD_DEFAULT);

        $userModel = new UserModel();
        $userModel->update($id_user, [
            'username' => $username,
            'email' => $email,
            'password' => $encryptedPassword,
            'nama_lengkap' => $nama_lengkap,
            'no_telpon' => $no_telpon,
            'sekretariat' => $sekretariat,
        ]);

        //$this->session->setFlashdata('flash', 'Diedit');
        return redirect()->to('admin/manajemenuser');
    }

    public function deleteuser()
    {
        $id_user = $this->request->getGet('id');

        $adminModel = new UserModel();
        $adminModel->delete($id_user);

        // Set pesan flashdata
        $session = session();
        $session->setFlashdata('flash', 'Dihapus');

        //$this->session->setFlashdata('flash', 'Dihapus');
        return redirect()->to('admin/manajemenuser');
    }

    public function inuserpw()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        //$this->session->setFlashdata('flash', 'Diedit');
        return view('template/headerTemplate', $data) . view('home/inuserpw') . view('template/footerTemplate');
    }

    public function inusercabang()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['pimpinan_cabang'] = $pimpinanModel->where('kategori_data', $kat)->where('pimpinan', 'PC')->orderBy('kd_pimpinan')->get()->getResultArray();
        $pimpinan_cabang = $data['pimpinan_cabang'];

        //$this->session->setFlashdata('flash', 'Diedit');
        return view('template/headerTemplate', $data) . view('home/inusercabang') . view('template/footerTemplate');
    }

    public function inuserpac()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['pimpinan_cabang'] = $pimpinanModel->where('kategori_data', $kat)->where('pimpinan', 'PC')->orderBy('kd_pimpinan')->get()->getResultArray();
        $pimpinan_cabang = $data['pimpinan_cabang'];

        $pimpinanacModel = new PimpinanAcModel();
        $data['anakcabang'] = $pimpinanacModel->where('kategori_data', $kat)->where('pimpinan_ac', 'PAC')->orderBy('kd_pimpinan_ac')->get()->getResultArray();
        $anakcabang = $data['anakcabang'];

        //$this->session->setFlashdata('flash', 'Diedit');
        return view('template/headerTemplate', $data) . view('home/inuserpac') . view('template/footerTemplate');
    }

    public function inuserpr()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['pimpinan_cabang'] = $pimpinanModel->where('kategori_data', $kat)->where('pimpinan', 'PC')->orderBy('kd_pimpinan')->get()->getResultArray();
        $pimpinan_cabang = $data['pimpinan_cabang'];

        $pimpinanacModel = new PimpinanAcModel();
        $data['anakcabang'] = $pimpinanacModel->where('kategori_data', $kat)->where('pimpinan_ac', 'PAC')->orderBy('kd_pimpinan_ac')->findAll();
        $anakcabang = $data['anakcabang'];

        $pimpinanrkModel = new PimpinanRkModel();
        $data['ranting'] = $pimpinanrkModel->where('kategori_data', $kat)->where('pimpinan_rk', 'PR')->orderBy('kd_pimpinan_rk')->findAll();
        $ranting = $data['ranting'];

        //$this->session->setFlashdata('flash', 'Diedit');
        return view('template/headerTemplate', $data) . view('home/inuserpr') . view('template/footerTemplate');
    }

    public function inuserpk()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['pimpinan_cabang'] = $pimpinanModel->where('kategori_data', $kat)->where('pimpinan', 'PC')->orderBy('kd_pimpinan')->get()->getResultArray();
        $pimpinan_cabang = $data['pimpinan_cabang'];

        $pimpinanacModel = new PimpinanAcModel();
        $data['anakcabang'] = $pimpinanacModel->where('kategori_data', $kat)->where('pimpinan_ac', 'PAC')->orderBy('kd_pimpinan_ac')->findAll();
        $anakcabang = $data['anakcabang'];

        $pimpinanrkModel = new PimpinanRkModel();
        $data['ranting'] = $pimpinanrkModel->where('kategori_data', $kat)->where('pimpinan_rk', 'PK')->orderBy('kd_pimpinan_rk')->findAll();
        $ranting = $data['ranting'];

        //$this->session->setFlashdata('flash', 'Diedit');
        return view('template/headerTemplate', $data) . view('home/inuserpk') . view('template/footerTemplate');
    }

    public function adduser()
    {
        $kategori_data = session()->get('kategori');
        $kat = $kategori_data;
        $tingkatan = $this->request->getPost('tingkatan');

        $userModel = new UserModel();
        $pengaturanpimpinanModel = new PengaturanPimpinanModel();

        $hashedPassword = password_hash($this->request->getPost('password'), PASSWORD_DEFAULT);

        if ($tingkatan == 'PW') {
            $data = [
                'id_pimpinan' => $this->request->getPost('id_pimpinan'),
                'username' => $this->request->getPost('username'),
                'password' => $hashedPassword,
                'kategori_user' => $kat,
                'tingkatan' => $this->request->getPost('tingkatan'),
                'sekretariat' => $this->request->getPost('sekretariat'),
                'email' => $this->request->getPost('email'),
                'no_telpon' => $this->request->getPost('no_telpon'),
                'nama_lengkap' => $this->request->getPost('nama_lengkap'),
                'level' => $this->request->getPost('level'),
                'aktif' => 'Y'
            ];
            $userModel->insert($data);
        } elseif ($tingkatan == 'PC') {
            $data = [
                'id_pimpinan' => $this->request->getPost('id_pimpinan'),
                'username' => $this->request->getPost('username'),
                'password' => $hashedPassword,
                'kategori_user' => $kat,
                'tingkatan' => $this->request->getPost('tingkatan'),
                'sekretariat' => $this->request->getPost('sekretariat'),
                'email' => $this->request->getPost('email'),
                'no_telpon' => $this->request->getPost('no_telpon'),
                'nama_lengkap' => $this->request->getPost('nama_lengkap'),
                'level' => $this->request->getPost('level'),
                'ket' => $this->request->getPost('id_pimpinan'),
                'aktif' => 'Y'
            ];
            $userModel->insert($data);

            $data_setting = [
                'id_pimpinan' => $this->request->getPost('id_pimpinan'),
                'tingkatan' => 'PC'
            ];
            $pengaturanpimpinanModel->insert($data_setting);
        } elseif ($tingkatan == 'PAC') {
            $data = [
                'id_pimpinan' => $this->request->getPost('id_pimpinan'),
                'username' => $this->request->getPost('username'),
                'password' => $hashedPassword,
                'kategori_user' => $kat,
                'tingkatan' => $this->request->getPost('tingkatan'),
                'sekretariat' => $this->request->getPost('sekretariat'),
                'email' => $this->request->getPost('email'),
                'no_telpon' => $this->request->getPost('no_telpon'),
                'nama_lengkap' => $this->request->getPost('nama_lengkap'),
                'level' => $this->request->getPost('level'),
                'ket' => $this->request->getPost('id_pimpinan1'),
                'pac' => $this->request->getPost('id_pimpinan'),
                'aktif' => 'Y'
            ];
            $userModel->insert($data);

            $data_setting = [
                'id_pimpinan' => $this->request->getPost('id_pimpinan'),
                'tingkatan' => 'PAC'
            ];
            $pengaturanpimpinanModel->insert($data_setting);
        } elseif ($tingkatan == 'PR') {
            $data = [
                'id_pimpinan' => $this->request->getPost('id_pimpinan_rk'),
                'username' => $this->request->getPost('username'),
                'password' => $hashedPassword,
                'kategori_user' => $kat,
                'tingkatan' => $this->request->getPost('tingkatan'),
                'sekretariat' => $this->request->getPost('sekretariat'),
                'email' => $this->request->getPost('email'),
                'no_telpon' => $this->request->getPost('no_telpon'),
                'nama_lengkap' => $this->request->getPost('nama_lengkap'),
                'level' => $this->request->getPost('level'),
                'ket' => $this->request->getPost('id_pimpinan1'),
                'pac' => $this->request->getPost('id_pimpinan2'),
                'aktif' => 'Y'
            ];
            $userModel->insert($data);

            $data_setting = [
                'id_pimpinan' => $this->request->getPost('id_pimpinan_rk'),
                'tingkatan' => 'PR'
            ];
            $pengaturanpimpinanModel->insert($data_setting);
        } elseif ($tingkatan == 'PK') {
            $data = [
                'id_pimpinan' => $this->request->getPost('id_pimpinan_rk'),
                'username' => $this->request->getPost('username'),
                'password' => $hashedPassword,
                'kategori_user' => $kat,
                'tingkatan' => $this->request->getPost('tingkatan'),
                'sekretariat' => $this->request->getPost('sekretariat'),
                'email' => $this->request->getPost('email'),
                'no_telpon' => $this->request->getPost('no_telpon'),
                'nama_lengkap' => $this->request->getPost('nama_lengkap'),
                'level' => $this->request->getPost('level'),
                'ket' => $this->request->getPost('id_pimpinan1'),
                'pac' => $this->request->getPost('id_pimpinan2'),
                'aktif' => 'Y'
            ];
            $userModel->insert($data);

            $data_setting = [
                'id_pimpinan' => $this->request->getPost('id_pimpinan_rk'),
                'tingkatan' => 'PK'
            ];
            $pengaturanpimpinanModel->insert($data_setting);
        }

        session()->setFlashdata('flash', 'Tersimpan');
        return redirect()->to('admin/manajemenuser');
    }

    public function editfotoanggota()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id_anggota = $this->request->getGet('id'); // Menggunakan method getGet untuk mendapatkan data dari query string
        $anggotaModel = new AnggotaModel();
        $data['anggota'] = $anggotaModel->find($id_anggota);

        return view('template/headerTemplate', $data)
            .view('home/editfotoanggota')
            .view('template/footerTemplate');
    }

    public function updatefotoanggota()
    {
        $id_anggota = $this->request->getPost('id');

        $upload = $this->request->getFile('foto');
        if ($upload->isValid() && !$upload->hasMoved()) {
            $newName = $upload->getRandomName();
            $upload->move('./upload/anggota', $newName);

            $anggotaModel = new AnggotaModel();
            $anggotaModel->update($id_anggota, ['foto' => $newName]);
        }

        session()->setFlashdata('flash', 'Diedit');
        return redirect()->to('admin/viewanggota?id=' . $id_anggota);
    }

    public function suratmasuk()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        //$id_anggota = $this->request->getGet('id'); // Menggunakan method getGet untuk mendapatkan data dari query string
        $suratmasukModel = new SuratMasukModel();
        $data['suratmasuk'] = $suratmasukModel->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->orderBy('tanggal_surat_diterima')->get()->getResultArray();
        $suratmasuk = $data['suratmasuk'];

        return view('template/headerTemplate', $data)
            .view('home/suratmasuk')
            .view('template/footerTemplate');
    }

    public function insuratmasuk()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        //$id_anggota = $this->request->getGet('id'); // Menggunakan method getGet untuk mendapatkan data dari query string
        // $suratmasukModel = new SuratMasukModel();
        // $data['suratmasuk'] = $suratmasukModel->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->orderBy('tanggal_surat_diterima')->get()->getResultArray();
        // $suratmasuk = $data['suratmasuk'];

        return view('template/headerTemplate', $data)
            .view('home/insuratmasuk')
            .view('template/footerTemplate');
    }

    public function addsuratmasuk()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        // Konfigurasi upload
        $uploadPath = './upload/suratmasuk/';
        $allowedTypes = 'pdf|jpg|png';
        $uploadConfig = [
            'upload_path' => $uploadPath,
            'allowed_types' => $allowedTypes
        ];

        $request = service('request');

        // Ambil file upload
        $fileSurat = $request->getFile('file_surat');

        // Validasi upload
        if ($fileSurat->isValid() && !$fileSurat->hasMoved()) {
            // Pindahkan file upload ke folder upload
            $newName = $fileSurat->getRandomName();
            $fileSurat->move($uploadPath, $newName);
        

            // Data untuk dimasukkan ke database
            $dataInsert = [
                'id_pimpinan' => $pimp,
                'kategori_data' => $kat,
                'pengirim' => $request->getPost('pengirim'),
                'tanggal_surat_diterima' => $request->getPost('tanggal_surat_diterima'),
                'perihal' => $request->getPost('perihal'),
                'nomor_surat_masuk' => $request->getPost('nomor_surat_masuk'),
                'tanggal_surat' => $request->getPost('tanggal_surat'),
                'tembusan' => $request->getPost('tembusan'),
                'catatan_disposisi' => $request->getPost('catatan_disposisi'),
                'keterangan' => $request->getPost('keterangan'),
                'file_surat' => $newName
            ];
        

            // Masukkan data ke database
            $suratMasukModel = new SuratMasukModel();
            $suratMasukModel->insert($dataInsert);
        }

            // Set flashdata dan redirect
            $session->setFlashdata('flash', 'Tersimpan');
            return redirect()->to('admin/suratmasuk');
    }

    public function viewsuratmasuk()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id = $this->request->getGet('id');
        $suratMasukModel = new SuratMasukModel();
        $data['suratmasuk'] = $suratMasukModel->where('id_surat_masuk', $id)->first();
        
        return view('template/headerTemplate', $data)
            .view('home/viewsuratmasuk')
            .view('template/footerTemplate');
    }

    public function editsuratmasuk()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id = $this->request->getGet('id');
        $suratMasukModel = new SuratMasukModel();
        $data['suratmasuk'] = $suratMasukModel->where('id_surat_masuk', $id)->first();
        
        return view('template/headerTemplate', $data)
            .view('home/editsuratmasuk')
            .view('template/footerTemplate');
    }

    public function updatesuratmasuk()
    {
        $suratMasukModel = new SuratMasukModel();

        $id_sm = $this->request->getPost('id_surat_masuk');
        $data = [
            'pengirim' => $this->request->getPost('pengirim'),
            'tanggal_surat_diterima' => $this->request->getPost('tanggal_surat_diterima'),
            'perihal' => $this->request->getPost('perihal'),
            'nomor_surat_masuk' => $this->request->getPost('nomor_surat_masuk'),
            'tanggal_surat' => $this->request->getPost('tanggal_surat'),
            'tembusan' => $this->request->getPost('tembusan'),
            'catatan_disposisi' => $this->request->getPost('catatan_disposisi'),
            'keterangan' => $this->request->getPost('keterangan')
        ];

        $suratMasukModel->update($id_sm, $data);

        return redirect()->to('/admin/suratmasuk')->with('flash', 'Diedit');
    }

    public function deletesuratmasuk()
    {
        $suratMasukModel = new SuratMasukModel();

        $id_sm = $this->request->getGet('id');
        $suratMasukModel->delete($id_sm);

        return redirect()->to('/admin/suratmasuk')->with('flash', 'Dihapus');
    }

    public function suratkeluar()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        //$id_anggota = $this->request->getGet('id'); // Menggunakan method getGet untuk mendapatkan data dari query string
        $suratkeluarModel = new SuratKeluarModel();
        $data['surat_keluar'] = $suratkeluarModel->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->orderBy('tanggal_surat')->get()->getResultArray();
        $surat_keluar = $data['surat_keluar'];

        return view('template/headerTemplate', $data)
            .view('home/suratkeluar')
            .view('template/footerTemplate');
    }

    public function insuratkeluar()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        //$id_anggota = $this->request->getGet('id'); // Menggunakan method getGet untuk mendapatkan data dari query string
        // $suratmasukModel = new SuratMasukModel();
        // $data['suratmasuk'] = $suratmasukModel->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->orderBy('tanggal_surat_diterima')->get()->getResultArray();
        // $suratmasuk = $data['suratmasuk'];

        return view('template/headerTemplate', $data)
            .view('home/insuratkeluar')
            .view('template/footerTemplate');
    }

    public function addsuratkeluar()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $file = $this->request->getFile('file_surat');
        $newName = $file->getRandomName();
        $uploadPath = './upload/suratkeluar/';

        if ($file->isValid() && !$file->hasMoved()) {
            $file->move($uploadPath, $newName);
        }

        $data = [
            'id_pimpinan' => $pimp,
            'kategori_data' => $kat,
            'nomor_surat' => $this->request->getPost('nomor_surat'),
            'index_surat' => $this->request->getPost('index_surat'),
            'tanggal_surat' => $this->request->getPost('tanggal_surat'),
            'tujuan_surat' => $this->request->getPost('tujuan_surat'),
            'perihal' => $this->request->getPost('perihal'),
            'keterangan' => $this->request->getPost('keterangan'),
            'file_surat' => $newName
        ];

        $suratKeluarModel = new SuratKeluarModel();
        $suratKeluarModel->insert($data);

        $session->setFlashdata('flash', 'Tersimpan');
        return redirect()->to('/admin/suratkeluar');
    }

    public function viewsuratkeluar()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id = $this->request->getGet('id');
        $suratkeluarModel = new SuratKeluarModel();
        $data['surat_keluar'] = $suratkeluarModel->where('id_surat_keluar', $id)->first();
        
        return view('template/headerTemplate', $data)
            .view('home/viewsuratkeluar')
            .view('template/footerTemplate');
    }

    public function editsuratkeluar()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id = $this->request->getGet('id');
        $suratkeluarModel = new SuratKeluarModel();
        $data['surat_keluar'] = $suratkeluarModel->where('id_surat_keluar', $id)->first();
        
        return view('template/headerTemplate', $data)
            .view('home/editsuratkeluar')
            .view('template/footerTemplate');
    }

    public function updatesuratkeluar()
    {
        $suratkeluarModel = new SuratKeluarModel();

        $id_sk = $this->request->getPost('id_surat_keluar');
        $data = [
            'nomor_surat' => $this->request->getPost('nomor_surat'),
            'tanggal_surat' => $this->request->getPost('tanggal_surat'),
            'tujuan_surat' => $this->request->getPost('tujuan_surat'),
            'perihal' => $this->request->getPost('perihal'),
            'keterangan' => $this->request->getPost('keterangan')
        ];

        $suratkeluarModel->update($id_sk, $data);

        return redirect()->to('/admin/suratkeluar')->with('flash', 'Diedit');
    }

    public function deletesuratkeluar()
    {
        $suratkeluarModel = new SuratKeluarModel();

        $id_sm = $this->request->getGet('id');
        $suratkeluarModel->delete($id_sm);

        return redirect()->to('/admin/suratkeluar')->with('flash', 'Dihapus');
    }

    public function inventarisbarang()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        //$id = $this->request->getGet('id');
        $inventarisbarangModel = new InventarisBarangModel();
        $data['inventaris_barang'] = $inventarisbarangModel->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->orderBy('nama_barang')->get()->getResultArray();
        
        return view('template/headerTemplate', $data)
            .view('home/inventarisbarang')
            .view('template/footerTemplate');
    }

    public function ininventarisbarang()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];
        
        return view('template/headerTemplate', $data)
            .view('home/ininventarisbarang')
            .view('template/footerTemplate');
    }

    public function addinventarisbarang()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data = [
            'id_pimpinan' => $pimp,
            'kategori_data' => $kat,
            'index_barang' => $this->request->getPost('index_barang'),
            'nama_barang' => $this->request->getPost('nama_barang'),
            'jumlah' => $this->request->getPost('jumlah'),
            'asal_barang' => $this->request->getPost('asal_barang'),
            'harga_satuan' => $this->request->getPost('harga_satuan'),
            'keterangan' => $this->request->getPost('keterangan')
        ];

        $inventarisBarangModel = new InventarisBarangModel();
        $inventarisBarangModel->insert($data);

        $session->setFlashdata('flash', 'Tersimpan');
        return redirect()->to('/admin/inventarisbarang');
    }

    public function viewinventarisbarang()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id = $this->request->getGet('id');
        $inventarisbarangModel = new InventarisBarangModel();
        $data['inventaris_barang'] = $inventarisbarangModel->where('id_inventaris_barang', $id)->first();
        
        return view('template/headerTemplate', $data)
            .view('home/viewinventarisbarang')
            .view('template/footerTemplate');
    }

    public function editinventarisbarang()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id = $this->request->getGet('id');
        $inventarisbarangModel = new InventarisBarangModel();
        $data['inventaris_barang'] = $inventarisbarangModel->where('id_inventaris_barang', $id)->first();
        
        return view('template/headerTemplate', $data)
            .view('home/editinventarisbarang')
            .view('template/footerTemplate');
    }

    public function updateinventarisbarang()
    {
        $inventarisbarangModel = new InventarisBarangModel();

        $id_ib = $this->request->getPost('id_inventaris_barang');
        $data = [
            'index_barang' => $this->request->getPost('index_barang'),
            'nama_barang' => $this->request->getPost('nama_barang'),
            'jumlah' => $this->request->getPost('jumlah'),
            'asal_barang' => $this->request->getPost('asal_barang'),
            'harga_satuan' => $this->request->getPost('harga_satuan'),
            'keterangan' => $this->request->getPost('keterangan')
        ];

        $inventarisbarangModel->update($id_ib, $data);

        return redirect()->to('/admin/inventarisbarang')->with('flash', 'Diedit');
    }

    public function deleteinventarisbarang()
    {
        $inventarisbarangModel = new InventarisBarangModel();

        $id_ib = $this->request->getGet('id');
        $inventarisbarangModel->delete($id_ib);

        return redirect()->to('/admin/inventarisbarang')->with('flash', 'Dihapus');
    }

    public function keuangan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $keuanganModel = new KeuanganModel();

        $data['keuangan'] = $keuanganModel->where('id_pimpinan', $pimp)
                                            ->where('kategori_data', $kat)
                                            ->orderBy('tanggal_transaksi')
                                            ->findAll();

        $data['masuk'] = $keuanganModel->selectSum('masuk')
                                        ->where('id_pimpinan', $pimp)
                                        ->where('kategori_data', $kat)
                                        ->first();

        $data['keluar'] = $keuanganModel->selectSum('keluar')
                                         ->where('id_pimpinan', $pimp)
                                         ->where('kategori_data', $kat)
                                         ->first();

        return view('template/headerTemplate', $data) .view('home/keuangan') .view('template/footerTemplate');
    }

    public function laporankeuangan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $keuanganModel = new KeuanganModel();

        $data['keuangan'] = $keuanganModel->where('id_pimpinan', $pimp)->where('jenis_transaksi', 'Masuk')
                                            ->where('kategori_data', $kat)
                                            ->orderBy('tanggal_transaksi')
                                            ->findAll();

        $data['keuangan0'] = $keuanganModel->where('id_pimpinan', $pimp)->where('jenis_transaksi', 'Keluar')
        ->where('kategori_data', $kat)
        ->orderBy('tanggal_transaksi')
        ->findAll();

        $data['masuk'] = $keuanganModel->selectSum('masuk')
                                        ->where('id_pimpinan', $pimp)
                                        ->where('kategori_data', $kat)
                                        ->first();

        $data['keluar'] = $keuanganModel->selectSum('keluar')
                                         ->where('id_pimpinan', $pimp)
                                         ->where('kategori_data', $kat)
                                         ->first();

        return view('template/headerTemplate', $data) .view('home/laporankeuangan') .view('template/footerTemplate');
    }

    public function inkeuangan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];
        
        return view('template/headerTemplate', $data)
            .view('home/inkeuangan')
            .view('template/footerTemplate');
    }

    public function addkeuangan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data = [
            'id_pimpinan' => $pimp,
            'kategori_data' => $kat,
            'tanggal_transaksi' => $this->request->getPost('tanggal_transaksi'),
            'nama_barang' => $this->request->getPost('nama_barang'),
            'masuk' => $this->request->getPost('masuk'),
            'keluar' => $this->request->getPost('keluar'),
            'jenis_transaksi' => $this->request->getPost('jenis_transaksi'),
            'keterangan' => $this->request->getPost('keterangan')
        ];

        $keuanganModel = new KeuanganModel();
        $keuanganModel->insert($data);

        $session->setFlashdata('flash', 'Tersimpan');
        return redirect()->to('/admin/keuangan');
    }

    public function viewkeuangan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id = $this->request->getGet('id');
        $keuanganModel = new KeuanganModel();
        $data['keuangan'] = $keuanganModel->where('id_keuangan', $id)->first();
        
        return view('template/headerTemplate', $data)
            .view('home/viewkeuangan')
            .view('template/footerTemplate');
    }

    public function editkeuangan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id = $this->request->getGet('id');
        $keuanganModel = new KeuanganModel();
        $data['keuangan'] = $keuanganModel->where('id_keuangan', $id)->first();
        
        return view('template/headerTemplate', $data)
            .view('home/editkeuangan')
            .view('template/footerTemplate');
    }

    public function updatekeuangan()
    {
        $keuanganModel = new KeuanganModel();

        $id_keu = $this->request->getPost('id_keuangan');
        $data = [
            'tanggal_transaksi' => $this->request->getPost('tanggal_transaksi'),
            'masuk' => $this->request->getPost('masuk'),
            'keluar' => $this->request->getPost('keluar'),
            'jenis_transaksi' => $this->request->getPost('jenis_transaksi'),
            'keterangan' => $this->request->getPost('keterangan')
        ];

        $keuanganModel->update($id_keu, $data);

        return redirect()->to('/admin/keuangan')->with('flash', 'Diedit');
    }

    public function deletekeuangan()
    {
        $keuanganModel = new KeuanganModel();

        $id_keu = $this->request->getGet('id');
        $keuanganModel->delete($id_keu);

        return redirect()->to('/admin/keuangan')->with('flash', 'Dihapus');
    }

    public function daftarkegiatan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $daftarkegiatanModel = new DaftarKegiatanModel();
        $data['daftar_kegiatan'] = $daftarkegiatanModel->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->orderBy('tanggal')->get()->getResultArray();
        $daftar_kegiatan = $data['daftar_kegiatan'];

        return view('template/headerTemplate', $data) .view('home/daftarkegiatan') .view('template/footerTemplate');
    }

    public function indaftarkegiatan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];
        
        return view('template/headerTemplate', $data)
            .view('home/indaftarkegiatan')
            .view('template/footerTemplate');
    }

    public function adddaftarkegiatan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $daftarKegiatanModel = new DaftarKegiatanModel();

        $uploadPath = './upload/lpj/';
        $allowedTypes = 'jpeg|jpg|png';
        $uploadConfig = [
            'upload_path' => $uploadPath,
            'allowed_types' => $allowedTypes
        ];

        $request = service('request');

        // Ambil file upload
        $fileSurat = $request->getFile('browsur');

        // Validasi upload
        if ($fileSurat->isValid() && !$fileSurat->hasMoved()) {
            // Pindahkan file upload ke folder upload
            $newName = $fileSurat->getRandomName();
            $fileSurat->move($uploadPath, $newName);

            // Data untuk dimasukkan ke database
            $dataInsert = [
                'id_pimpinan' => $pimp,
                'kategori_data' => $kat,
                'nama_kegiatan' => $this->request->getPost('nama_kegiatan'),
                'hari' => $this->request->getPost('hari'),
                'tanggal' => $this->request->getPost('tanggal'),
                'waktu' => $this->request->getPost('waktu'),
                'kategori_kegiatan' => $this->request->getPost('kategori_kegiatan'),
                'pelaksana_kegiatan' => $this->request->getPost('pelaksana_kegiatan'),
                'tempat' => $this->request->getPost('tempat'),
                'informasi' => $this->request->getPost('informasi'),
                'browsur' => $newName
            ];

            // Masukkan data ke database
            $db = db_connect();
            $db->table('daftar_kegiatan')->insert($dataInsert);

            // Set flashdata dan redirect
            $session->setFlashdata('flash', 'Tersimpan');
            return redirect()->to('admin/daftarkegiatan');
        } else {
            // Jika file upload tidak valid, kembali ke halaman sebelumnya
            return redirect()->back()->withInput()->with('error', 'File tidak valid.');
        }
    }

    public function editdaftarkegiatan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id = $this->request->getGet('id');
        $daftarkegiatannModel = new DaftarKegiatanModel();
        $data['daftar_kegiatan'] = $daftarkegiatanModel->where('id_daftar_kegiatan', $id)->first();
        
        return view('template/headerTemplate', $data)
            .view('home/editdaftarkegiatan')
            .view('template/footerTemplate');
    }

    public function updatedaftarkegiatan()
    {
        $daftarkegiatanModel = new DaftarKegiatanModel();

        $id_dk = $this->request->getPost('id_daftar_kegiatan');
        $data = [
            'nama_kegiatan' => $this->request->getPost('nama_kegiatan'),
            'hari' => $this->request->getPost('hari'),
            'tanggal' => $this->request->getPost('tanggal'),
            'waktu' => $this->request->getPost('waktu'),
            'kategori_kegiatan' => $this->request->getPost('kategori_kegiatan'),
            'pelaksana_kegiatan' => $this->request->getPost('pelaksana_kegiatan'),
            'tempat' => $this->request->getPost('tempat'),
            //'keterangan' => $this->request->getPost('keterangan')
        ];

        $daftarkegiatanModel->update($id_dk, $data);

        return redirect()->to('/admin/daftarkegiatan')->with('flash', 'Diedit');
    }

    public function viewdaftarkegiatan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id = $this->request->getGet('id');
        $daftarkegiatanModel = new DaftarKegiatanModel();
        $data['daftar_kegiatan'] = $daftarkegiatanModel->where('id_daftar_kegiatan', $id)->first();
        
        return view('template/headerTemplate', $data)
            .view('home/viewdaftarkegiatan')
            .view('template/footerTemplate');
    }

    public function deletedaftarkegiatan()
    {
        $daftarkegiatanModel = new DaftarKegiatanModel();

        $id_dk = $this->request->getGet('id');
        $daftarkegiatanModel->delete($id_dk);

        return redirect()->to('/admin/daftarkegiatan')->with('flash', 'Dihapus');
    }

    public function viewdaftarpeserta()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];
        $kategori = $session->get('kategori');

        $data['cabang'] = $pimpinanModel->where('kategori_data', $kat)->where('pimpinan', 'PC')->orderBy('kd_pimpinan')->get()->getResultArray();
        $cabang = $data['cabang'];

        $data['get_pc'] = $pimpinanModel->where('id_pimpinan', $this->request->getGet('id'))->get()->getRowArray();
        $get_pc = $data['get_pc'];

        $anggotaModel = new AnggotaModel();
        $data['anggota'] = $anggotaModel->select('*')->join('pimpinan_ac', 'id_pimpinan_ac')->where('anggota.id_pimpinan', $this->request->getGet('id'))->orderBy('id_anggota')->get()->getResultArray();
        $anggota = $data['anggota'];

        $data['jumlah'] = $anggotaModel
                        ->where('id_pimpinan', 'PM615052')
                        ->countAllResults();
        $jumlah = $data['jumlah'];

        // Mengambil data daftar kegiatan berdasarkan id
        $datapendaftarModel = new DataPendaftarModel();
        $daftarkegiatanModel = new DaftarKegiatanModel();

        $id = $this->request->getGet('id');
        $data['daftar_kegiatan'] = $daftarkegiatanModel->where('id_daftar_kegiatan', $id)->first();
        $daftar_kegiatan = $data['daftar_kegiatan'];

        // Mengambil data peserta dengan join tabel anggota dan daftar_kegiatan
        $data['data_peserta'] = $datapendaftarModel
                        ->select('*')
                        ->join('anggota', 'id_anggota')
                        ->join('daftar_kegiatan as dk', 'dk.id_daftar_kegiatan = data_pendaftar.id_daftar_kegiatan')
                        ->where('dk.id_daftar_kegiatan', $id)
                        ->where('data_pendaftar.kategori_data', $kat)
                        ->orderBy('anggota.nama')
                        ->get()
                        ->getResultArray();
        $data_peserta = $data['data_peserta'];

        return view('template/headerTemplate', $data) .
            view('home/viewdaftarpeserta') .
            view('template/footerTemplate');
    }

    public function updatekelulusan()
    {
        // Ambil data dari formulir
        $id_peserta = $this->request->getPost('id');
        //$status = $this->request->getPost('status');
        $id_daftar_kegiatan = $this->request->getPost('id_daftar_kegiatan');
        
        // Inisialisasi model
        $datapendaftarModel = new DataPendaftarModel();
        
        // Siapkan data yang akan diupdate
        $state = [
            'status' => $this->request->getPost('status'),
            'id_daftar_kegiatan' => $this->request->getPost('id_daftar_kegiatan')
        ];

        $datapendaftarModel->update($id_peserta, $state);

        // Lakukan pembaruan dengan menggunakan klausa where
        //$datapendaftarModel->where('id_peserta', $id_peserta)->update($data);

        // Redirect atau tampilkan pesan sukses
        return redirect()->to('admin/viewdaftarpeserta?id=' . $id_daftar_kegiatan)->with('flash', 'Diedit');
    }

    public function updatekelulusan1()
    {
        // Ambil data dari formulir
        $id_peserta = $this->request->getPost('id');
        //$status = $this->request->getPost('status');
        $id_daftar_kegiatan = $this->request->getPost('id_daftar_kegiatan');
        
        // Inisialisasi model
        $datapendaftarModel = new DataPendaftarModel();
        
        // Siapkan data yang akan diupdate
        $state = [
            'status' => $this->request->getPost('status'),
            'id_daftar_kegiatan' => $this->request->getPost('id_daftar_kegiatan')
        ];

        $datapendaftarModel->update($id_peserta, $state);

        // Lakukan pembaruan dengan menggunakan klausa where
        //$datapendaftarModel->where('id_peserta', $id_peserta)->update($data);

        // Redirect atau tampilkan pesan sukses
        return redirect()->to('admin/viewdaftarpeserta?id=' . $id_daftar_kegiatan)->with('flash', 'Diedit');
    }

    public function perpustakaan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $perpustakaanModel = new PerpustakaanModel();
        $data['perpustakaan'] = $perpustakaanModel->where('kategori_data', $kat)->orderBy('nama_materi')->get()->getResultArray();
        $perpustakaan = $data['perpustakaan'];

        return view('template/headerTemplate', $data) .view('home/perpustakaan') .view('template/footerTemplate');
    }

    public function inperpustakaan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];
        
        return view('template/headerTemplate', $data)
            .view('home/inperpustakaan')
            .view('template/footerTemplate');
    }

    public function addperpustakaan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $request = $this->request;

        $validationRules = [
            'nama_materi' => 'required',
            'kategori_materi' => 'required',
            'materi' => 'uploaded[materi]|mime_in[materi,application/pdf]|max_size[materi,2048]'
        ];

        if (!$this->validate($validationRules)) {
            return redirect()->back()->withInput()->with('validation', $this->validator);
        }

        $materiFile = $request->getFile('materi');

        if ($materiFile->isValid() && !$materiFile->hasMoved()) {
            $materiName = $materiFile->getRandomName();
            $materiFile->move('./upload/materi', $materiName);

            $perpustakaanModel = new PerpustakaanModel();
            $data = [
                'kategori_data' => $kat,
                'nama_materi' => $request->getPost('nama_materi'),
                'kategori_materi' => $request->getPost('kategori_materi'),
                'materi' => $materiName
            ];

            $perpustakaanModel->insert($data);

            // Set flash data untuk pesan sukses
            session()->setFlashdata('flash', 'Tersimpan');

            // Redirect ke halaman perpustakaan
            return redirect()->to(base_url('admin/perpustakaan'));
        } else {
            // Handle error jika file tidak valid
            return redirect()->back()->withInput()->with('error', 'File materi tidak valid.');
        }
    }

    public function deleteperpustakaan()
    {
        $perpustakaanModel = new PerpustakaanModel();

        $id_p = $this->request->getGet('id');
        $perpustakaanModel->delete($id_p);

        return redirect()->to('/admin/perpustakaan')->with('flash', 'Dihapus');
    }

    public function dataalumni()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $anggotaModel = new AnggotaModel();
        $data['anggota'] = $anggotaModel->join('pimpinan', 'anggota.id_pimpinan = pimpinan.id_pimpinan')->where('anggota.kategori_data', $kat)->where('status_alumni', ['ya'])->orderBy('id_anggota')->findAll();
        $anggota = $data['anggota'];

        return view('template/headerTemplate', $data) .
            view('home/dataalumni') .
            view('template/footerTemplate');

    }

    public function tambahdataalumni()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $anggotaModel = new AnggotaModel();
        $data['anggota'] = $anggotaModel->join('pimpinan', 'anggota.id_pimpinan = pimpinan.id_pimpinan')->where('anggota.kategori_data', $kat)->orderBy('id_anggota')->findAll();
        $anggota = $data['anggota'];

        return view('template/headerTemplate', $data) .
            view('home/tambahdataalumni') .
            view('template/footerTemplate');
        
    }

    public function editdataalumni()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        $id_anggota = $this->request->getPost('id');
        $state = [
              'status_alumni' => 'Ya'
        ];

        $model = new AnggotaModel();
        $model->update($id_anggota, $state);

        // $this->session->setFlashdata('flash', 'Diedit');
        return redirect()->to('admin/tambahdataalumni');

    }

    public function statistikcabang()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        // Hitung jumlah anggota
        $anggotaModel = new AnggotaModel();
        $data['surakarta'] = $anggotaModel->where('id_pimpinan', '1')->where('kategori_data', $kat)->countAllResults();
        $data['ksemarang'] = $anggotaModel->where('id_pimpinan', '2')->where('kategori_data', $kat)->countAllResults();
        $data['kendal'] = $anggotaModel->where('id_pimpinan', '3')->where('kategori_data', $kat)->countAllResults();
        $data['lasem'] = $anggotaModel->where('id_pimpinan', '4')->where('kategori_data', $kat)->countAllResults();
        $data['cilacap'] = $anggotaModel->where('id_pimpinan', '5')->where('kategori_data', $kat)->countAllResults();
        $data['jepara'] = $anggotaModel->where('id_pimpinan', '6')->where('kategori_data', $kat)->countAllResults();
        $data['purbalingga'] = $anggotaModel->where('id_pimpinan', '7')->where('kategori_data', $kat)->countAllResults();
        $data['blora'] = $anggotaModel->where('id_pimpinan', '8')->where('kategori_data', $kat)->countAllResults();
        $data['semarang'] = $anggotaModel->where('id_pimpinan', '9')->where('kategori_data', $kat)->countAllResults();
        $data['sragen'] = $anggotaModel->where('id_pimpinan', '10')->where('kategori_data', $kat)->countAllResults();
        $data['sukoharjo'] = $anggotaModel->where('id_pimpinan', '11')->where('kategori_data', $kat)->countAllResults();
        $data['klaten'] = $anggotaModel->where('id_pimpinan', '12')->where('kategori_data', $kat)->countAllResults();
        $data['kmagelang'] = $anggotaModel->where('id_pimpinan', '13')->where('kategori_data', $kat)->countAllResults();
        $data['magelang'] = $anggotaModel->where('id_pimpinan', '14')->where('kategori_data', $kat)->countAllResults();
        $data['pati'] = $anggotaModel->where('id_pimpinan', '15')->where('kategori_data', $kat)->countAllResults();
        $data['boyolali'] = $anggotaModel->where('id_pimpinan', '16')->where('kategori_data', $kat)->countAllResults();
        $data['ktegal'] = $anggotaModel->where('id_pimpinan', '17')->where('kategori_data', $kat)->countAllResults();
        $data['demak'] = $anggotaModel->where('id_pimpinan', '19')->where('kategori_data', $kat)->countAllResults();
        $data['batang'] = $anggotaModel->where('id_pimpinan', '20')->where('kategori_data', $kat)->countAllResults();
        $data['banyumas'] = $anggotaModel->where('id_pimpinan', '21')->where('kategori_data', $kat)->countAllResults();
        $data['karanganyar'] = $anggotaModel->where('id_pimpinan', '22')->where('kategori_data', $kat)->countAllResults();
        $data['wonogiri'] = $anggotaModel->where('id_pimpinan', '23')->where('kategori_data', $kat)->countAllResults();
        $data['brebes'] = $anggotaModel->where('id_pimpinan', '24')->where('kategori_data', $kat)->countAllResults();
        $data['pemalang'] = $anggotaModel->where('id_pimpinan', '25')->where('kategori_data', $kat)->countAllResults();
        $data['rembang'] = $anggotaModel->where('id_pimpinan', '26')->where('kategori_data', $kat)->countAllResults();
        $data['purworejo'] = $anggotaModel->where('id_pimpinan', '27')->where('kategori_data', $kat)->countAllResults();
        $data['wonosobo'] = $anggotaModel->where('id_pimpinan', '28')->where('kategori_data', $kat)->countAllResults();
        $data['kudus'] = $anggotaModel->where('id_pimpinan', '29')->where('kategori_data', $kat)->countAllResults();
        $data['grobogan'] = $anggotaModel->where('id_pimpinan', '30')->where('kategori_data', $kat)->countAllResults();
        $data['kebumen'] = $anggotaModel->where('id_pimpinan', '31')->where('kategori_data', $kat)->countAllResults();
        $data['temanggung'] = $anggotaModel->where('id_pimpinan', '32')->where('kategori_data', $kat)->countAllResults();
        $data['tegal'] = $anggotaModel->where('id_pimpinan', '33')->where('kategori_data', $kat)->countAllResults();
        $data['banjarnegara'] = $anggotaModel->where('id_pimpinan', '34')->where('kategori_data', $kat)->countAllResults();
        $data['salatiga'] = $anggotaModel->where('id_pimpinan', '35')->where('kategori_data', $kat)->countAllResults();
        $data['kpekalongan'] = $anggotaModel->where('id_pimpinan', '36')->where('kategori_data', $kat)->countAllResults();
        $data['pekalongan'] = $anggotaModel->where('id_pimpinan', '37')->where('kategori_data', $kat)->countAllResults();

        return view('template/headerTemplate', $data) . view('home/statistikcabang') . view('template/footerTemplate');
    }

    public function profilpimpinancabang()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        // Ambil data pimpinan dengan kategori 'PC' dan kategori_data sesuai dengan session
        $data['pimpinan'] = $pimpinanModel->where('pimpinan', 'PC')
                                ->where('kategori_data', $kat)
                                ->orderBy('kd_pimpinan')
                                ->findAll();
        
        $pimpinan = $data['pimpinan'];

        return view('template/headerTemplate', $data) . view('home/profilpimpinancabang') . view('template/footerTemplate');
      
    }

    public function profilpc()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id_pc = $this->request->getPost('19');

        $pengaturanpimpinanModel = new PengaturanPimpinanModel();
        // if ($tingkatan === 'PW') {
        //     $data['aplikasi'] = $pengaturanpimpinanModel->join('pimpinan', 'id_pimpinan')->where('id_pimpinan', $pimp)->first();;
        //     $aplikasi = $data['aplikasi'];
        // } elseif ($tingkatan === 'PC') {
            $data['aplikasi'] = $pengaturanpimpinanModel->where('id_pimpinan', $id_pc)->first();;
            $aplikasi = $data['aplikasi'];
        // } elseif ($tingkatan === 'PAC') {
        //     $data['pac'] = $pimpinanacModel->where('id_pimpinan_ac', $session->get('id_pimpinan'))->first();
        //     $data['aplikasi'] = $pengaturanpimpinanModel->where('id_pimpinan', $pimp)->first();
        // }
        // ->join('pimpinan', 'anggota.id_pimpinan = pimpinan.id_pimpinan')->where('anggota.kategori_data', $kat)
        // if ($tingkatan === 'PW') {
            return view('template/headerTemplate', $data) .
            view('home/profilpc') .
            view('template/footerTemplate');
        // } elseif ($tingkatan === 'PC') {
        //     return view('template/headerUser', $data) .
        //     view('operator/aplikasi') .
        //     view('template/footerUser');
        // } else {
        //     // Jika status akun tidak valid, mungkin redirect ke halaman error atau tampilkan pesan kesalahan
        //     return 'Invalid role';
        // }

        //return view('template/headerTemplate', $data) . view('home/aplikasi') . view('template/footerTemplate');
    }

    public function createKTA()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        // Ambil data anggota dari database (contoh)
        $data['anggota'] = [
            'nama' => 'John Doe',
            'nik' => '1234567890',
            'alamat' => 'Jalan Contoh No. 123',
            // tambahkan data anggota lainnya sesuai kebutuhan
        ];

        return view('home/kta', $data);
    }

    public function saveKTA()
    {
        // Proses penyimpanan KTA ke database (jika diperlukan)
        // ...

        return redirect()->to('/admin/createKTA')->with('success', 'KTA berhasil disimpan.');
    }

    public function cetakktaipnu()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $anggotaModel = new AnggotaModel();
        $pengaturanpimpinanModel = new PengaturanPimpinanModel();

        $id1 = $this->request->getPost('id');
        $id2 = $this->request->getPost('id2');
        $id_pimpinan = $this->request->getPost('id_pimpinan');

        $data['anggota'] = $anggotaModel->find($this->request->getGet('id'));
        $data['cabang'] = $pimpinanModel->find($this->request->getGet('id2'));
        // $aktif = $this->request->get('aktif');

        if ($tingkatan === 'PW'){
            $data['setting_app'] = $pengaturanpimpinanModel->where('id_pimpinan', '18')->get()->getRowArray();
        } else {
            $data['setting_app'] = $pengaturanpimpinanModel->where('id_pimpinan', $id_pimpinan)->get()->getRowArray();
        }

        return view('home/kta', $data);
    }

    private function isLoggedIn()
    {
        // Ambil instance session
        $session = session();

        // Periksa apakah data sesi yang menandakan pengguna sudah login ada
        return $session->has('logged_in') && $session->get('logged_in') === true;
    }
}
