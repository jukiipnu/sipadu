<?php
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\UserModel;
use App\Models\PimpinanModel;
use App\Models\PimpinanAcModel;
use App\Models\PimpinanRkModel;
use App\Models\AnggotaModel;
use App\Models\KeuanganModel;
use App\Models\SuratMasukModel;
use App\Models\SuratKeluarModel;
use App\Models\InventarisBarangModel;
use App\Models\PengaturanPimpinanModel;
use App\Models\DaftarKegiatanModel;
use App\Models\DataPendaftarModel;
use App\Models\PerpustakaanModel;

class Rumah extends Controller
{
    public function aplikasi()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session()->get('id_pimpinan'))->first();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', $pimp)->first();        

        $pengaturanpimpinanModel = new PengaturanPimpinanModel();
        $data['prr'] = $pimpinanrkModel->where('id_pimpinan_rk', $session->get('id_pimpinan'))->first();
        $data['aplikasi'] = $pengaturanpimpinanModel->where('id_pimpinan', $pimp)->first();


       // if ($tingkatan === 'PR') {
            
            // $data['aplikasi'] = $pengaturanpimpinanModel->join('pimpinan', 'id_pimpinan')->where('id_pimpinan', $pimp)->first();
            // $aplikasi = $data['aplikasi'];
        // } elseif ($tingkatan === 'PK') {
        //     $data['pac'] = $pimpinanacModel->where('id_pimpinan_ac', $session->get('id_pimpinan'))->first();
        //     $data['aplikasi'] = $pengaturanpimpinanModel->where('id_pimpinan', $pimp)->first();
        // }
        
        // $data['aplikasi'] = $pengaturanpimpinanModel->join('pimpinan', 'id_pimpinan')->where('id_pimpinan', $pimp)->first();;
        // $aplikasi = $data['aplikasi'];

        return view('template/headerKelurahan', $data) . view('desa/aplikasi') . view('template/footerKelurahan');
    }

    public function editaplikasi_text()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('pac');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];
        
        $pengaturanpimpinanModel = new PengaturanPimpinanModel();

        //if ($tingkatan === 'PR') {
            $data['prr'] = $pimpinanrkModel->where('id_pimpinan_rk', $session->get('id_pimpinan'))->first();
            $data['aplikasi'] = $pengaturanpimpinanModel->where('id_pimpinan', $pimp)->first();
       // } elseif ($tingkatan === 'PK') {
           // $data['pac'] = $pimpinanacModel->where('id_pimpinan_ac', $session->get('id_pimpinan'))->first();
          //  $data['aplikasi'] = $pengaturanpimpinanModel->where('id_pimpinan', $pimp)->first();
       // }

        return view('template/headerKelurahan', $data) . view('desa/editaplikasi_text') . view('template/footerKelurahan');
    }

    public function updateaplikasi_text()
    {
        $id_pengaturan = $this->request->getPost('id');
        $kolom = $this->request->getPost('kolom');
        $namakolom = $this->request->getPost('namakolom');

        $model = new PengaturanPimpinanModel();

        $data = [
            $namakolom => $kolom
        ];

        $model->where('id_pengaturan_pimpinan', $id_pengaturan)
            ->set($data)
            ->update();

        $session = session();
        //$session->setFlashdata('flash', 'Diedit');

        return redirect()->to('rumah/aplikasi');
    }

    public function editaplikasi_foto()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('pac');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];
        
        $pengaturanpimpinanModel = new PengaturanPimpinanModel();

        //if ($tingkatan === 'PC') {
        //    $data['aplikasi'] = $pengaturanpimpinanModel->join('pimpinan', 'id_pimpinan')->where('id_pimpinan', $pimp)->first();
       //     $aplikasi = $data['aplikasi'];
        //} elseif ($tingkatan === 'PAC') {
            $data['prr'] = $pimpinanrkModel->where('id_pimpinan_rk', $session->get('id_pimpinan'))->first();
            $data['aplikasi'] = $pengaturanpimpinanModel->where('id_pimpinan', $pimp)->first();
       // }

        return view('template/headerKelurahan', $data) . view('desa/editaplikasi_foto') . view('template/footerKelurahan');
    }

    public function updateaplikasi_foto()
    {
        $id_pengaturan = $this->request->getPost('id');
        $kolom = $this->request->getPost('kolom');
        $namakolom = $this->request->getPost('namakolom');

        $config['upload_path'] = './upload/setting-app/';
        $config['allowed_types'] = 'jpg|png';

        $upload = $this->request->getFile($namakolom);
        $upload->move('./upload/setting-app/', $upload->getName());

        $model = new PengaturanPimpinanModel();

        $data = [
            $namakolom => $upload->getName()
        ];

        $model->where('id_pengaturan_pimpinan', $id_pengaturan)
            ->set($data)
            ->update();

        $session = session();
        //$session->setFlashdata('flash', 'Diedit');

        return redirect()->to('rumah/aplikasi');
    }

    public function editaplikasi_dokumen()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('pac');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];
        
        $pengaturanpimpinanModel = new PengaturanPimpinanModel();

        //if ($tingkatan === 'PC') {
         //   $data['aplikasi'] = $pengaturanpimpinanModel->join('pimpinan', 'id_pimpinan')->where('id_pimpinan', $pimp)->first();
         //   $aplikasi = $data['aplikasi'];
       // } elseif ($tingkatan === 'PAC') {
            $data['prr'] = $pimpinanrkModel->where('id_pimpinan_rk', $session->get('id_pimpinan'))->first();
            $data['aplikasi'] = $pengaturanpimpinanModel->where('id_pimpinan', $pimp)->first();
       // }

        return view('template/headerKelurahan', $data) . view('desa/editaplikasi_dokumen') . view('template/footerKelurahan');
    }

    public function updateaplikasi_dokumen()
    {
        $id_pengaturan = $this->request->getPost('id');
        $kolom = $this->request->getPost('kolom');
        $namakolom = $this->request->getPost('namakolom');

        // Konfigurasi upload
        $config = [
            'upload_path' => './upload/setting-app/',
            'allowed_types' => 'pdf'
        ];

        // Memuat library Upload dengan konfigurasi
        $upload = \Config\Services::upload($config);

        // Mengambil file yang diupload
        $file = $this->request->getFile($namakolom);

        // Lakukan proses upload
        if ($file->isValid() && !$file->hasMoved()) {
            // Pindahkan file ke lokasi yang ditentukan
            $file->move($config['upload_path']);

            // Dapatkan nama file yang diupload
            $name = $file->getName();

            // Persiapkan model untuk update
            $model = new PengaturanPimpinanModel();

            // Data yang akan diupdate
            $data = [
                $namakolom => $name
            ];

            // Lakukan update ke database
            $model->update($id_pengaturan, $data);

            // Atur pesan flash
            session()->setFlashdata('flash', 'Diedit');

            // Redirect ke halaman aplikasi
            return redirect()->to('rumah/aplikasi');
        } else {
            // Jika upload gagal, tangani kesalahan
            $errors = $file->getErrorString();
            return redirect()->back()->with('errors', $errors);
        }
    }

    public function edituser()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('pac');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id_user = $this->request->getGet('id');
        //$data['pimpinan_cabang'] = $pimpinanModel->find($id_pimpinan);

        //$pimpinanAcModel = new PimpinanAcModel();
        //$pimpinanRkModel = new PimpinanRkModel();
        //$anggotaModel = new AnggotaModel();
        // Ambil data pimpinan dengan kategori 'PR' dan kategori_data sesuai dengan session
        $data['user'] = $userModel->where('id_pimpinan', $pimp)->first();
                                //->where('id_user', $pimp)
                                //->where('kategori_user', $kat)
                                //->orderBy('email')
                               // ->first();
        
        $user = $data['user'];
        //$encryptedPassword = $userData['encrypted_password'];

        //$data['user_data'] = $userModel->select('password')->where('id_user', $id_user)->get()->getRow();
        //$userData = $data['user_data'];
        //return view('encrypted_password', ['encryptedPassword' => $userData->password]);

        return view('template/headerKelurahan', $data) . view('desa/edituser') . view('template/footerKelurahan');
    }

    public function updateuser()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('pac');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id_user = $this->request->getPost('id_user');
        $id_pimpinan = $this->request->getPost('id_pimpinan');
        $password = $this->request->getPost('password');
        $username = $this->request->getPost('username');
        $email = $this->request->getPost('email');
        $nama_lengkap = $this->request->getPost('nama_lengkap');
        $no_telpon = $this->request->getPost('no_telpon');
        $sekretariat = $this->request->getPost('sekretariat');

        // Lakukan pengecekan apakah ada perubahan pada password
        $encryptedPassword = password_hash($password, PASSWORD_DEFAULT);

        $userModel = new UserModel();
        $userModel->update($id_user, [
            'username' => $username,
            'email' => $email,
            'password' => $encryptedPassword,
            'nama_lengkap' => $nama_lengkap,
            'no_telpon' => $no_telpon,
            'sekretariat' => $sekretariat,
        ]);

        //$this->session->setFlashdata('flash', 'Diedit');
        return redirect()->to('rumah/edituser');
    }

    public function anggotapr()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['pac'] = $session->get('pac');
        $pac = $data['pac'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['cabang'] = $pimpinanModel->where('kategori_data', $kat)->where('pimpinan', 'PC')->orderBy('kd_pimpinan')->get()->getResultArray();
        $cabang = $data['cabang'];

        //$pimpinanAcModel = new PimpinanAcModel();
        $data['kecamatan'] = $pimpinanacModel->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->where('pimpinan_ac', 'PAC')->orderBy('kd_pimpinan_ac')->findAll();
        $kecamatan = $data['kecamatan'];

        $pac = $this->request->getGet('id2');

        $data['ac'] = $pimpinanacModel->where('id_pimpinan_ac', $pac)->first();

        $data['get_pc'] = $pimpinanModel->where('id_pimpinan', $this->request->getGet('id'))->get()->getRowArray();
        $get_pc = $data['get_pc'];

        $data['get_pac'] = $pimpinanacModel->where('id_pimpinan_ac', $this->request->getGet('id2'))->get()->getRowArray();
        $get_pac = $data['get_pac'];

        //$pimpinanRkModel = new PimpinanRkModel();
        $data['pr'] = $pimpinanrkModel->where('kategori_data', $kat)->where('pimpinan_rk', 'PR')->orderBy('kd_pimpinan_rk')->findAll();
        $pr = $data['pr'];

        $data['pr1'] = $pimpinanrkModel->where('id_pimpinan_ac', $this->request->getGet('id2'))->where('kategori_data', $kat)->where('pimpinan_rk', 'PR')->orderBy('kd_pimpinan_rk')->findAll();
        $pr1 = $data['pr1'];

        $data['get_pr'] = $pimpinanrkModel->where('id_pimpinan_rk', $this->request->getGet('id3'))->get()->getRowArray();
        $get_pr = $data['get_pr'];

        $anggotaModel = new AnggotaModel();
        $data['anggota'] = $anggotaModel->select('*')->join('pimpinan_ac', 'id_pimpinan_ac')->join('pimpinan_rk', 'id_pimpinan_rk')->where('anggota.id_pimpinan_rk', $pimp)->where('anggota.id_pimpinan_ac', $this->request->getGet('id2'))->where('anggota.id_pimpinan_rk', $this->request->getGet('id3'))->orderBy('id_anggota')->whereNotIn('aktif_kepengurusan', ['PW'])->get()->getResultArray();
        $anggota = $data['anggota'];

        return view('template/headerKelurahan', $data) . view('desa/anggotapr') . view('template/footerKelurahan');
    }

    public function inanggota()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('kec');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['id_pimpinan_ac'] = $session->get('id_pimpinan_ac');
        $pimp_ac = $data['id_pimpinan_ac'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id = $this->request->getGet('id'); // Menggunakan $this->request untuk mengakses data yang dikirimkan melalui request

        $data['cabang'] = $pimpinanModel->where('id_pimpinan', $ket)->where('kategori_data', $kat)->where('pimpinan', 'PC')->orderBy('kd_pimpinan')->get()->getResultArray();
        $cabang = $data['cabang'];

        //$pimpinanAcModel = new PimpinanAcModel();

        // if ($tingkatan == 'PC') {
        //     $get_pc = $pimpinanModel->where('id_pimpinan', $pimp)->first();
        //     $data['get_pc'] = $get_pc;

        //     //$pimpinanAcModel = new PimpinanAcModel();
        //     $data['kecamatan'] = $pimpinanAcModel->where('kategori_data', $kat)->where('pimpinan_ac', 'PAC')->orderBy('kd_pimpinan_ac')->findAll();
        //     $kecamatan = $data['kecamatan'];
            
        // } elseif ($tingkatan == 'PAC') {
            $get_pc = $pimpinanModel->where('id_pimpinan', $ket)->first();
            $data['get_pc'] = $get_pc;

            //$pimpinanAcModel = new PimpinanAcModel();
            $data['kecamatan'] = $pimpinanacModel->where('kategori_data', $kat)->where('pimpinan_ac', 'PAC')->orderBy('kd_pimpinan_ac')->findAll();
            $kecamatan = $data['kecamatan'];
        //}

        

       // $pimpinanRkModel = new PimpinanRkModel();
        $data['ranting'] = $pimpinanrkModel->where('id_pimpinan_rk', $pimp)->where('kategori_data', $kat)->orderBy('nama_pimpinan_rk')->findAll();
        $pk = $data['ranting'];

        $anggotaModel = new AnggotaModel();
        //$data['anggota'] = $anggotaModel->select('*')->join('pimpinan_ac', 'id_pimpinan_ac')->join('pimpinan_rk', 'id_pimpinan_rk')->where('anggota.id_pimpinan', $this->request->getGet('id'))->where('anggota.id_pimpinan_ac', $this->request->getGet('id2'))->where('anggota.id_pimpinan_rk', $this->request->getGet('id3'))->orderBy('id_anggota')->whereNotIn('aktif_kepengurusan', ['PW'])->get()->getResultArray();
        //$anggota = $data['anggota'];
        $data['anggota'] = $anggotaModel->where('kategori_data', $kat)->countAllResults();


        $jumlah = $anggotaModel->where('id_pimpinan', $id)->countAllResults(); // Menggunakan model untuk melakukan query


        return view('template/headerKelurahan', $data) . view('desa/inanggota') . view('template/footerKelurahan');
    }

    public function addanggota()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }
        $this->pimpinanRkModel = new PimpinanRkModel();
        $request = service('request');
        $id = $request->getGet('id');
        $model = new AnggotaModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];
        $pimpinanRkModel = new PimpinanRkModel();
        $data['pimpinanRkModel'] = $pimpinanRkModel->where('kategori_data', $kat)->orderBy('nama_pimpinan_rk')->findAll();
        $pimpinanRkModel = $data['pimpinanRkModel'];
        

        $validationRules = [
            'nik' => 'is_unique[anggota.nik]',
            'email' => 'is_unique[anggota.email]'
        ];

        // Validasi input
        if (!$this->validate($validationRules)) {
            $idPimpinan = $request->getPost('id_pimpinan');
            $idPimpinanAc = $request->getPost('id_pimpinan_ac');
            $session = \Config\Services::session();


            //$this->session->setFlashdata('flash', 'Terpakai');
            //$this->session->setFlashdata('pesan', 'Data Telah Digunakan');
            //$pesan = $this->session->getFlashdata('pesan');

           // $this->session->setFlashdata('pesan', 'Data Telah Digunakan');

                return redirect()->to('rumah/inanggota');
        } else {
            // Lakukan proses insert data anggota
            $idPimpinan = $request->getPost('id_pimpinan');
            $data['jumlah'] = $model->where('id_pimpinan', $idPimpinan)->countAllResults();

            $jumlah = $data['jumlah'];
            $nia = $jumlah + 1;
            $niaurut = str_pad($nia, 5, "0", STR_PAD_LEFT);

            $pw = $this->request->getPost('pw');

            // $rkpost = $this->request->getPost('id_pimpinan_rk');
            // $A = $pimpinanRkModel->getByPimpinanRkId($rkpost);
            // $idP1 = $A['kd_pimpinan_rk'];

            // $acpost = $this->request->getPost('id_pimpinan_ac');
            // $B = $this->db->table('pimpinan_ac')->where('id_pimpinan_ac', $acpost)->get()->getRowArray();
            // $idP2 = $B['kd_pimpinan_ac'];

            $pcpost = $this->request->getPost('id_pimpinan');

            // Mengakses data dari tabel pimpinan menggunakan model
            $pimpinanModel = new PimpinanModel();
            $C = $pimpinanModel->where('id_pimpinan', $pcpost)->first();

            // Mendapatkan kd_pimpinan dari hasil query
            $pc = $C['kd_pimpinan'];


            $tgl_masuk = $this->request->getPost('tanggal_masuk');
            $th = substr($tgl_masuk, 2, 2);

            $tgl_lahir = $this->request->getPost('tanggal_lahir');
            $th_lahir = substr($tgl_lahir, 2, 2);

            $nia_jadi = $pw . '.' . $pc . '.' . $th_lahir . '.' . $niaurut;

            // $upload = $this->request->getFile('foto');
            // if ($upload->isValid() && !$upload->hasMoved()) {
            //     $upload->move('./upload/anggota/');
            //     $name = $upload->getName();
            // }

            //$datanonformal = implode(", ", $this->request->getPost('pelatihan_nonformal'));


            $data = [
                'nia' => $nia_jadi,
                'nama' => $request->getPost('nama'),
                'nik' => $request->getPost('nik'),
                'kategori_data' => $request->getPost('kategori_data'),
                'tempat_lahir' => $request->getPost('tempat_lahir'),
                'tanggal_lahir' => $request->getPost('tanggal_lahir'),
                'alamat_lengkap' => $request->getPost('alamat_lengkap'),
                'id_pw' => '18',
                'id_pimpinan' => $request->getPost('id_pimpinan'),
                'id_pimpinan_ac' => $request->getPost('id_pimpinan_ac'),
                'id_pimpinan_rk' => $request->getPost('id_pimpinan_rk'),
                'aktif_kepengurusan' => $request->getPost('aktif_kepengurusan'),
                'pelatihan_formal' => $request->getPost('pelatihan_formal'),
                'makesta' => $request->getPost('makesta'),
                'penyelenggara_makesta' => $request->getPost('penyelenggara_makesta'),
                'tempat_makesta' => $request->getPost('tempat_makesta'),
                'waktu_makesta' => $request->getPost('waktu_makesta'),
                'lakmud' => $request->getPost('lakmud'),
                'penyelenggara_lakmud' => $request->getPost('penyelenggara_lakmud'),
                'tempat_lakmud' => $request->getPost('tempat_lakmud'),
                'waktu_lakmud' => $request->getPost('waktu_lakmud'),
                'lakut' => $request->getPost('lakut'),
                'penyelenggara_lakut' => $request->getPost('penyelenggara_lakut'),
                'tempat_lakut' => $request->getPost('tempat_lakut'),
                'waktu_lakut' => $request->getPost('waktu_lakut'),
                'email' => $request->getPost('email'),
                'password' => '$2y$10$Logj899HwVPyNFXVLpThg.RLf2zlwh9NDGrXg8B2xEAuglbu48NrW',
                'status_verifikasi' => 'belum',
                'status_alumni' => 'Tidak',
                'jabatan' => $request->getPost('jabatan'),
            ];
            
        
        $model->insert($data);

        // Set flashdata untuk notifikasi
        //$this->session->setFlashdata('pesan', 'Data berhasil disimpan');

        return redirect()->to('admin/dashboard');
        }
        
    }

    public function viewanggota()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('kec');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['id_pimpinan_ac'] = $session->get('id_pimpinan_ac');
        $pimp_ac = $data['id_pimpinan_ac'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        // Mendapatkan data anggota berdasarkan id_anggota dari input
        $anggotaModel = new AnggotaModel();
        $data['anggota'] = $anggotaModel->find($this->request->getGet('id'));

        // Menampilkan view dengan data yang telah disiapkan
        return view('template/headerKelurahan', $data) . view('desa/viewanggota') . view('template/footerKelurahan');
    }

    public function editanggota()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('kec');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['cabang'] = $pimpinanModel->where('kategori_data', $kat)->where('pimpinan', 'PC')->orderBy('kd_pimpinan')->get()->getResultArray();
        $cabang = $data['cabang'];

        $pimpinanAcModel = new PimpinanAcModel();
        $data['kecamatan'] = $pimpinanAcModel->where('kategori_data', $kat)->where('pimpinan_ac', 'PAC')->orderBy('kd_pimpinan_ac')->findAll();
        $kecamatan = $data['kecamatan'];

        $pimpinanRkModel = new PimpinanRkModel();
        $data['ranting'] = $pimpinanRkModel->where('kategori_data', $kat)->orderBy('kd_pimpinan_rk')->findAll();
        $ranting = $data['ranting'];

        // Mendapatkan data cabang berdasarkan kategori_data dan pimpinan
        //$data['cabang'] = $pimpinanModel->where('kategori_data', $kat)->where('pimpinan', 'PC')->orderBy('kd_pimpinan')->findAll();

        // Mendapatkan data kecamatan berdasarkan kategori_data dan pimpinan_ac
        //$data['kecamatan'] = $pimpinanAcModel->where('kategori_data', $kat)->where('pimpinan_ac', 'PAC')->orderBy('kd_pimpinan_ac')->findAll();

        // Mendapatkan data ranting berdasarkan kategori_data
        //$data['ranting'] = $pimpinanRkModel->where('kategori_data', $kat)->orderBy('pimpinan_rk')->orderBy('kd_pimpinan_rk')->findAll();

        // Mendapatkan data anggota berdasarkan id_anggota dari input
        $anggotaModel = new AnggotaModel();
        $id_anggota = $this->request->getGet('id');
        $data['anggota'] = $anggotaModel->select('*')->join('pimpinan', 'id_pimpinan')->join('pimpinan_ac', 'id_pimpinan_ac')->join('pimpinan_rk', 'id_pimpinan_rk')->find($id_anggota);
        //$data['anggota'] = $anggotaModel->find($id_anggota);

        // Menampilkan view dengan data yang telah disiapkan
        return view('template/headerKelurahan', $data) . view('desa/editanggota') . view('template/footerKelurahan');
    }

    public function updateanggota()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        $id_anggota = $this->request->getPost('id');
        //$datanonformal = implode(", ",$this->input->post('pelatihan_nonformal'));
        $state = [
            'nia' => $this->request->getPost('nia'),
            'nama' => $this->request->getPost('nama'),
            'nik' => $this->request->getPost('nik'),
            'tempat_lahir' => $this->request->getPost('tempat_lahir'),
            'tanggal_lahir' => $this->request->getPost('tanggal_lahir'),
            'alamat_lengkap' => $this->request->getPost('alamat_lengkap'),
            'nama_ayah' => $this->request->getPost('nama_ayah'),
            'nama_ibu' => $this->request->getPost('nama_ibu'),
            'aktif_kepengurusan' => $this->request->getPost('aktif_kepengurusan'),
            //'id_pimpinan' => $this->request->getPost('id_pimpinan'),
            //'id_pimpinan_ac' => $this->request->getPost('id_pimpinan_ac'),
            'id_pimpinan_rk' => $this->request->getPost('id_pimpinan_rk'),
            'pelatihan_formal' => $this->request->getPost('pelatihan_formal'),
            'makesta' => $this->request->getPost('makesta'),
            'penyelenggara_makesta' => $this->request->getPost('penyelenggara_makesta'),
            'tempat_makesta' => $this->request->getPost('tempat_makesta'),
            'waktu_makesta' => $this->request->getPost('waktu_makesta'),
            'lakmud' => $this->request->getPost('lakmud'),
            'penyelenggara_lakmud' => $this->request->getPost('penyelenggara_lakmud'),
            'tempat_lakmud' => $this->request->getPost('tempat_lakmud'),
            'waktu_lakmud' => $this->request->getPost('waktu_lakmud'),
            'lakut' => $this->request->getPost('lakut'),
            'penyelenggara_lakut' => $this->request->getPost('penyelenggara_lakut'),
            'tempat_lakut' => $this->request->getPost('tempat_lakut'),
            'waktu_lakut' => $this->request->getPost('waktu_lakut'),
            'pelatihan_nonformal' => $this->request->getPost('pelatihan_nonformal'),
            'status_cbp' => $this->request->getPost('status_cbp'),
            'tanggal_masuk' => $this->request->getPost('tanggal_masuk'),
            'pendidikan_terakhir' => $this->request->getPost('pendidikan_terakhir'),
            'pendidikan_sd' => $this->request->getPost('pendidikan_sd'),
            'pendidikan_smp' => $this->request->getPost('pendidikan_smp'),
            'pendidikan_sma' => $this->request->getPost('pendidikan_sma'),
            'pendidikan_pt' => $this->request->getPost('pendidikan_pt'),
            'pendidikan_nonformal' => $this->request->getPost('pendidikan_nonformal'),
            'email' => $this->request->getPost('email'),
            'no_hp' => $this->request->getPost('no_hp'),
            'fb' => $this->request->getPost('fb'),
            'ig' => $this->request->getPost('ig'),
            'jabatan' => $this->request->getPost('jabatan'),
            'bakat' => $this->request->getPost('bakat'),
            'twitter' => $this->request->getPost('twitter'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT)
        ];
        
        $model = new AnggotaModel();
        $model->update($id_anggota, $state);
        
        return redirect()->to('rumah/viewanggota?id=' . $id_anggota)->with('flash', 'Diedit');
        
    }

    public function about()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('kec');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        return view('template/headerKelurahan', $data) . view('desa/about') . view('template/footerKelurahan');
    }

    public function suratmasuk()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('kec');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        //$id_anggota = $this->request->getGet('id'); // Menggunakan method getGet untuk mendapatkan data dari query string
        $suratmasukModel = new SuratMasukModel();
        $data['suratmasuk'] = $suratmasukModel->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->orderBy('tanggal_surat_diterima')->get()->getResultArray();
        $suratmasuk = $data['suratmasuk'];

        return view('template/headerKelurahan', $data) . view('desa/suratmasuk') . view('template/footerKelurahan');
    }

    public function insuratmasuk()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('kec');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        //$id_anggota = $this->request->getGet('id'); // Menggunakan method getGet untuk mendapatkan data dari query string
        // $suratmasukModel = new SuratMasukModel();
        // $data['suratmasuk'] = $suratmasukModel->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->orderBy('tanggal_surat_diterima')->get()->getResultArray();
        // $suratmasuk = $data['suratmasuk'];

        return view('template/headerKelurahan', $data) . view('desa/insuratmasuk') . view('template/footerKelurahan');
    }

    public function addsuratmasuk()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('kec');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        // Konfigurasi upload
        $uploadPath = './upload/suratmasuk/';
        $allowedTypes = 'pdf|jpg|png';
        $uploadConfig = [
            'upload_path' => $uploadPath,
            'allowed_types' => $allowedTypes
        ];

        $request = service('request');

        // Ambil file upload
        $fileSurat = $request->getFile('file_surat');

        // Validasi upload
        if ($fileSurat->isValid() && !$fileSurat->hasMoved()) {
            // Pindahkan file upload ke folder upload
            $newName = $fileSurat->getRandomName();
            $fileSurat->move($uploadPath, $newName);

            // Data untuk dimasukkan ke database
            $dataInsert = [
                'id_pimpinan' => $pimp,
                'kategori_data' => $kat,
                'pengirim' => $request->getPost('pengirim'),
                'tanggal_surat_diterima' => $request->getPost('tanggal_surat_diterima'),
                'perihal' => $request->getPost('perihal'),
                'nomor_surat_masuk' => $request->getPost('nomor_surat_masuk'),
                'tanggal_surat' => $request->getPost('tanggal_surat'),
                'tembusan' => $request->getPost('tembusan'),
                'catatan_disposisi' => $request->getPost('catatan_disposisi'),
                'keterangan' => $request->getPost('keterangan'),
                'file_surat' => $newName
            ];

            // Masukkan data ke database
            $db = db_connect();
            $db->table('surat_masuk')->insert($dataInsert);

            // Set flashdata dan redirect
            $session->setFlashdata('flash', 'Tersimpan');
            return redirect()->to('rumah/suratmasuk');
        } else {
            // Jika file upload tidak valid, kembali ke halaman sebelumnya
            return redirect()->back()->withInput()->with('error', 'File tidak valid.');
        }
    }

    public function viewsuratmasuk()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('kec');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id = $this->request->getGet('id');
        $suratMasukModel = new SuratMasukModel();
        $data['suratmasuk'] = $suratMasukModel->where('id_surat_masuk', $id)->first();
        
        return view('template/headerKelurahan', $data) . view('desa/viewsuratmasuk') . view('template/footerKelurahan');
    }

    public function editsuratmasuk()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('kec');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id = $this->request->getGet('id');
        $suratMasukModel = new SuratMasukModel();
        $data['suratmasuk'] = $suratMasukModel->where('id_surat_masuk', $id)->first();
        
        return view('template/headerKelurahan', $data) . view('desa/editsuratmasuk') . view('template/footerKelurahan');
    }

    public function updatesuratmasuk()
    {
        $suratMasukModel = new SuratMasukModel();

        $id_sm = $this->request->getPost('id_surat_masuk');
        $data = [
            'pengirim' => $this->request->getPost('pengirim'),
            'tanggal_surat_diterima' => $this->request->getPost('tanggal_surat_diterima'),
            'perihal' => $this->request->getPost('perihal'),
            'nomor_surat_masuk' => $this->request->getPost('nomor_surat_masuk'),
            'tanggal_surat' => $this->request->getPost('tanggal_surat'),
            'tembusan' => $this->request->getPost('tembusan'),
            'catatan_disposisi' => $this->request->getPost('catatan_disposisi'),
            'keterangan' => $this->request->getPost('keterangan')
        ];

        $suratMasukModel->update($id_sm, $data);

        return redirect()->to('/rumah/suratmasuk')->with('flash', 'Diedit');
    }

    public function deletesuratmasuk()
    {
        $suratMasukModel = new SuratMasukModel();

        $id_sm = $this->request->getGet('id');
        $suratMasukModel->delete($id_sm);

        return redirect()->to('/rumah/suratmasuk')->with('flash', 'Dihapus');
    }

    public function suratkeluar()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('kec');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        //$id_anggota = $this->request->getGet('id'); // Menggunakan method getGet untuk mendapatkan data dari query string
        $suratkeluarModel = new SuratKeluarModel();
        $data['surat_keluar'] = $suratkeluarModel->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->orderBy('tanggal_surat')->get()->getResultArray();
        $surat_keluar = $data['surat_keluar'];

        return view('template/headerKelurahan', $data) . view('desa/suratkeluar') . view('template/footerKelurahan');
    }

    public function insuratkeluar()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('kec');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        //$id_anggota = $this->request->getGet('id'); // Menggunakan method getGet untuk mendapatkan data dari query string
        // $suratmasukModel = new SuratMasukModel();
        // $data['suratmasuk'] = $suratmasukModel->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->orderBy('tanggal_surat_diterima')->get()->getResultArray();
        // $suratmasuk = $data['suratmasuk'];

        return view('template/headerKelurahan', $data) . view('desa/insuratkeluar') . view('template/footerKelurahan');
    }

    public function addsuratkeluar()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('kec');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $file = $this->request->getFile('file_surat');
        $newName = $file->getRandomName();
        $uploadPath = './upload/suratkeluar/';

        if ($file->isValid() && !$file->hasMoved()) {
            $file->move($uploadPath, $newName);
        }

        $data = [
            'id_pimpinan' => $pimp,
            'kategori_data' => $kat,
            'nomor_surat' => $this->request->getPost('nomor_surat'),
            'index_surat' => $this->request->getPost('index_surat'),
            'tanggal_surat' => $this->request->getPost('tanggal_surat'),
            'tujuan_surat' => $this->request->getPost('tujuan_surat'),
            'perihal' => $this->request->getPost('perihal'),
            'keterangan' => $this->request->getPost('keterangan'),
            'file_surat' => $newName
        ];

        $suratKeluarModel = new SuratKeluarModel();
        $suratKeluarModel->insert($data);

        $session->setFlashdata('flash', 'Tersimpan');
        return redirect()->to('/rumah/suratkeluar');
    }

    public function viewsuratkeluar()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('kec');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id = $this->request->getGet('id');
        $suratkeluarModel = new SuratKeluarModel();
        $data['surat_keluar'] = $suratkeluarModel->where('id_surat_keluar', $id)->first();
        
        return view('template/headerKelurahan', $data) . view('desa/viewsuratkeluar') . view('template/footerKelurahan');
    }

    public function editsuratkeluar()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('kec');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id = $this->request->getGet('id');
        $suratkeluarModel = new SuratKeluarModel();
        $data['surat_keluar'] = $suratkeluarModel->where('id_surat_keluar', $id)->first();
        
        return view('template/headerKelurahan', $data) . view('desa/editsuratkeluar') . view('template/footerKelurahan');
    }

    public function updatesuratkeluar()
    {
        $suratkeluarModel = new SuratKeluarModel();

        $id_sk = $this->request->getPost('id_surat_keluar');
        $data = [
            'nomor_surat' => $this->request->getPost('nomor_surat'),
            'tanggal_surat' => $this->request->getPost('tanggal_surat'),
            'tujuan_surat' => $this->request->getPost('tujuan_surat'),
            'perihal' => $this->request->getPost('perihal'),
            'keterangan' => $this->request->getPost('keterangan')
        ];

        $suratkeluarModel->update($id_sk, $data);

        return redirect()->to('/rumah/suratkeluar')->with('flash', 'Diedit');
    }

    public function deletesuratkeluar()
    {
        $suratkeluarModel = new SuratKeluarModel();

        $id_sm = $this->request->getGet('id');
        $suratkeluarModel->delete($id_sm);

        return redirect()->to('/rumah/suratkeluar')->with('flash', 'Dihapus');
    }

    public function keuangan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('kec');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $keuanganModel = new KeuanganModel();

        $data['keuangan'] = $keuanganModel->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->orderBy('tanggal_transaksi')->findAll();

        $data['masuk'] = $keuanganModel->selectSum('masuk')->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->first();

        $data['keluar'] = $keuanganModel->selectSum('keluar')->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->first();

        return view('template/headerKelurahan', $data) . view('desa/keuangan') . view('template/footerKelurahan');
    }

    public function inkeuangan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('kec');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];
        
        return view('template/headerKelurahan', $data) . view('desa/inkeuangan') . view('template/footerKelurahan');
    }

    public function addkeuangan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('kec');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data = [
            'id_pimpinan' => $pimp,
            'kategori_data' => $kat,
            'tanggal_transaksi' => $this->request->getPost('tanggal_transaksi'),
            'nama_barang' => $this->request->getPost('nama_barang'),
            'masuk' => $this->request->getPost('masuk'),
            'keluar' => $this->request->getPost('keluar'),
            'jenis_transaksi' => $this->request->getPost('jenis_transaksi'),
            'keterangan' => $this->request->getPost('keterangan')
        ];

        $keuanganModel = new KeuanganModel();
        $keuanganModel->insert($data);

        $session->setFlashdata('flash', 'Tersimpan');
        return redirect()->to('/rumah/keuangan');
    }

    public function viewkeuangan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('kec');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id = $this->request->getGet('id');
        $keuanganModel = new KeuanganModel();
        $data['keuangan'] = $keuanganModel->where('id_keuangan', $id)->first();
        
        return view('template/headerKelurahan', $data) . view('desa/viewkeuangan') . view('template/footerKelurahan');
    }

    public function editkeuangan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('kec');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id = $this->request->getGet('id');
        $keuanganModel = new KeuanganModel();
        $data['keuangan'] = $keuanganModel->where('id_keuangan', $id)->first();
        
        return view('template/headerKelurahan', $data) . view('desa/editkeuangan') . view('template/footerKelurahan');
    }

    public function updatekeuangan()
    {
        $keuanganModel = new KeuanganModel();

        $id_keu = $this->request->getPost('id_keuangan');
        $data = [
            'tanggal_transaksi' => $this->request->getPost('tanggal_transaksi'),
            'masuk' => $this->request->getPost('masuk'),
            'keluar' => $this->request->getPost('keluar'),
            'jenis_transaksi' => $this->request->getPost('jenis_transaksi'),
            'keterangan' => $this->request->getPost('keterangan')
        ];

        $keuanganModel->update($id_keu, $data);

        return redirect()->to('/rumah/keuangan')->with('flash', 'Diedit');
    }

    public function deletekeuangan()
    {
        $keuanganModel = new KeuanganModel();

        $id_keu = $this->request->getGet('id');
        $keuanganModel->delete($id_keu);

        return redirect()->to('/rumah/keuangan')->with('flash', 'Dihapus');
    }

    public function inventarisbarang()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('kec');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        //$id = $this->request->getGet('id');
        $inventarisbarangModel = new InventarisBarangModel();
        $data['inventaris_barang'] = $inventarisbarangModel->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->orderBy('nama_barang')->get()->getResultArray();
        
        return view('template/headerKelurahan', $data) . view('desa/inventarisbarang') . view('template/footerKelurahan');
    }

    public function ininventarisbarang()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('kec');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];
        
        return view('template/headerKelurahan', $data) . view('desa/ininventarisbarang') . view('template/footerKelurahan');
    }

    public function addinventarisbarang()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('kec');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data = [
            'id_pimpinan' => $pimp,
            'kategori_data' => $kat,
            'index_barang' => $this->request->getPost('index_barang'),
            'nama_barang' => $this->request->getPost('nama_barang'),
            'jumlah' => $this->request->getPost('jumlah'),
            'asal_barang' => $this->request->getPost('asal_barang'),
            'harga_satuan' => $this->request->getPost('harga_satuan'),
            'keterangan' => $this->request->getPost('keterangan')
        ];

        $inventarisBarangModel = new InventarisBarangModel();
        $inventarisBarangModel->insert($data);

        $session->setFlashdata('flash', 'Tersimpan');
        return redirect()->to('/rumah/inventarisbarang');
    }

    public function viewinventarisbarang()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('kec');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id = $this->request->getGet('id');
        $inventarisbarangModel = new InventarisBarangModel();
        $data['inventaris_barang'] = $inventarisbarangModel->where('id_inventaris_barang', $id)->first();
        
        return view('template/headerKelurahan', $data) . view('desa/viewinventarisbarang') . view('template/footerKelurahan');
    }

    public function editinventarisbarang()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('kec');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id = $this->request->getGet('id');
        $inventarisbarangModel = new InventarisBarangModel();
        $data['inventaris_barang'] = $inventarisbarangModel->where('id_inventaris_barang', $id)->first();
        
        return view('template/headerKelurahan', $data) . view('desa/editinventarisbarang') . view('template/footerKelurahan');
    }

    public function updateinventarisbarang()
    {
        $inventarisbarangModel = new InventarisBarangModel();

        $id_ib = $this->request->getPost('id_inventaris_barang');
        $data = [
            'index_barang' => $this->request->getPost('index_barang'),
            'nama_barang' => $this->request->getPost('nama_barang'),
            'jumlah' => $this->request->getPost('jumlah'),
            'asal_barang' => $this->request->getPost('asal_barang'),
            'harga_satuan' => $this->request->getPost('harga_satuan'),
            'keterangan' => $this->request->getPost('keterangan')
        ];

        $inventarisbarangModel->update($id_ib, $data);

        return redirect()->to('/rumah/inventarisbarang')->with('flash', 'Diedit');
    }

    public function deleteinventarisbarang()
    {
        $inventarisbarangModel = new InventarisBarangModel();

        $id_ib = $this->request->getGet('id');
        $inventarisbarangModel->delete($id_ib);

        return redirect()->to('/rumah/inventarisbarang')->with('flash', 'Dihapus');
    }

    public function potensikader()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('kec');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        // Hitung jumlah anggota
        $anggotaModel = new AnggotaModel();
        $data['anggota'] = $anggotaModel->where('id_pimpinan_rk', $pimp)->where('kategori_data', $kat)->whereNotIn('aktif_kepengurusan', ['PW'])->countAllResults();
        $data['makesta'] = $anggotaModel->where('id_pimpinan_rk', $pimp)->where('pelatihan_formal', 'makesta')->where('kategori_data', $kat)->whereNotIn('aktif_kepengurusan', ['PW'])->countAllResults();
        $data['lakmud'] = $anggotaModel->where('id_pimpinan_rk', $pimp)->where('pelatihan_formal', 'lakmud')->where('kategori_data', $kat)->whereNotIn('aktif_kepengurusan', ['PW'])->countAllResults();
        $data['lakut'] = $anggotaModel->where('id_pimpinan_rk', $pimp)->where('pelatihan_formal', 'lakut')->where('kategori_data', $kat)->whereNotIn('aktif_kepengurusan', ['PW'])->countAllResults();
        $data['cbp'] = $anggotaModel->where('id_pimpinan_rk', $pimp)->where('status_cbp', 'ya')->where('kategori_data', $kat)->whereNotIn('aktif_kepengurusan', ['PW'])->countAllResults();


        //return view('template/headerUser', $data) . view('operator/potensikader') . view('template/footerUser');
        
      //  if ($lev === 'user') {
            return view('template/headerKelurahan', $data) .
            view('desa/potensikader') .
            view('template/footerKelurahan');
        // } elseif ($lev === 'userpac') {
        //     return view('template/headerUser', $data) .
        //     view('operator/potensikader1') .
        //     view('template/footerUser');
        // } else {
        //     // Jika status akun tidak valid, mungkin redirect ke halaman error atau tampilkan pesan kesalahan
        //     return 'Invalid role';
        // }

    }

    public function editfotoanggota()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('kec');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id_anggota = $this->request->getGet('id'); // Menggunakan method getGet untuk mendapatkan data dari query string
        $anggotaModel = new AnggotaModel();
        $data['anggota'] = $anggotaModel->find($id_anggota);

        return view('template/headerKelurahan', $data) . view('desa/editfotoanggota') . view('template/footerKelurahan');
    }

    public function updatefotoanggota()
    {
        $id_anggota = $this->request->getPost('id');

        $upload = $this->request->getFile('foto');
        if ($upload->isValid() && !$upload->hasMoved()) {
            $newName = $upload->getRandomName();
            $upload->move('./upload/anggota', $newName);

            $anggotaModel = new AnggotaModel();
            $anggotaModel->update($id_anggota, ['foto' => $newName]);
        }

        session()->setFlashdata('flash', 'Diedit');
        return redirect()->to('rumah/viewanggota?id=' . $id_anggota);
    }

    public function dataalumni()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('kec');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['cabang'] = $pimpinanModel->where('kategori_data', $kat)->where('pimpinan', 'PC')->orderBy('kd_pimpinan')->get()->getResultArray();
        $cabang = $data['cabang'];

        //$pimpinanAcModel = new PimpinanAcModel();
        $data['kecamatan'] = $pimpinanacModel->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->where('pimpinan_ac', 'PAC')->orderBy('kd_pimpinan_ac')->findAll();
        $kecamatan = $data['kecamatan'];

        $pac = $this->request->getGet('id2');

        $data['ac'] = $pimpinanacModel->where('id_pimpinan_ac', $pac)->first();

        $data['get_pc'] = $pimpinanModel->where('id_pimpinan', $this->request->getGet('id'))->get()->getRowArray();
        $get_pc = $data['get_pc'];

        $data['get_pac'] = $pimpinanacModel->where('id_pimpinan_ac', $this->request->getGet('id2'))->get()->getRowArray();
        $get_pac = $data['get_pac'];

        //$pimpinanRkModel = new PimpinanRkModel();
        $data['pr'] = $pimpinanrkModel->where('kategori_data', $kat)->where('pimpinan_rk', 'PR')->orderBy('kd_pimpinan_rk')->findAll();
        $pr = $data['pr'];

        $data['pr1'] = $pimpinanrkModel->where('id_pimpinan_ac', $this->request->getGet('id2'))->where('kategori_data', $kat)->where('pimpinan_rk', 'PR')->orderBy('kd_pimpinan_rk')->findAll();
        $pr1 = $data['pr1'];

        $data['get_pr'] = $pimpinanrkModel->where('id_pimpinan_rk', $this->request->getGet('id3'))->get()->getRowArray();
        $get_pr = $data['get_pr'];

        $anggotaModel = new AnggotaModel();
        $data['anggota'] = $anggotaModel->select('*')->join('pimpinan_ac', 'id_pimpinan_ac')->join('pimpinan_rk', 'id_pimpinan_rk')->where('anggota.id_pimpinan_rk', $pimp)->where('anggota.id_pimpinan_ac', $this->request->getGet('id2'))->where('anggota.id_pimpinan_rk', $this->request->getGet('id3'))->orderBy('id_anggota')->whereNotIn('aktif_kepengurusan', ['PW'])->where('status_alumni', ['ya'])->get()->getResultArray();
        $anggota = $data['anggota'];

        return view('template/headerKelurahan', $data) . view('desa/dataalumni') . view('template/footerKelurahan');
    }

    public function tambahdataalumni()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('pac');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['cabang'] = $pimpinanModel->where('kategori_data', $kat)->where('pimpinan', 'PC')->orderBy('kd_pimpinan')->get()->getResultArray();
        $cabang = $data['cabang'];

        $pimpinanAcModel = new PimpinanAcModel();
        $data['kecamatan'] = $pimpinanAcModel->where('id_pimpinan', $this->request->getGet('id'))->where('kategori_data', $kat)->where('pimpinan_ac', 'PAC')->orderBy('kd_pimpinan_ac')->findAll();
        $kecamatan = $data['kecamatan'];

        $pac = $this->request->getGet('id2');

        $data['ac'] = $pimpinanAcModel->where('id_pimpinan_ac', $pac)->first();

        $data['get_pc'] = $pimpinanModel->where('id_pimpinan', $this->request->getGet('id'))->get()->getRowArray();
        $get_pc = $data['get_pc'];

        $data['get_pac'] = $pimpinanAcModel->where('id_pimpinan_ac', $this->request->getGet('id2'))->get()->getRowArray();
        $get_pac = $data['get_pac'];

        $anggotaModel = new AnggotaModel();
        $data['anggota'] = $anggotaModel->select('*')->join('pimpinan_ac', 'id_pimpinan_ac')->join('pimpinan_rk', 'id_pimpinan_rk')->where('anggota.id_pimpinan_rk', $pimp)->where('anggota.id_pimpinan_ac', $this->request->getGet('id2'))->where('anggota.id_pimpinan_rk', $this->request->getGet('id3'))->orderBy('id_anggota')->whereNotIn('aktif_kepengurusan', ['PW'])->get()->getResultArray();
        $anggota = $data['anggota'];

        return view('template/headerKelurahan', $data) . view('desa/tambahdataalumni') . view('template/footerKelurahan');
    }

    public function editdataalumni()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('pac');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id_anggota = $this->request->getPost('id');
        $state = [
              'status_alumni' => 'Ya'
        ];

        $model = new AnggotaModel();
        $model->update($id_anggota, $state);

        // $this->session->setFlashdata('flash', 'Diedit');
        return redirect()->to('desa/tambahdataalumni?id=' .$ket.'&id2=' .$kec. '&id3=' .$pimp);

    }

    public function addanggotaippnu()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/login'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $userModel = new UserModel();
        $data['admin_users'] = $userModel->where('email', $session->get('email'))->first();

        $data['level'] = $session->get('level');
        $lev = $data['level'];

        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $data['ket'] = $session->get('ket');
        $ket = $data['ket'];

        $data['id_usermodel'] = $session->get('id_user');
        $id_usermodel = $data['id_usermodel'];

        $data['kec'] = $session->get('pac');
        $kec = $data['kec'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();

        $pimpinanacModel = new PimpinanAcModel();
        $data['pimpinan_defaultpac'] = $pimpinanacModel->where('id_pimpinan_ac', session('id_pimpinan'))->get()->getRowArray();

        $pimpinanrkModel = new PimpinanRkModel();
        $data['pimpinan_defaultrk'] = $pimpinanrkModel->where('id_pimpinan_rk', session('id_pimpinan'))->get()->getRowArray();       

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];
        
        //$KategoriDataModel = new KategoriDataModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $this->pimpinanRkModel = new PimpinanRkModel();
        $request = service('request');
        $id = $request->getGet('id');
        $model = new AnggotaModel();
        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];
        $pimpinanRkModel = new PimpinanRkModel();
        $data['pimpinanRkModel'] = $pimpinanRkModel->where('kategori_data', $kat)->orderBy('nama_pimpinan_rk')->findAll();
        $pimpinanRkModel = $data['pimpinanRkModel'];
        $data['tingkatan'] = $session->get('tingkatan');
        $tingkatan = $data['tingkatan'];

        $validationRules = [
            'nik' => 'is_unique[anggota.nik]',
            'email' => 'is_unique[anggota.email]'
        ];

        $validated = $this->validate($validationRules);

        if (!$validated)
        {
            $id_pimpinan = $request->getPost('id_pimpinan');
            $id_pimpinan_ac = $request->getPost('id_pimpinan_ac');
            $session = \Config\Services::session();
            // $this->session->setFlashdata('flash', 'Terpakai');

            // if ($this->request->getPost('jenis') == 'PKPT') {
            //     return redirect()->to('user/inanggotapkpt?id=&id2=' . $id_pimpinan_ac);
            // } else {
                return redirect()->to('rumah/inanggota?id=' . $id_pimpinan);
            // }
        }
        else
        {
            // Proses penyimpanan data anggota ke database
            // ...
            $id = $this->request->getPost('id_pimpinan');
            //$this->db->from('anggota');
            //$this->db->where('id_pimpinan', $id);
            //$jumlah = $this->db->count_all_results();
            //$nia = $jumlah + 1;

            $data['jumlah'] = $model->where('id_pimpinan', $id)->countAllResults();

            $jumlah = $data['jumlah'];
            $nia = $jumlah + 1;

            $nia_urut = str_pad($nia, 4, "0", STR_PAD_LEFT);
            $pw = $this->request->getPost('pw');

            // $pimpinan_defaultpac = $this->db->get_where('pimpinan_ac', ['id_pimpinan_ac' => $this->session->get('id_pimpinan')])->getRowArray();

            // $rkpost = $this->request->getPost('id_pimpinan_rk');
            // $A = $this->db->select('*')->where('id_pimpinan_rk', $rkpost)->get('pimpinan_rk')->getRowArray();
            // $idP1 = $A['kd_pimpinan_rk'];

            // $acpost = $this->request->getPost('id_pimpinan_ac');
            // $B = $this->db->select('*')->where('id_pimpinan_ac', $acpost)->get('pimpinan_ac')->getRowArray();
            // $idP2 = $B['kd_pimpinan_ac'];

            $pcpost = $this->request->getPost('id_pimpinan');
            $pimpinanModel = new PimpinanModel();
            $C = $pimpinanModel->where('id_pimpinan', $pcpost)->first();
            
            // $C = $this->db->select('*')->where('id_pimpinan', $pcpost)->get('pimpinan')->getRowArray();
            $pc = $C['kd_pimpinan'];

            $tgl_masuk = $this->request->getPost('waktu_makesta');
            $th = substr($tgl_masuk, 2, 2);
            $bln = substr($tgl_masuk, 5, 2);

            $tgl_lahir = $this->request->getPost('tanggal_lahir');
            $th_lahir = substr($tgl_lahir, 2, 2);

            $nia_jadi = $pw . $pc . $th . $bln . $nia_urut;

            $uploadPath = './upload/anggota/';
            $allowedTypes = 'jpg|jpeg|png';
            $this->validate([
                'foto' => [
                    'uploaded[foto]',
                    'mime_in[foto,' . $allowedTypes . ']',
                    'max_size[foto,1024]' // 1 MB max size
                ]
            ]);

            if ($this->request->getFile('foto')->isValid() && !$this->request->getFile('foto')->hasMoved()) {
                $foto = $this->request->getFile('foto');
                $fotoName = $foto->getRandomName();
                $foto->move($uploadPath, $fotoName);
            } else {
                // Handle error if file upload fails
            }

            // $datanonformal = implode(", ", $this->request->getPost('pelatihan_nonformal'));

            // Ambil data anggota dari form
            // $nik = $this->request->getPost('nik');
            // $email = $this->request->getPost('email');

            // Lakukan proses penyimpanan ke database
            // ...
                $data = [
                    'nia' => $nia_jadi,
                    'nama' => $request->getPost('nama'),
                    'nik' => $request->getPost('nik'),
                    'kategori_data' => $request->getPost('kategori_data'),
                    'tempat_lahir' => $request->getPost('tempat_lahir'),
                    'tanggal_lahir' => $request->getPost('tanggal_lahir'),
                    'alamat_lengkap' => $request->getPost('alamat_lengkap'),
                    'id_pw' => '18',
                    'id_pimpinan' => $request->getPost('id_pimpinan'),
                    'id_pimpinan_ac' => $request->getPost('id_pimpinan_ac'),
                    'id_pimpinan_rk' => $request->getPost('id_pimpinan_rk'),
                    'aktif_kepengurusan' => $request->getPost('aktif_kepengurusan'),
                    'pelatihan_formal' => $request->getPost('pelatihan_formal'),
                    'makesta' => $request->getPost('makesta'),
                    'penyelenggara_makesta' => $request->getPost('penyelenggara_makesta'),
                    'tempat_makesta' => $request->getPost('tempat_makesta'),
                    'waktu_makesta' => $request->getPost('waktu_makesta'),
                    'lakmud' => $request->getPost('lakmud'),
                    'penyelenggara_lakmud' => $request->getPost('penyelenggara_lakmud'),
                    'tempat_lakmud' => $request->getPost('tempat_lakmud'),
                    'waktu_lakmud' => $request->getPost('waktu_lakmud'),
                    'lakut' => $request->getPost('lakut'),
                    'penyelenggara_lakut' => $request->getPost('penyelenggara_lakut'),
                    'tempat_lakut' => $request->getPost('tempat_lakut'),
                    'waktu_lakut' => $request->getPost('waktu_lakut'),
                    'email' => $request->getPost('email'),
                    'password' => '$2y$10$Logj899HwVPyNFXVLpThg.RLf2zlwh9NDGrXg8B2xEAuglbu48NrW',
                    'status_verifikasi' => 'belum',
                    'jabatan' => $request->getPost('jabatan'),
                ];
                
            
            $model->insert($data);


           // $tingkatan = $this->session->get('tingkatan');
          //  $id_pimpinan = $this->request->getPost('id_pimpinan');
          //  $id_pimpinan_ac = $this->request->getPost('id_pimpinan_ac');

            // $this->session->setFlashdata('flash', 'Tersimpan');

           // if ($tingkatan == 'PC') {
                return redirect()->to('admin/dashboard');
           // } elseif ($tingkatan == 'PAC') {
          //      return redirect()->to('user/dashboard');
           // }
        }
    }

    private function isLoggedIn()
    {
        // Ambil instance session
        $session = session();

        // Periksa apakah data sesi yang menandakan pengguna sudah login ada
        return $session->has('logged_in') && $session->get('logged_in') === true;
    }
}