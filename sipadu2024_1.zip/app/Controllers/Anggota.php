<?php
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\UserModel;
use App\Models\PimpinanModel;
use App\Models\PimpinanAcModel;
use App\Models\PimpinanRkModel;
use App\Models\AnggotaModel;
use App\Models\KeuanganModel;
use App\Models\SuratMasukModel;
use App\Models\SuratKeluarModel;
use App\Models\InventarisBarangModel;
use App\Models\PengaturanPimpinanModel;
use App\Models\DaftarKegiatanModel;
use App\Models\DataPendaftarModel;
use App\Models\PerpustakaanModel;

class Anggota extends Controller
{
    public function logout()
    {
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginanggota'); // Redirect ke halaman login jika belum login
        }
        // Hapus data sesi yang menandakan pengguna sudah login
        $session = session();
        $session->destroy();

        // Redirect ke halaman utama setelah logout
        return redirect()->to('/');
    }

    public function dashboard()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginanggota'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $anggotaModel = new AnggotaModel();
        $data['admin_users'] = $anggotaModel->where('nia', $session->get('nia'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama'] = $session->get('nama');
        $nama = $data['nama'];

        $data['id_anggota'] = $session->get('id_anggota');
        $id_anggota = $data['id_anggota'];

        $data['pelatihan_formal'] = $session->get('pelatihan_formal');
        $pelatihan_formal = $data['pelatihan_formal'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        return view('template/headerAnggota', $data) . view('anggota/dashboard') . view('template/footerAnggota');
    }

    public function about()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginanggota'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $anggotaModel = new AnggotaModel();
        $data['admin_users'] = $anggotaModel->where('nia', $session->get('nia'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama'] = $session->get('nama');
        $nama = $data['nama'];

        $data['id_anggota'] = $session->get('id_anggota');
        $id_anggota = $data['id_anggota'];

        $data['pelatihan_formal'] = $session->get('pelatihan_formal');
        $pelatihan_formal = $data['pelatihan_formal'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        return view('template/headerAnggota', $data) . view('anggota/about') . view('template/footerAnggota');
    }

    public function editpassword()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginanggota'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $anggotaModel = new AnggotaModel();
        $data['admin_users'] = $anggotaModel->where('nia', $session->get('nia'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama'] = $session->get('nama');
        $nama = $data['nama'];

        $data['id_anggota'] = $session->get('id_anggota');
        $id_anggota = $data['id_anggota'];

        $data['pelatihan_formal'] = $session->get('pelatihan_formal');
        $pelatihan_formal = $data['pelatihan_formal'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $data['anggota'] = $anggotaModel->where('id_anggota', $id_anggota)->get()->getRowArray();

        return view('template/headerAnggota', $data) . view('anggota/editpassword') . view('template/footerAnggota');
    }
    
    public function statusalumni()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginanggota'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $anggotaModel = new AnggotaModel();
        $data['admin_users'] = $anggotaModel->where('nia', $session->get('nia'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama'] = $session->get('nama');
        $nama = $data['nama'];

        $data['id_anggota'] = $session->get('id_anggota');
        $id_anggota = $data['id_anggota'];

        $data['pelatihan_formal'] = $session->get('pelatihan_formal');
        $pelatihan_formal = $data['pelatihan_formal'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $data['anggota'] = $anggotaModel->where('id_anggota', $id_anggota)->get()->getRowArray();

        return view('template/headerAnggota', $data) . view('anggota/statusalumni') . view('template/footerAnggota');
    }

    public function minatbakat()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginanggota'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $anggotaModel = new AnggotaModel();
        $data['admin_users'] = $anggotaModel->where('nia', $session->get('nia'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama'] = $session->get('nama');
        $nama = $data['nama'];

        $data['id_anggota'] = $session->get('id_anggota');
        $id_anggota = $data['id_anggota'];

        $data['pelatihan_formal'] = $session->get('pelatihan_formal');
        $pelatihan_formal = $data['pelatihan_formal'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $data['anggota'] = $anggotaModel->where('id_anggota', $id_anggota)->get()->getRowArray();

        return view('template/headerAnggota', $data) . view('anggota/minatbakat') . view('template/footerAnggota');
    }

    public function updatepassword()
    {
        $id_anggota = $this->request->getPost('id');
        $state = [
            'nia' => $this->request->getPost('nia'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT)
        ];

        $anggotaModel = new AnggotaModel();
        $anggotaModel->update($id_anggota, $state);

        session()->setFlashdata('flash', 'Diedit');
        return redirect()->to(site_url('anggota/dashboard'));
    }

    public function updatealumni()
    {
        $id_anggota = $this->request->getPost('id');
        $state = [
            'status_alumni' => $this->request->getPost('status_alumni')
        ];

        $anggotaModel = new AnggotaModel();
        $anggotaModel->update($id_anggota, $state);

        session()->setFlashdata('flash', 'Diedit');
        return redirect()->to(site_url('anggota/statusalumni'));
    }

    public function updateminatbakat()
    {
        $id_anggota = $this->request->getPost('id');
        $state = [
            'minat_bakat' => $this->request->getPost('minat_bakat'),
            'detail_minat' => $this->request->getPost('detail_minat'),
            'prestasi' => $this->request->getPost('prestasi')
        ];

        $anggotaModel = new AnggotaModel();
        $anggotaModel->update($id_anggota, $state);

        session()->setFlashdata('flash', 'Diedit');
        return redirect()->to(site_url('anggota/minatbakat'));
    }

    public function viewanggota()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginanggota'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $anggotaModel = new AnggotaModel();
        $data['admin_users'] = $anggotaModel->where('nia', $session->get('nia'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama'] = $session->get('nama');
        $nama = $data['nama'];

        $data['id_anggota'] = $session->get('id_anggota');
        $id_anggota = $data['id_anggota'];

        $data['pelatihan_formal'] = $session->get('pelatihan_formal');
        $pelatihan_formal = $data['pelatihan_formal'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $data['anggota'] = $anggotaModel->where('id_anggota', $id_anggota)->get()->getRowArray();

        return view('template/headerAnggota', $data) . view('anggota/viewanggota') . view('template/footerAnggota');
    }

    public function editanggota()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginanggota'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $anggotaModel = new AnggotaModel();
        $data['admin_users'] = $anggotaModel->where('nia', $session->get('nia'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama'] = $session->get('nama');
        $nama = $data['nama'];

        $data['id_anggota'] = $session->get('id_anggota');
        $id_anggota = $data['id_anggota'];

        $data['pelatihan_formal'] = $session->get('pelatihan_formal');
        $pelatihan_formal = $data['pelatihan_formal'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $data['cabang'] = $pimpinanModel->where('kategori_data', $kat)->where('pimpinan', 'PC')->orderBy('kd_pimpinan')->get()->getResultArray();
        $cabang = $data['cabang'];

        $pimpinanacModel = new PimpinanAcModel();
        $data['kecamatan'] = $pimpinanacModel->where('kategori_data', $kat)->where('pimpinan_ac', 'PAC')->orderBy('kd_pimpinan_ac')->findAll();
        $kecamatan = $data['kecamatan'];

        $pimpinanrkModel = new PimpinanRkModel();
        $data['ranting'] = $pimpinanrkModel->where('kategori_data', $kat)->orderBy('kd_pimpinan_rk')->findAll();
        $ranting = $data['ranting'];

        $data['anggota'] = $anggotaModel->join('pimpinan', 'id_pimpinan')->join('pimpinan_ac', 'id_pimpinan_ac')->join('pimpinan_rk', 'id_pimpinan_rk')->where('id_anggota', $id_anggota)->get()->getRowArray();

        return view('template/headerAnggota', $data) . view('anggota/editanggota') . view('template/footerAnggota');
    }

    public function updateanggota()
    {
        $id_anggota = $this->request->getPost('id');
        $datanonformal = implode(", ", $this->request->getPost('pelatihan_nonformal'));
        $state = [
            'nia' => $this->request->getPost('nia'),
            'nama' => $this->request->getPost('nama'),
            'nik' => $this->request->getPost('nik'),
            'tempat_lahir' => $this->request->getPost('tempat_lahir'),
            'tanggal_lahir' => $this->request->getPost('tanggal_lahir'),
            'alamat_lengkap' => $this->request->getPost('alamat_lengkap'),
            'nama_ayah' => $this->request->getPost('nama_ayah'),
            'nama_ibu' => $this->request->getPost('nama_ibu'),
            'aktif_kepengurusan' => $this->request->getPost('aktif_kepengurusan'),
            //'id_pimpinan' => $this->request->getPost('id_pimpinan'),
            //'id_pimpinan_ac' => $this->request->getPost('id_pimpinan_ac'),
            //'id_pimpinan_rk' => $this->request->getPost('id_pimpinan_rk'),
            'pelatihan_formal' => $this->request->getPost('pelatihan_formal'),
            'makesta' => $this->request->getPost('makesta'),
            'penyelenggara_makesta' => $this->request->getPost('penyelenggara_makesta'),
            'tempat_makesta' => $this->request->getPost('tempat_makesta'),
            'waktu_makesta' => $this->request->getPost('waktu_makesta'),
            'lakmud' => $this->request->getPost('lakmud'),
            'penyelenggara_lakmud' => $this->request->getPost('penyelenggara_lakmud'),
            'tempat_lakmud' => $this->request->getPost('tempat_lakmud'),
            'waktu_lakmud' => $this->request->getPost('waktu_lakmud'),
            'lakut' => $this->request->getPost('lakut'),
            'penyelenggara_lakut' => $this->request->getPost('penyelenggara_lakut'),
            'tempat_lakut' => $this->request->getPost('tempat_lakut'),
            'waktu_lakut' => $this->request->getPost('waktu_lakut'),
            'pelatihan_nonformal' => $datanonformal,
            'status_cbp' => $this->request->getPost('status_cbp'),
            'tanggal_masuk' => $this->request->getPost('tanggal_masuk'),
            'pendidikan_terakhir' => $this->request->getPost('pendidikan_terakhir'),
            'pendidikan_sd' => $this->request->getPost('pendidikan_sd'),
            'pendidikan_smp' => $this->request->getPost('pendidikan_smp'),
            'pendidikan_sma' => $this->request->getPost('pendidikan_sma'),
            'pendidikan_pt' => $this->request->getPost('pendidikan_pt'),
            'pendidikan_nonformal' => $this->request->getPost('pendidikan_nonformal'),
            'pekerjaan_ayah' => $this->request->getPost('pekerjaan_ayah'),
            'pekerjaan_ibu' => $this->request->getPost('pekerjaan_ibu'),
            'penghasilan_ayah' => $this->request->getPost('penghasilan_ayah'),
            'penghasilan_ibu' => $this->request->getPost('penghasilan_ibu'),
            'pekerjaan_usaha' => $this->request->getPost('pekerjaan_usaha'),
            'penghasilan_pribadi' => $this->request->getPost('penghasilan_pribadi'),
            'program_studi_s1' => $this->request->getPost('program_studi_s1'),
            'program_studi_s2' => $this->request->getPost('program_studi_s2'),
            'pascasarjana' => $this->request->getPost('pascasarjana'),
            'pengalaman_organisasi' => $this->request->getPost('pengalaman_organisasi'),
            'email' => $this->request->getPost('email'),
            'no_hp' => $this->request->getPost('no_hp'),
            'fb' => $this->request->getPost('fb'),
            'ig' => $this->request->getPost('ig'),
            'bakat' => $this->request->getPost('bakat'),
            'jabatan' => $this->request->getPost('jabatan'),
            'twitter' => $this->request->getPost('twitter')
        ];

        $anggotaModel = new AnggotaModel();
        $anggotaModel->update($id_anggota, $state);

        session()->setFlashdata('flash', 'Diedit');
        return redirect()->to(site_url('anggota/viewanggota?id=' . $id_anggota));
    }

    public function editfotoanggota()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginanggota'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $anggotaModel = new AnggotaModel();
        $data['admin_users'] = $anggotaModel->where('nia', $session->get('nia'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama'] = $session->get('nama');
        $nama = $data['nama'];

        $data['id_anggota'] = $session->get('id_anggota');
        $id_anggota = $data['id_anggota'];

        $data['pelatihan_formal'] = $session->get('pelatihan_formal');
        $pelatihan_formal = $data['pelatihan_formal'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $data['anggota'] = $anggotaModel->where('id_anggota', $id_anggota)->get()->getRowArray();

        return view('template/headerAnggota', $data) . view('anggota/editfotoanggota') . view('template/footerAnggota');
    }

    public function updatefotoanggota()
    {
        $id_anggota = $this->request->getPost('id');

        $upload = $this->request->getFile('foto');
        if ($upload->isValid() && !$upload->hasMoved()) {
            $newName = $upload->getRandomName();
            $upload->move('./upload/anggota', $newName);

            $anggotaModel = new AnggotaModel();
            $anggotaModel->update($id_anggota, ['foto' => $newName]);
        }

        session()->setFlashdata('flash', 'Diedit');
        return redirect()->to('anggota/viewanggota?id=' . $id_anggota);
    }

    public function daftarkegiatan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginanggota'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $anggotaModel = new AnggotaModel();
        $data['admin_users'] = $anggotaModel->where('nia', $session->get('nia'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama'] = $session->get('nama');
        $nama = $data['nama'];

        $data['id_anggota'] = $session->get('id_anggota');
        $id_anggota = $data['id_anggota'];

        $data['pelatihan_formal'] = $session->get('pelatihan_formal');
        $pelatihan_formal = $data['pelatihan_formal'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $data['anggota'] = $anggotaModel->where('id_anggota', $id_anggota)->get()->getRowArray();
        
        $daftarkegiatanModel = new DaftarKegiatanModel();
        $data['daftar_kegiatan'] = $daftarkegiatanModel->where('kategori_data', $kat)->where('kategori_kegiatan', $pelatihan_formal)->orderBy('tanggal')->get()->getResultArray();

        return view('template/headerAnggota', $data) . view('anggota/daftarkegiatan') . view('template/footerAnggota');
    }

    public function daftarkegiatananggota()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginanggota'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $anggotaModel = new AnggotaModel();
        $data['admin_users'] = $anggotaModel->where('nia', $session->get('nia'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama'] = $session->get('nama');
        $nama = $data['nama'];

        $data['id_anggota'] = $session->get('id_anggota');
        $id_anggota = $data['id_anggota'];

        $data['pelatihan_formal'] = $session->get('pelatihan_formal');
        $pelatihan_formal = $data['pelatihan_formal'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $data['anggota'] = $anggotaModel->join('pimpinan_ac', 'id_pimpinan_ac')->where('id_anggota', $id_anggota)->get()->getRowArray();
        
        $daftarkegiatanModel = new DaftarKegiatanModel();
        $data['daftar_kegiatan'] = $daftarkegiatanModel->where('kategori_data', $kat)->where('kategori_kegiatan', $pelatihan_formal)->orderBy('tanggal')->get()->getResultArray();

        $datapendaftarModel = new DataPendaftarModel();
        $data['data_peserta'] = $datapendaftarModel->join('anggota', 'id_anggota')->join('daftar_kegiatan', 'id_daftar_kegiatan')->where('id_anggota', $id_anggota)->where('data_pendaftar.kategori_data', $kat)->orderBy('tanggal')->get()->getResultArray();

        return view('template/headerAnggota', $data) . view('anggota/daftarkegiatananggota') . view('template/footerAnggota');
    }

    public function viewdaftarkegiatan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginanggota'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $anggotaModel = new AnggotaModel();
        $data['admin_users'] = $anggotaModel->where('nia', $session->get('nia'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama'] = $session->get('nama');
        $nama = $data['nama'];

        $data['id_anggota'] = $session->get('id_anggota');
        $id_anggota = $data['id_anggota'];

        $data['pelatihan_formal'] = $session->get('pelatihan_formal');
        $pelatihan_formal = $data['pelatihan_formal'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $id = $this->request->getGet('id');

        $data['anggota'] = $anggotaModel->where('id_anggota', $id_anggota)->get()->getRowArray();
        
        $daftarkegiatanModel = new DaftarKegiatanModel();
        $data['daftar_kegiatan'] = $daftarkegiatanModel->where('id_daftar_kegiatan', $id)->get()->getRowArray();

        return view('template/headerAnggota', $data) . view('anggota/viewdaftarkegiatan') . view('template/footerAnggota');
    }

    public function addpeserta()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginanggota'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $anggotaModel = new AnggotaModel();
        $data['admin_users'] = $anggotaModel->where('nia', $session->get('nia'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $id_anggota = $this->request->getPost('id_anggota');
        $id_daftar_kegiatan = $this->request->getPost('id_daftar_kegiatan');

        $state = [
            'kategori_data' => $kat,
            'id_daftar_kegiatan' => $this->request->getPost('id_daftar_kegiatan'),
            'status' => $this->request->getPost('status'),
            'id_anggota' => $this->request->getPost('id_anggota'),
        ];

        $datapendaftarModel = new DataPendaftarModel();
        $datapendaftarModel->insert($state);

        session()->setFlashdata('flash', 'Diedit');
        return redirect()->to(site_url('anggota/viewdaftarkegiatan?id='.$id_daftar_kegiatan.'&id2='.$id_anggota));
    }

    public function perpustakaan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginanggota'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $anggotaModel = new AnggotaModel();
        $data['admin_users'] = $anggotaModel->where('nia', $session->get('nia'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama'] = $session->get('nama');
        $nama = $data['nama'];

        $data['id_anggota'] = $session->get('id_anggota');
        $id_anggota = $data['id_anggota'];

        $data['pelatihan_formal'] = $session->get('pelatihan_formal');
        $pelatihan_formal = $data['pelatihan_formal'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $data['anggota'] = $anggotaModel->where('id_anggota', $id_anggota)->get()->getRowArray();
        
        $perpustakaanModel = new PerpustakaanModel();
        $data['perpustakaan'] = $perpustakaanModel->where('kategori_data', $kat)->where('kategori_materi', $pelatihan_formal)->orderBy('nama_materi')->get()->getResultArray();

        return view('template/headerAnggota', $data) . view('anggota/perpustakaan') . view('template/footerAnggota');
    }

    private function isLoggedIn()
    {
        // Ambil instance session
        $session = session();

        // Periksa apakah data sesi yang menandakan pengguna sudah login ada
        return $session->has('logged_in') && $session->get('logged_in') === true;
    }
}