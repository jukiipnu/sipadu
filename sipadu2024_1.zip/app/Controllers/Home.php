<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        // load assets in folder sipadu-template/
        return view('Home/index');
    }
}
