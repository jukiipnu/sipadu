<?php
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\UserModel;
use App\Models\PimpinanModel;
use App\Models\PimpinanAcModel;
use App\Models\PimpinanRkModel;
use App\Models\AnggotaModel;
use App\Models\KeuanganModel;
use App\Models\SuratMasukModel;
use App\Models\SuratKeluarModel;
use App\Models\InventarisBarangModel;
use App\Models\PengaturanPimpinanModel;
use App\Models\DaftarKegiatanModel;
use App\Models\DataPendaftarModel;
use App\Models\PerpustakaanModel;
use App\Models\PengurusModel;

class Pengurus extends Controller
{
    public function logout()
    {
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }
        // Hapus data sesi yang menandakan pengguna sudah login
        $session = session();
        $session->destroy();

        // Redirect ke halaman utama setelah logout
        return redirect()->to('/');
    }

    public function dashboard()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $id_pimpinan = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        return view('template/headerPengurus', $data) . view('pengurus/dashboard') . view('template/footerAnggota');
    }

    public function anggotapc()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $id_pimpinan = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $data['cabang'] = $pimpinanModel->where('kategori_data', $kat)->where('pimpinan', 'PC')->orderBy('kd_pimpinan')->get()->getResultArray();
        $cabang = $data['cabang'];

        $data['get_pc'] = $pimpinanModel->where('id_pimpinan', $this->request->getGet('id'))->get()->getRowArray();
        $get_pc = $data['get_pc'];

        $anggotaModel = new AnggotaModel();
        $data['anggota'] = $anggotaModel->select('*')->join('pimpinan_ac', 'id_pimpinan_ac')->where('anggota.id_pimpinan', $this->request->getGet('id'))->orderBy('id_anggota')->get()->getResultArray();
        $anggota = $data['anggota'];

        return view('template/headerPengurus', $data) .
            view('pengurus/anggotapc') .
            view('template/footerAnggota');
    }

    public function daftarkegiatan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $id_pimpinan = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $daftarkegiatanModel = new DaftarKegiatanModel();
        $data['daftar_kegiatan'] = $daftarkegiatanModel->where('id_pimpinan', $id_pimpinan)->where('kategori_data', $kat)->orderBy('tanggal')->get()->getResultArray();
        $daftar_kegiatan = $data['daftar_kegiatan'];

        return view('template/headerPengurus', $data) .view('pengurus/daftarkegiatan') .view('template/footerTemplate');
    }

    public function indaftarkegiatan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $id_pimpinan = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter
        
        return view('template/headerPengurus', $data)
            .view('pengurus/indaftarkegiatan')
            .view('template/footerTemplate');
    }

    public function adddaftarkegiatan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $id_pimpinan = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $daftarKegiatanModel = new DaftarKegiatanModel();

        $uploadPath = './upload/lpj/';
        $allowedTypes = 'jpeg|jpg|png';
        $uploadConfig = [
            'upload_path' => $uploadPath,
            'allowed_types' => $allowedTypes
        ];

        $request = service('request');

        // Ambil file upload
        $fileSurat = $request->getFile('browsur');

        // Validasi upload
        if ($fileSurat->isValid() && !$fileSurat->hasMoved()) {
            // Pindahkan file upload ke folder upload
            $newName = $fileSurat->getRandomName();
            $fileSurat->move($uploadPath, $newName);

            // Data untuk dimasukkan ke database
            $dataInsert = [
                'id_pimpinan' => $id_pimpinan,
                'kategori_data' => $kat,
                'nama_kegiatan' => $this->request->getPost('nama_kegiatan'),
                'hari' => $this->request->getPost('hari'),
                'tanggal' => $this->request->getPost('tanggal'),
                'waktu' => $this->request->getPost('waktu'),
                'kategori_kegiatan' => $this->request->getPost('kategori_kegiatan'),
                'pelaksana_kegiatan' => $this->request->getPost('pelaksana_kegiatan'),
                'tempat' => $this->request->getPost('tempat'),
                'informasi' => $this->request->getPost('informasi'),
                'browsur' => $newName
            ];

            // Masukkan data ke database
            $db = db_connect();
            $db->table('daftar_kegiatan')->insert($dataInsert);

            // Set flashdata dan redirect
            $session->setFlashdata('flash', 'Tersimpan');
            return redirect()->to('pengurus/daftarkegiatan');
        } else {
            // Jika file upload tidak valid, kembali ke halaman sebelumnya
            return redirect()->back()->withInput()->with('error', 'File tidak valid.');
        }
    }

    public function editdaftarkegiatan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $id_pimpinan = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $id = $this->request->getGet('id');
        $daftarkegiatannModel = new DaftarKegiatanModel();
        $data['daftar_kegiatan'] = $daftarkegiatanModel->where('id_daftar_kegiatan', $id)->first();
        
        return view('template/headerPengurus', $data)
            .view('pengurus/editdaftarkegiatan')
            .view('template/footerTemplate');
    }

    public function updatedaftarkegiatan()
    {
        $daftarkegiatanModel = new DaftarKegiatanModel();

        $id_dk = $this->request->getPost('id_daftar_kegiatan');
        $data = [
            'nama_kegiatan' => $this->request->getPost('nama_kegiatan'),
            'hari' => $this->request->getPost('hari'),
            'tanggal' => $this->request->getPost('tanggal'),
            'waktu' => $this->request->getPost('waktu'),
            'kategori_kegiatan' => $this->request->getPost('kategori_kegiatan'),
            'pelaksana_kegiatan' => $this->request->getPost('pelaksana_kegiatan'),
            'tempat' => $this->request->getPost('tempat'),
            //'keterangan' => $this->request->getPost('keterangan')
        ];

        $daftarkegiatanModel->update($id_dk, $data);

        return redirect()->to('pengurus/daftarkegiatan')->with('flash', 'Diedit');
    }

    public function viewdaftarkegiatan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $id_pimpinan = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $id = $this->request->getGet('id');
        $daftarkegiatanModel = new DaftarKegiatanModel();
        $data['daftar_kegiatan'] = $daftarkegiatanModel->where('id_daftar_kegiatan', $id)->first();
        
        return view('template/headerPengurus', $data)
            .view('pengurus/viewdaftarkegiatan')
            .view('template/footerTemplate');
    }

    public function deletedaftarkegiatan()
    {
        $daftarkegiatanModel = new DaftarKegiatanModel();

        $id_dk = $this->request->getGet('id');
        $daftarkegiatanModel->delete($id_dk);

        return redirect()->to('/pengurus/daftarkegiatan')->with('flash', 'Dihapus');
    }

    public function viewdaftarpeserta()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $id_pimpinan = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $kategori = $session->get('kategori');

        $data['cabang'] = $pimpinanModel->where('kategori_data', $kat)->where('pimpinan', 'PC')->orderBy('kd_pimpinan')->get()->getResultArray();
        $cabang = $data['cabang'];

        $data['get_pc'] = $pimpinanModel->where('id_pimpinan', $this->request->getGet('id'))->get()->getRowArray();
        $get_pc = $data['get_pc'];

        $anggotaModel = new AnggotaModel();
        $data['anggota'] = $anggotaModel->select('*')->join('pimpinan_ac', 'id_pimpinan_ac')->where('anggota.id_pimpinan', $this->request->getGet('id'))->orderBy('id_anggota')->get()->getResultArray();
        $anggota = $data['anggota'];

        $data['jumlah'] = $anggotaModel
                        ->where('id_pimpinan', 'PM615052')
                        ->countAllResults();
        $jumlah = $data['jumlah'];

        // Mengambil data daftar kegiatan berdasarkan id
        $datapendaftarModel = new DataPendaftarModel();
        $daftarkegiatanModel = new DaftarKegiatanModel();

        $id = $this->request->getGet('id');
        $data['daftar_kegiatan'] = $daftarkegiatanModel->where('id_daftar_kegiatan', $id)->first();
        $daftar_kegiatan = $data['daftar_kegiatan'];

        // Mengambil data peserta dengan join tabel anggota dan daftar_kegiatan
        $data['data_peserta'] = $datapendaftarModel
                        ->select('*')
                        ->join('anggota', 'id_anggota')
                        ->join('daftar_kegiatan as dk', 'dk.id_daftar_kegiatan = data_pendaftar.id_daftar_kegiatan')
                        ->where('dk.id_daftar_kegiatan', $id)
                        ->where('data_pendaftar.kategori_data', $kat)
                        ->orderBy('anggota.nama')
                        ->get()
                        ->getResultArray();
        $data_peserta = $data['data_peserta'];

        return view('template/headerPengurus', $data) .
            view('pengurus/viewdaftarpeserta') .
            view('template/footerTemplate');
    }

    public function updatekelulusan()
    {
        // Ambil data dari formulir
        $id_peserta = $this->request->getPost('id');
        //$status = $this->request->getPost('status');
        $id_daftar_kegiatan = $this->request->getPost('id_daftar_kegiatan');
        
        // Inisialisasi model
        $datapendaftarModel = new DataPendaftarModel();
        
        // Siapkan data yang akan diupdate
        $state = [
            'status' => $this->request->getPost('status'),
            'id_daftar_kegiatan' => $this->request->getPost('id_daftar_kegiatan')
        ];

        $datapendaftarModel->update($id_peserta, $state);

        // Lakukan pembaruan dengan menggunakan klausa where
        //$datapendaftarModel->where('id_peserta', $id_peserta)->update($data);

        // Redirect atau tampilkan pesan sukses
        return redirect()->to('pengurus/viewdaftarpeserta?id=' . $id_daftar_kegiatan)->with('flash', 'Diedit');
    }

    public function updatekelulusan1()
    {
        // Ambil data dari formulir
        $id_peserta = $this->request->getPost('id');
        //$status = $this->request->getPost('status');
        $id_daftar_kegiatan = $this->request->getPost('id_daftar_kegiatan');
        
        // Inisialisasi model
        $datapendaftarModel = new DataPendaftarModel();
        
        // Siapkan data yang akan diupdate
        $state = [
            'status' => $this->request->getPost('status'),
            'id_daftar_kegiatan' => $this->request->getPost('id_daftar_kegiatan')
        ];

        $datapendaftarModel->update($id_peserta, $state);

        // Lakukan pembaruan dengan menggunakan klausa where
        //$datapendaftarModel->where('id_peserta', $id_peserta)->update($data);

        // Redirect atau tampilkan pesan sukses
        return redirect()->to('pengurus/viewdaftarpeserta?id=' . $id_daftar_kegiatan)->with('flash', 'Diedit');
    }

    public function viewanggota()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $id_pimpinan = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        // Mendapatkan data anggota berdasarkan id_anggota dari input
        $anggotaModel = new AnggotaModel();
        $data['anggota'] = $anggotaModel->find($this->request->getGet('id'));

        // Menampilkan view dengan data yang telah disiapkan
        return view('template/headerPengurus', $data) . 
            view('pengurus/viewanggota') . 
            view('template/footerTemplate');
    }

    public function about()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $id_pimpinan = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        return view('template/headerPengurus', $data) .
            view('pengurus/about') .
            view('template/footerTemplate');
    }

    public function statistikorganisasi()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        // Hitung jumlah anggota
        $anggotaModel = new AnggotaModel();
        $data['anggota'] = $anggotaModel->where('kategori_data', $kat)->countAllResults();
        $data['anggotapc'] = $anggotaModel->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->countAllResults();

        // Hitung jumlah anggota yang belum diverifikasi
        $data['belumverifikasi'] = $anggotaModel->where('kategori_data', $kat)->where('status_verifikasi', 'belum')->countAllResults();
        $data['belumverifikasipc'] = $anggotaModel->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->where('status_verifikasi', 'belum')->countAllResults();

        // Hitung jumlah pimpinan
        $pimpinanCount = $pimpinanModel->where('pimpinan', 'PC')->where('kategori_data', $kat)->countAllResults();
        $data['statistik_pc'] = $pimpinanCount;

        // Data PAC
        $pimpinanAcModel = new PimpinanAcModel();
        $pimpinanAccCount = $pimpinanAcModel->where('pimpinan_ac', 'PAC')->where('status_aktif', 'Aktif')->where('kategori_data', $kat)->countAllResults();
        $data['statistik_ac_aktif'] = $pimpinanAccCount;

        $pimpinanAcCount = $pimpinanAcModel->where('pimpinan_ac', 'PAC')->where('kategori_data', $kat)->countAllResults();
        $data['statistik_ac'] = $pimpinanAcCount;

        $data['id_pimpinan_ac'] = $session->get('id_pimpinan_ac');
        $pimp1 = $data['id_pimpinan_ac'];

        // Data Ranting dan Komisariat
        $pimpinanRkModel = new PimpinanRkModel();
        $ranting_aktif = $pimpinanRkModel->where('kategori_data', $kat)->where('status_aktif', 'Aktif')->where('pimpinan_rk', 'PR')->countAllResults();
        $data['ranting_aktif'] = $ranting_aktif;

        $pimpinanRkkCount = $pimpinanRkModel->where('pimpinan_rk', 'PR')->where('kategori_data', $kat)->countAllResults();
        $data['ranting'] = $pimpinanRkkCount;

        $pimpinanRkCount = $pimpinanRkModel->where('pimpinan_rk', 'PK')->where('status_aktif', 'Aktif')->where('kategori_data', $kat)->countAllResults();
        $data['komisariat_aktif'] = $pimpinanRkCount;

        $pimpinanRktCount = $pimpinanRkModel->where('pimpinan_rk', 'PK')->where('kategori_data', $kat)->countAllResults();
        $data['komisariat'] = $pimpinanRktCount;

        // Hitung jumlah keuangan
        $keuanganModel = new KeuanganModel();

        // Memanggil method untuk menghitung total masuk dan keluar dari model
        $totalMasuk = $keuanganModel->selectSum('masuk')->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->first();
        $totalKeluar = $keuanganModel->selectSum('keluar')->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->first();

        $totalMasuk = isset($totalMasukResult['masuk']) ? $totalMasukResult['masuk'] : 0;
        $totalKeluar = isset($totalKeluarResult['keluar']) ? $totalKeluarResult['keluar'] : 0;

        $selisih = $totalMasuk - $totalKeluar;

        // Menggabungkan total masuk, total keluar, dan selisih ke dalam satu array
        $data['jumlah_keuangan'] = ['masuk' => $totalMasuk, 'keluar' => $totalKeluar, 'selisih' => $selisih];

        $suratMasukModel = new SuratMasukModel();
        $data['sm'] = $suratMasukModel->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->countAllResults();

        return view('template/headerPengurus', $data) . view('pengurus/statistikorganisasi') . view('template/footerTemplate');
    }

    public function statistikcabang()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        // Hitung jumlah anggota
        $anggotaModel = new AnggotaModel();
        $data['surakarta'] = $anggotaModel->where('id_pimpinan', '1')->where('kategori_data', $kat)->countAllResults();
        $data['ksemarang'] = $anggotaModel->where('id_pimpinan', '2')->where('kategori_data', $kat)->countAllResults();
        $data['kendal'] = $anggotaModel->where('id_pimpinan', '3')->where('kategori_data', $kat)->countAllResults();
        $data['lasem'] = $anggotaModel->where('id_pimpinan', '4')->where('kategori_data', $kat)->countAllResults();
        $data['cilacap'] = $anggotaModel->where('id_pimpinan', '5')->where('kategori_data', $kat)->countAllResults();
        $data['jepara'] = $anggotaModel->where('id_pimpinan', '6')->where('kategori_data', $kat)->countAllResults();
        $data['purbalingga'] = $anggotaModel->where('id_pimpinan', '7')->where('kategori_data', $kat)->countAllResults();
        $data['blora'] = $anggotaModel->where('id_pimpinan', '8')->where('kategori_data', $kat)->countAllResults();
        $data['semarang'] = $anggotaModel->where('id_pimpinan', '9')->where('kategori_data', $kat)->countAllResults();
        $data['sragen'] = $anggotaModel->where('id_pimpinan', '10')->where('kategori_data', $kat)->countAllResults();
        $data['sukoharjo'] = $anggotaModel->where('id_pimpinan', '11')->where('kategori_data', $kat)->countAllResults();
        $data['klaten'] = $anggotaModel->where('id_pimpinan', '12')->where('kategori_data', $kat)->countAllResults();
        $data['kmagelang'] = $anggotaModel->where('id_pimpinan', '13')->where('kategori_data', $kat)->countAllResults();
        $data['magelang'] = $anggotaModel->where('id_pimpinan', '14')->where('kategori_data', $kat)->countAllResults();
        $data['pati'] = $anggotaModel->where('id_pimpinan', '15')->where('kategori_data', $kat)->countAllResults();
        $data['boyolali'] = $anggotaModel->where('id_pimpinan', '16')->where('kategori_data', $kat)->countAllResults();
        $data['ktegal'] = $anggotaModel->where('id_pimpinan', '17')->where('kategori_data', $kat)->countAllResults();
        $data['demak'] = $anggotaModel->where('id_pimpinan', '19')->where('kategori_data', $kat)->countAllResults();
        $data['batang'] = $anggotaModel->where('id_pimpinan', '20')->where('kategori_data', $kat)->countAllResults();
        $data['banyumas'] = $anggotaModel->where('id_pimpinan', '21')->where('kategori_data', $kat)->countAllResults();
        $data['karanganyar'] = $anggotaModel->where('id_pimpinan', '22')->where('kategori_data', $kat)->countAllResults();
        $data['wonogiri'] = $anggotaModel->where('id_pimpinan', '23')->where('kategori_data', $kat)->countAllResults();
        $data['brebes'] = $anggotaModel->where('id_pimpinan', '24')->where('kategori_data', $kat)->countAllResults();
        $data['pemalang'] = $anggotaModel->where('id_pimpinan', '25')->where('kategori_data', $kat)->countAllResults();
        $data['rembang'] = $anggotaModel->where('id_pimpinan', '26')->where('kategori_data', $kat)->countAllResults();
        $data['purworejo'] = $anggotaModel->where('id_pimpinan', '27')->where('kategori_data', $kat)->countAllResults();
        $data['wonosobo'] = $anggotaModel->where('id_pimpinan', '28')->where('kategori_data', $kat)->countAllResults();
        $data['kudus'] = $anggotaModel->where('id_pimpinan', '29')->where('kategori_data', $kat)->countAllResults();
        $data['grobogan'] = $anggotaModel->where('id_pimpinan', '30')->where('kategori_data', $kat)->countAllResults();
        $data['kebumen'] = $anggotaModel->where('id_pimpinan', '31')->where('kategori_data', $kat)->countAllResults();
        $data['temanggung'] = $anggotaModel->where('id_pimpinan', '32')->where('kategori_data', $kat)->countAllResults();
        $data['tegal'] = $anggotaModel->where('id_pimpinan', '33')->where('kategori_data', $kat)->countAllResults();
        $data['banjarnegara'] = $anggotaModel->where('id_pimpinan', '34')->where('kategori_data', $kat)->countAllResults();
        $data['salatiga'] = $anggotaModel->where('id_pimpinan', '35')->where('kategori_data', $kat)->countAllResults();
        $data['kpekalongan'] = $anggotaModel->where('id_pimpinan', '36')->where('kategori_data', $kat)->countAllResults();
        $data['pekalongan'] = $anggotaModel->where('id_pimpinan', '37')->where('kategori_data', $kat)->countAllResults();

        return view('template/headerPengurus', $data) . view('pengurus/statistikcabang') . view('template/footerTemplate');
    }

    public function datapac()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        //$id_pimpinan = $this->request->getGet('id');
        //$data['pimpinan_cabang'] = $pimpinanModel->find($id_pimpinan);

        $pimpinanAcModel = new PimpinanAcModel();
        // Ambil data pimpinan dengan kategori 'PAC' dan kategori_data sesuai dengan session
        $data['data_pac'] = $pimpinanAcModel->join('pimpinan', 'id_pimpinan')->where('pimpinan_ac', 'PAC')->where('status_aktif', 'aktif')
                                ->where('pimpinan_ac.kategori_data', $kat)
                                ->orderBy('kd_pimpinan_ac')
                                ->findAll();
        
        $data_pac = $data['data_pac'];

        return view('template/headerPengurus', $data) . view('pengurus/datapac') . view('template/footerTemplate');
    }

    public function datapr()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        //$id_pimpinan = $this->request->getGet('id');
        //$data['pimpinan_cabang'] = $pimpinanModel->find($id_pimpinan);

        $pimpinanAcModel = new PimpinanAcModel();
        $pimpinanRkModel = new PimpinanRkModel();
        // Ambil data pimpinan dengan kategori 'PR' dan kategori_data sesuai dengan session
        $data['data_pr'] = $pimpinanRkModel->join('pimpinan', 'id_pimpinan')->join('pimpinan_ac', 'id_pimpinan_ac')->where('pimpinan_rk', 'PR')->where('pimpinan_rk.status_aktif', 'aktif')
                                ->where('pimpinan_rk.kategori_data', $kat)
                                ->orderBy('kd_pimpinan_rk')
                                ->findAll();
        
        $data_pr = $data['data_pr'];

        return view('template/headerPengurus', $data) . view('pengurus/datapr') . view('template/footerTemplate');
    }

    public function datapk()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        //$id_pimpinan = $this->request->getGet('id');
        //$data['pimpinan_cabang'] = $pimpinanModel->find($id_pimpinan);

        $pimpinanAcModel = new PimpinanAcModel();
        $pimpinanRkModel = new PimpinanRkModel();
        // Ambil data pimpinan dengan kategori 'PR' dan kategori_data sesuai dengan session
        $data['data_pk'] = $pimpinanRkModel->join('pimpinan', 'id_pimpinan')->join('pimpinan_ac', 'id_pimpinan_ac')->where('pimpinan_rk', 'PK')->where('pimpinan_rk.status_aktif', 'aktif')
                                ->where('pimpinan_rk.kategori_data', $kat)
                                ->orderBy('kd_pimpinan_rk')
                                ->findAll();
        
        $data_pk = $data['data_pk'];

        return view('template/headerPengurus', $data) . view('pengurus/datapk') . view('template/footerTemplate');
    }

    public function anggotaformal()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $kaderisasi = $this->request->getGet('id');
        //$data['pimpinan_cabang'] = $pimpinanModel->find($id_pimpinan);

        $pimpinanAcModel = new PimpinanAcModel();
        $pimpinanRkModel = new PimpinanRkModel();
        $anggotaModel = new AnggotaModel();
        // Ambil data pimpinan dengan kategori 'PR' dan kategori_data sesuai dengan session
        $data['anggota'] = $anggotaModel->join('pimpinan', 'id_pimpinan')->where('pelatihan_formal', $kaderisasi)
                                ->where('anggota.kategori_data', $kat)
                                ->orderBy('id_anggota')
                                ->findAll();
        
        $anggota = $data['anggota'];

        return view('template/headerPengurus', $data) . view('pengurus/anggotaformal') . view('template/footerTemplate');
    }

    public function potensikader()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        // Hitung jumlah anggota
        $anggotaModel = new AnggotaModel();
        $data['anggota'] = $anggotaModel->where('kategori_data', $kat)->countAllResults();
        $data['makesta'] = $anggotaModel->where('pelatihan_formal', 'makesta')->where('kategori_data', $kat)->countAllResults();
        $data['lakmud'] = $anggotaModel->where('pelatihan_formal', 'lakmud')->where('kategori_data', $kat)->countAllResults();
        $data['lakut'] = $anggotaModel->where('pelatihan_formal', 'lakut')->where('kategori_data', $kat)->countAllResults();
        $data['cbp'] = $anggotaModel->where('status_cbp', 'ya')->where('kategori_data', $kat)->countAllResults();

        return view('template/headerPengurus', $data) . view('pengurus/potensikader') . view('template/footerTemplate');
    }

    public function minatbakat()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        // Hitung jumlah anggota
        $anggotaModel = new AnggotaModel();
        $data['m1'] = $anggotaModel->where('minat_bakat', 'Seni dan Kreativitas')->where('kategori_data', $kat)->countAllResults();
        $data['m2'] = $anggotaModel->where('minat_bakat', 'Musik')->where('kategori_data', $kat)->countAllResults();
        $data['m3'] = $anggotaModel->where('minat_bakat', 'Tari dan Pertunjukan')->where('kategori_data', $kat)->countAllResults();
        $data['m4'] = $anggotaModel->where('minat_bakat', 'Penulisan dan Literasi')->where('kategori_data', $kat)->countAllResults();
        $data['m5'] = $anggotaModel->where('minat_bakat', 'Olahraga dan Kesehatan')->where('kategori_data', $kat)->countAllResults();
        $data['m6'] = $anggotaModel->where('minat_bakat', 'Ilmu Pengetahuan dan Teknologi')->where('kategori_data', $kat)->countAllResults();
        $data['m7'] = $anggotaModel->where('minat_bakat', 'Kepemimpinan dan Kepanitiaan')->where('kategori_data', $kat)->countAllResults();
        $data['m8'] = $anggotaModel->where('minat_bakat', 'Keterampilan Praktis')->where('kategori_data', $kat)->countAllResults();
        $data['m9'] = $anggotaModel->where('minat_bakat', 'Kepedulian Sosial dan Lingkungan')->where('kategori_data', $kat)->countAllResults();
        $data['m10'] = $anggotaModel->where('minat_bakat', 'Bisnis dan Kewirausahaan')->where('kategori_data', $kat)->countAllResults();
        $data['m11'] = $anggotaModel->where('minat_bakat', 'Budaya dan Bahasa')->where('kategori_data', $kat)->countAllResults();
        $data['m12'] = $anggotaModel->where('minat_bakat', 'Media')->where('kategori_data', $kat)->countAllResults();
        
        return view('template/headerPengurus', $data) . view('pengurus/minatbakat') . view('template/footerTemplate');
    }

    public function anggotacbp()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        //$kaderisasi = $this->request->getGet('id');
        //$data['pimpinan_cabang'] = $pimpinanModel->find($id_pimpinan);

        $pimpinanAcModel = new PimpinanAcModel();
        $pimpinanRkModel = new PimpinanRkModel();
        $anggotaModel = new AnggotaModel();
        // Ambil data pimpinan dengan kategori 'PR' dan kategori_data sesuai dengan session
        $data['anggota'] = $anggotaModel->join('pimpinan', 'id_pimpinan')->where('status_cbp', 'ya')
                                ->where('anggota.kategori_data', $kat)
                                ->orderBy('id_anggota')
                                ->findAll();
        
        $anggota = $data['anggota'];

        return view('template/headerPengurus', $data) . view('pengurus/anggotacbp') . view('template/footerTemplate');
    }

    public function penguruspw()
    {
        $session = session(); 
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $anggotaModel = new AnggotaModel();
        $data['anggota'] = $anggotaModel->join('pimpinan', 'anggota.id_pimpinan = pimpinan.id_pimpinan')->where('anggota.kategori_data', $kat)->orderBy('id_anggota')->where('aktif_kepengurusan', 'PW')->findAll();
        $anggota = $data['anggota'];

        return view('template/headerPengurus', $data) .
            view('pengurus/penguruspw') .
            view('template/footerTemplate');
    }

    public function inventarisbarang()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        //$id = $this->request->getGet('id');
        $inventarisbarangModel = new InventarisBarangModel();
        $data['inventaris_barang'] = $inventarisbarangModel->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->orderBy('nama_barang')->get()->getResultArray();
        
        return view('template/headerPengurus', $data)
            .view('pengurus/inventarisbarang')
            .view('template/footerTemplate');
    }

    public function ininventarisbarang()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter
        
        return view('template/headerPengurus', $data)
            .view('pengurus/ininventarisbarang')
            .view('template/footerTemplate');
    }

    public function addinventarisbarang()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $data = [
            'id_pimpinan' => $pimp,
            'kategori_data' => $kat,
            'index_barang' => $this->request->getPost('index_barang'),
            'nama_barang' => $this->request->getPost('nama_barang'),
            'jumlah' => $this->request->getPost('jumlah'),
            'asal_barang' => $this->request->getPost('asal_barang'),
            'harga_satuan' => $this->request->getPost('harga_satuan'),
            'keterangan' => $this->request->getPost('keterangan')
        ];

        $inventarisBarangModel = new InventarisBarangModel();
        $inventarisBarangModel->insert($data);

        $session->setFlashdata('flash', 'Tersimpan');
        return redirect()->to('/pengurus/inventarisbarang');
    }

    public function viewinventarisbarang()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $id = $this->request->getGet('id');
        $inventarisbarangModel = new InventarisBarangModel();
        $data['inventaris_barang'] = $inventarisbarangModel->where('id_inventaris_barang', $id)->first();
        
        return view('template/headerPengurus', $data)
            .view('pengurus/viewinventarisbarang')
            .view('template/footerTemplate');
    }

    public function editinventarisbarang()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $id = $this->request->getGet('id');
        $inventarisbarangModel = new InventarisBarangModel();
        $data['inventaris_barang'] = $inventarisbarangModel->where('id_inventaris_barang', $id)->first();
        
        return view('template/headerPengurus', $data)
            .view('pengurus/editinventarisbarang')
            .view('template/footerTemplate');
    }

    public function updateinventarisbarang()
    {
        $inventarisbarangModel = new InventarisBarangModel();

        $id_ib = $this->request->getPost('id_inventaris_barang');
        $data = [
            'index_barang' => $this->request->getPost('index_barang'),
            'nama_barang' => $this->request->getPost('nama_barang'),
            'jumlah' => $this->request->getPost('jumlah'),
            'asal_barang' => $this->request->getPost('asal_barang'),
            'harga_satuan' => $this->request->getPost('harga_satuan'),
            'keterangan' => $this->request->getPost('keterangan')
        ];

        $inventarisbarangModel->update($id_ib, $data);

        return redirect()->to('/pengurus/inventarisbarang')->with('flash', 'Diedit');
    }

    public function deleteinventarisbarang()
    {
        $inventarisbarangModel = new InventarisBarangModel();

        $id_ib = $this->request->getGet('id');
        $inventarisbarangModel->delete($id_ib);

        return redirect()->to('/pengurus/inventarisbarang')->with('flash', 'Dihapus');
    }

    public function suratmasuk()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        //$id_anggota = $this->request->getGet('id'); // Menggunakan method getGet untuk mendapatkan data dari query string
        $suratmasukModel = new SuratMasukModel();
        $data['suratmasuk'] = $suratmasukModel->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->orderBy('tanggal_surat_diterima')->get()->getResultArray();
        $suratmasuk = $data['suratmasuk'];

        return view('template/headerPengurus', $data)
            .view('pengurus/suratmasuk')
            .view('template/footerTemplate');
    }

    public function insuratmasuk()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        //$id_anggota = $this->request->getGet('id'); // Menggunakan method getGet untuk mendapatkan data dari query string
        // $suratmasukModel = new SuratMasukModel();
        // $data['suratmasuk'] = $suratmasukModel->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->orderBy('tanggal_surat_diterima')->get()->getResultArray();
        // $suratmasuk = $data['suratmasuk'];

        return view('template/headerPengurus', $data)
            .view('pengurus/insuratmasuk')
            .view('template/footerTemplate');
    }

    public function addsuratmasuk()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        // Konfigurasi upload
        $uploadPath = './upload/suratmasuk/';
        $allowedTypes = 'pdf|jpg|png';
        $uploadConfig = [
            'upload_path' => $uploadPath,
            'allowed_types' => $allowedTypes
        ];

        $request = service('request');

        // Ambil file upload
        $fileSurat = $request->getFile('file_surat');

        // Validasi upload
        if ($fileSurat->isValid() && !$fileSurat->hasMoved()) {
            // Pindahkan file upload ke folder upload
            $newName = $fileSurat->getRandomName();
            $fileSurat->move($uploadPath, $newName);
        

            // Data untuk dimasukkan ke database
            $dataInsert = [
                'id_pimpinan' => $pimp,
                'kategori_data' => $kat,
                'pengirim' => $request->getPost('pengirim'),
                'tanggal_surat_diterima' => $request->getPost('tanggal_surat_diterima'),
                'perihal' => $request->getPost('perihal'),
                'nomor_surat_masuk' => $request->getPost('nomor_surat_masuk'),
                'tanggal_surat' => $request->getPost('tanggal_surat'),
                'tembusan' => $request->getPost('tembusan'),
                'catatan_disposisi' => $request->getPost('catatan_disposisi'),
                'keterangan' => $request->getPost('keterangan'),
                'file_surat' => $newName
            ];
        

            // Masukkan data ke database
            $suratMasukModel = new SuratMasukModel();
            $suratMasukModel->insert($dataInsert);
        }

            // Set flashdata dan redirect
            $session->setFlashdata('flash', 'Tersimpan');
            return redirect()->to('pengurus/suratmasuk');
    }

    public function viewsuratmasuk()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $id = $this->request->getGet('id');
        $suratMasukModel = new SuratMasukModel();
        $data['suratmasuk'] = $suratMasukModel->where('id_surat_masuk', $id)->first();
        
        return view('template/headerPengurus', $data)
            .view('pengurus/viewsuratmasuk')
            .view('template/footerTemplate');
    }

    public function editsuratmasuk()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $id = $this->request->getGet('id');
        $suratMasukModel = new SuratMasukModel();
        $data['suratmasuk'] = $suratMasukModel->where('id_surat_masuk', $id)->first();
        
        return view('template/headerPengurus', $data)
            .view('pengurus/editsuratmasuk')
            .view('template/footerTemplate');
    }

    public function updatesuratmasuk()
    {
        $suratMasukModel = new SuratMasukModel();

        $id_sm = $this->request->getPost('id_surat_masuk');
        $data = [
            'pengirim' => $this->request->getPost('pengirim'),
            'tanggal_surat_diterima' => $this->request->getPost('tanggal_surat_diterima'),
            'perihal' => $this->request->getPost('perihal'),
            'nomor_surat_masuk' => $this->request->getPost('nomor_surat_masuk'),
            'tanggal_surat' => $this->request->getPost('tanggal_surat'),
            'tembusan' => $this->request->getPost('tembusan'),
            'catatan_disposisi' => $this->request->getPost('catatan_disposisi'),
            'keterangan' => $this->request->getPost('keterangan')
        ];

        $suratMasukModel->update($id_sm, $data);

        return redirect()->to('/pengurus/suratmasuk')->with('flash', 'Diedit');
    }

    public function deletesuratmasuk()
    {
        $suratMasukModel = new SuratMasukModel();

        $id_sm = $this->request->getGet('id');
        $suratMasukModel->delete($id_sm);

        return redirect()->to('/pengurus/suratmasuk')->with('flash', 'Dihapus');
    }

    public function suratkeluar()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        //$id_anggota = $this->request->getGet('id'); // Menggunakan method getGet untuk mendapatkan data dari query string
        $suratkeluarModel = new SuratKeluarModel();
        $data['surat_keluar'] = $suratkeluarModel->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->orderBy('tanggal_surat')->get()->getResultArray();
        $surat_keluar = $data['surat_keluar'];

        return view('template/headerPengurus', $data)
            .view('pengurus/suratkeluar')
            .view('template/footerTemplate');
    }

    public function insuratkeluar()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        //$id_anggota = $this->request->getGet('id'); // Menggunakan method getGet untuk mendapatkan data dari query string
        // $suratmasukModel = new SuratMasukModel();
        // $data['suratmasuk'] = $suratmasukModel->where('id_pimpinan', $pimp)->where('kategori_data', $kat)->orderBy('tanggal_surat_diterima')->get()->getResultArray();
        // $suratmasuk = $data['suratmasuk'];

        return view('template/headerPengurus', $data)
            .view('pengurus/insuratkeluar')
            .view('template/footerTemplate');
    }

    public function addsuratkeluar()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $file = $this->request->getFile('file_surat');
        $newName = $file->getRandomName();
        $uploadPath = './upload/suratkeluar/';

        if ($file->isValid() && !$file->hasMoved()) {
            $file->move($uploadPath, $newName);
        }

        $data = [
            'id_pimpinan' => $pimp,
            'kategori_data' => $kat,
            'nomor_surat' => $this->request->getPost('nomor_surat'),
            'index_surat' => $this->request->getPost('index_surat'),
            'tanggal_surat' => $this->request->getPost('tanggal_surat'),
            'tujuan_surat' => $this->request->getPost('tujuan_surat'),
            'perihal' => $this->request->getPost('perihal'),
            'keterangan' => $this->request->getPost('keterangan'),
            'file_surat' => $newName
        ];

        $suratKeluarModel = new SuratKeluarModel();
        $suratKeluarModel->insert($data);

        $session->setFlashdata('flash', 'Tersimpan');
        return redirect()->to('/pengurus/suratkeluar');
    }

    public function viewsuratkeluar()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $id = $this->request->getGet('id');
        $suratkeluarModel = new SuratKeluarModel();
        $data['surat_keluar'] = $suratkeluarModel->where('id_surat_keluar', $id)->first();
        
        return view('template/headerPengurus', $data)
            .view('pengurus/viewsuratkeluar')
            .view('template/footerTemplate');
    }

    public function editsuratkeluar()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $id = $this->request->getGet('id');
        $suratkeluarModel = new SuratKeluarModel();
        $data['surat_keluar'] = $suratkeluarModel->where('id_surat_keluar', $id)->first();
        
        return view('template/headerPengurus', $data)
            .view('pengurus/editsuratkeluar')
            .view('template/footerTemplate');
    }

    public function updatesuratkeluar()
    {
        $suratkeluarModel = new SuratKeluarModel();

        $id_sk = $this->request->getPost('id_surat_keluar');
        $data = [
            'nomor_surat' => $this->request->getPost('nomor_surat'),
            'tanggal_surat' => $this->request->getPost('tanggal_surat'),
            'tujuan_surat' => $this->request->getPost('tujuan_surat'),
            'perihal' => $this->request->getPost('perihal'),
            'keterangan' => $this->request->getPost('keterangan')
        ];

        $suratkeluarModel->update($id_sk, $data);

        return redirect()->to('/pengurus/suratkeluar')->with('flash', 'Diedit');
    }

    public function deletesuratkeluar()
    {
        $suratkeluarModel = new SuratKeluarModel();

        $id_sm = $this->request->getGet('id');
        $suratkeluarModel->delete($id_sm);

        return redirect()->to('/pengurus/suratkeluar')->with('flash', 'Dihapus');
    }

    public function perpustakaan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $perpustakaanModel = new PerpustakaanModel();
        $data['perpustakaan'] = $perpustakaanModel->where('kategori_data', $kat)->orderBy('nama_materi')->get()->getResultArray();
        $perpustakaan = $data['perpustakaan'];

        return view('template/headerPengurus', $data) .view('pengurus/perpustakaan') .view('template/footerTemplate');
    }

    public function inperpustakaan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter
        
        return view('template/headerPengurus', $data)
            .view('pengurus/inperpustakaan')
            .view('template/footerTemplate');
    }

    public function addperpustakaan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $request = $this->request;

        $validationRules = [
            'nama_materi' => 'required',
            'kategori_materi' => 'required',
            'materi' => 'uploaded[materi]|mime_in[materi,application/pdf]|max_size[materi,2048]'
        ];

        if (!$this->validate($validationRules)) {
            return redirect()->back()->withInput()->with('validation', $this->validator);
        }

        $materiFile = $request->getFile('materi');

        if ($materiFile->isValid() && !$materiFile->hasMoved()) {
            $materiName = $materiFile->getRandomName();
            $materiFile->move('./upload/materi', $materiName);

            $perpustakaanModel = new PerpustakaanModel();
            $data = [
                'kategori_data' => $kat,
                'nama_materi' => $request->getPost('nama_materi'),
                'kategori_materi' => $request->getPost('kategori_materi'),
                'materi' => $materiName
            ];

            $perpustakaanModel->insert($data);

            // Set flash data untuk pesan sukses
            session()->setFlashdata('flash', 'Tersimpan');

            // Redirect ke halaman perpustakaan
            return redirect()->to(base_url('pengurus/perpustakaan'));
        } else {
            // Handle error jika file tidak valid
            return redirect()->back()->withInput()->with('error', 'File materi tidak valid.');
        }
    }

    public function deleteperpustakaan()
    {
        $perpustakaanModel = new PerpustakaanModel();

        $id_p = $this->request->getGet('id');
        $perpustakaanModel->delete($id_p);

        return redirect()->to('/pengurus/perpustakaan')->with('flash', 'Dihapus');
    }

    public function keuangan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $keuanganModel = new KeuanganModel();

        $data['keuangan'] = $keuanganModel->where('id_pimpinan', $pimp)
                                            ->where('kategori_data', $kat)
                                            ->orderBy('tanggal_transaksi')
                                            ->findAll();

        $data['masuk'] = $keuanganModel->selectSum('masuk')
                                        ->where('id_pimpinan', $pimp)
                                        ->where('kategori_data', $kat)
                                        ->first();

        $data['keluar'] = $keuanganModel->selectSum('keluar')
                                         ->where('id_pimpinan', $pimp)
                                         ->where('kategori_data', $kat)
                                         ->first();

        return view('template/headerPengurus', $data) .view('pengurus/keuangan') .view('template/footerTemplate');
    }

    public function inkeuangan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter
        
        return view('template/headerPengurus', $data)
            .view('pengurus/inkeuangan')
            .view('template/footerTemplate');
    }

    public function addkeuangan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $data = [
            'id_pimpinan' => $pimp,
            'kategori_data' => $kat,
            'tanggal_transaksi' => $this->request->getPost('tanggal_transaksi'),
            'nama_barang' => $this->request->getPost('nama_barang'),
            'masuk' => $this->request->getPost('masuk'),
            'keluar' => $this->request->getPost('keluar'),
            'jenis_transaksi' => $this->request->getPost('jenis_transaksi'),
            'keterangan' => $this->request->getPost('keterangan')
        ];

        $keuanganModel = new KeuanganModel();
        $keuanganModel->insert($data);

        $session->setFlashdata('flash', 'Tersimpan');
        return redirect()->to('/pengurus/keuangan');
    }

    public function viewkeuangan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $id = $this->request->getGet('id');
        $keuanganModel = new KeuanganModel();
        $data['keuangan'] = $keuanganModel->where('id_keuangan', $id)->first();
        
        return view('template/headerPengurus', $data)
            .view('pengurus/viewkeuangan')
            .view('template/footerTemplate');
    }

    public function editkeuangan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $id = $this->request->getGet('id');
        $keuanganModel = new KeuanganModel();
        $data['keuangan'] = $keuanganModel->where('id_keuangan', $id)->first();
        
        return view('template/headerPengurus', $data)
            .view('pengurus/editkeuangan')
            .view('template/footerTemplate');
    }

    public function updatekeuangan()
    {
        $keuanganModel = new KeuanganModel();

        $id_keu = $this->request->getPost('id_keuangan');
        $data = [
            'tanggal_transaksi' => $this->request->getPost('tanggal_transaksi'),
            'masuk' => $this->request->getPost('masuk'),
            'keluar' => $this->request->getPost('keluar'),
            'jenis_transaksi' => $this->request->getPost('jenis_transaksi'),
            'keterangan' => $this->request->getPost('keterangan')
        ];

        $keuanganModel->update($id_keu, $data);

        return redirect()->to('/pengurus/keuangan')->with('flash', 'Diedit');
    }

    public function deletekeuangan()
    {
        $keuanganModel = new KeuanganModel();

        $id_keu = $this->request->getGet('id');
        $keuanganModel->delete($id_keu);

        return redirect()->to('/pengurus/keuangan')->with('flash', 'Dihapus');
    }

    public function laporankeuangan()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $keuanganModel = new KeuanganModel();

        $data['keuangan'] = $keuanganModel->where('id_pimpinan', $pimp)->where('jenis_transaksi', 'Masuk')
                                            ->where('kategori_data', $kat)
                                            ->orderBy('tanggal_transaksi')
                                            ->findAll();

        $data['keuangan0'] = $keuanganModel->where('id_pimpinan', $pimp)->where('jenis_transaksi', 'Keluar')
        ->where('kategori_data', $kat)
        ->orderBy('tanggal_transaksi')
        ->findAll();

        $data['masuk'] = $keuanganModel->selectSum('masuk')
                                        ->where('id_pimpinan', $pimp)
                                        ->where('kategori_data', $kat)
                                        ->first();

        $data['keluar'] = $keuanganModel->selectSum('keluar')
                                         ->where('id_pimpinan', $pimp)
                                         ->where('kategori_data', $kat)
                                         ->first();

        return view('template/headerPengurus', $data) .view('pengurus/laporankeuangan') .view('template/footerTemplate');
    }

    public function dataalumni()
    {
        $session = session();
        if (!$this->isLoggedIn()) {
            return redirect()->to('/Auth/loginpengurus'); // Redirect ke halaman login jika belum login
        }

        // Data default parameter
        $pengurusModel = new PengurusModel();
        $data['admin_users'] = $pengurusModel->where('email', $session->get('email'))->first();

        $data['kategori_data'] = $session->get('kategori');
        $kat = $data['kategori_data'];

        $data['nama_bidang'] = $session->get('nama_bidang');
        $nama_bidang = $data['nama_bidang'];

        $data['id_pengurus'] = $session->get('id_pengurus');
        $id_pengurus = $data['id_pengurus'];

        $data['id_pimpinan'] = $session->get('id_pimpinan');
        $pimp = $data['id_pimpinan'];

        $pimpinanModel = new PimpinanModel();
        $data['pimpinan_default'] = $pimpinanModel->where('id_pimpinan', $session->get('id_pimpinan'))->first();
        // Batas default parameter

        $anggotaModel = new AnggotaModel();
        $data['anggota'] = $anggotaModel->join('pimpinan', 'anggota.id_pimpinan = pimpinan.id_pimpinan')->where('anggota.kategori_data', $kat)->where('status_alumni', ['ya'])->orderBy('id_anggota')->findAll();
        $anggota = $data['anggota'];

        return view('template/headerPengurus', $data) .
            view('pengurus/dataalumni') .
            view('template/footerTemplate');

    }

    private function isLoggedIn()
    {
        // Ambil instance session
        $session = session();

        // Periksa apakah data sesi yang menandakan pengguna sudah login ada
        return $session->has('logged_in') && $session->get('logged_in') === true;
    }
}