<?php

namespace App\Controllers\Auth;

use CodeIgniter\Controller;
use App\Models\PengurusModel;

class Loginpengurus extends Controller
{
    public function index()
    {
        // Load halaman login
        return view('Auth/loginpengurus');
    }

    // Login
    public function prosesLogin()
    {
    
    $session = session();

    $email = $this->request->getPost('email');
    $password = $this->request->getPost('password');

    $pengurusModel = new PengurusModel();
    $userName = $pengurusModel->where('email', $email)->first();

    // Jika username ada sesuai dengan database
    if ($userName) {
        if (password_verify($password, $userName['password'])) {
            // Login berhasil
            $data = [
                'email' => $userName['email'],
                'password' => $userName['password'],
                'nama_bidang' => $userName['nama_bidang'],
                'id_pengurus' => $userName['id_pengurus'],
                'id_pimpinan' => $userName['id_pimpinan'],
                'kategori' => $userName['kategori_data'],
                'status' => 'pengurus',
                'logged_in' => true,
            ];

            $session->set($data);
            return redirect()->to('/pengurus/dashboard'); // Dashboard Pengurus
        } else {
            // Password salah
            return redirect()->back()->withInput()->with('error', 'Password salah.');
        }
    } else {
        // Pengguna tidak ditemukan
        return redirect()->back()->withInput()->with('error', 'Email tidak ditemukan.');
    }
    }

    private function isLoggedIn()
    {
        // Ambil instance session
        $session = session();

        // Periksa apakah data sesi yang menandakan pengguna sudah login ada
        return $session->has('logged_in') && $session->get('logged_in') === true;
    }
}