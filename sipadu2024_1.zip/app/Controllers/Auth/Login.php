<?php

namespace App\Controllers\Auth;

use CodeIgniter\Controller;
use App\Models\UserModel;

class Login extends Controller
{
    public function index()
    {
        // Load halaman login
        return view('Auth/login');
    }

    // Login
    public function prosesLogin()
    {
    
    $session = session();

    $username = $this->request->getPost('username');
    $password = $this->request->getPost('password');

    $userModel = new UserModel();
    $userName = $userModel->where('email', $username)->first();

    // Jika username ada sesuai dengan database
    if ($userName) {
        if (password_verify($password, $userName['password'])) {
            // Login berhasil
            $data = [
                'email' => $userName['email'],
                'password' => $userName['password'],
                'level' => $userName['level'],
                'id_pimpinan' => $userName['id_pimpinan'],
                'tingkatan' => $userName['tingkatan'],
                'kategori' => $userName['kategori_user'],
                'ket' => $userName['ket'],
                'kec' => $userName['pac'],
                'status' => 'admin',
                'logged_in' => true,
            ];

            $session->set($data);
            return redirect()->to('/admin/dashboard'); // Dashboard Pengurus
        } else {
            // Password salah
            return redirect()->back()->withInput()->with('error', 'Password salah.');
        }
    } else {
        // Pengguna tidak ditemukan
        return redirect()->back()->withInput()->with('error', 'Email tidak ditemukan.');
    }
    }

    private function isLoggedIn()
    {
        // Ambil instance session
        $session = session();

        // Periksa apakah data sesi yang menandakan pengguna sudah login ada
        return $session->has('logged_in') && $session->get('logged_in') === true;
    }
}