<?php

namespace App\Controllers\Auth;

use CodeIgniter\Controller;
use App\Models\AnggotaModel;

class Loginanggota extends Controller
{
    public function index()
    {
        // Load halaman login
        return view('Auth/loginanggota');
    }

    // Login
    public function prosesLogin()
    {
    
    $session = session();

    $nia = $this->request->getPost('nia');
    $password = $this->request->getPost('password');

    $anggotaModel = new AnggotaModel();
    $userName = $anggotaModel->where('nia', $nia)->first();

    // Jika username ada sesuai dengan database
    if ($userName) {
        if (password_verify($password, $userName['password'])) {
            // Login berhasil
            $data = [
                'nia' => $userName['nia'],
                'password' => $userName['password'],
                'nama' => $userName['nama'],
                'id_anggota' => $userName['id_anggota'],
                'id_pimpinan' => $userName['id_pimpinan'],
                'id_pimpinan_ac' => $userName['id_pimpinan_ac'],
                'id_pimpinan_rk' => $userName['id_pimpinan_rk'],
                'tingkatan' => $userName['aktif_kepengurusan'],
                'pelatihan_formal' => $userName['pelatihan_formal'],
                'kategori' => $userName['kategori_data'],
                'status' => 'anggota',
                'logged_in' => true,
            ];

            $session->set($data);
            return redirect()->to('/anggota/dashboard'); // Dashboard Pengurus
        } else {
            // Password salah
            return redirect()->back()->withInput()->with('error', 'Password salah.');
        }
    } else {
        // Pengguna tidak ditemukan
        return redirect()->back()->withInput()->with('error', 'NIA tidak ditemukan.');
    }
    }

    private function isLoggedIn()
    {
        // Ambil instance session
        $session = session();

        // Periksa apakah data sesi yang menandakan pengguna sudah login ada
        return $session->has('logged_in') && $session->get('logged_in') === true;
    }
}