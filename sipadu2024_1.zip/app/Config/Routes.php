<?php

$routes->setDefaultController('Home');
$routes->setAutoRoute(true);

// Auth Admin Login & Logout
$routes->post('Auth/login', 'Auth\Login::proseslogin');
$routes->add('Auth/login', 'Auth\Login::index');
$routes->add('Auth/logout', 'Auth\Logout::index');

// Auth Anggota Login & Logout
$routes->post('Auth/loginanggota', 'Auth\Loginanggota::proseslogin');
$routes->add('Auth/loginanggota', 'Auth\Loginanggota::index');
$routes->add('Auth/logoutanggota', 'Auth\Logoutanggota::index');

// Auth Pengurus Login & Logout
$routes->post('Auth/loginpengurus', 'Auth\Loginpengurus::proseslogin');
$routes->add('Auth/loginpengurus', 'Auth\Loginpengurus::index');
$routes->add('Auth/logoutpengurus', 'Auth\Logoutpengurus::index');
