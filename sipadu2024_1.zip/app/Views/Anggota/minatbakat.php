<style type="text/css">
	.fileUpload {
	    position: relative;
	    overflow: hidden;
	    border-radius: 0px;
	    margin-left: -4px;
	    margin-top: -2px;
	}
	.fileUpload input.upload {
	    position: absolute;
	    top: 0;
	    right: 0;
	    margin: 0;
	    padding: 0;
	    font-size: 20px;
	    cursor: pointer;
	    opacity: 0;
	    filter: alpha(opacity=0);
	}
</style>

<script type="text/javascript">
	$(document).ready(function(){
		document.getElementById("uploadBtn").onchange = function () {
			document.getElementById("uploadFile").value = this.value;
		};
	});
</script>

  <!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Minat dan Bakat</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Anggota</a></li>
              <li class="breadcrumb-item active">Minat dan Bakat</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
    <div class="flash-data" data-flashdata="<?= session()->getFlashdata('flash'); ?>"></div>
      <div class="container-fluid">
        <!-- SELECT2 EXAMPLE -->
        <div class="card card-default">
          <div class="card-header">
            <h3 class="card-title">Tambah Minat dan Bakat</h3>

            <div class="card-tools">
              <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
              <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body table-responsive p-o">
            <form action="<?=base_url()?>anggota/updateminatbakat" method="post" enctype="multipart/form-data" name="form1" id="form1">
            <table class='table'>
            <tr>
            <td>Nama Lengkap</td>
            <td colspan="3"><input required="required" readonly="readonly" class="form-control" type="text" name="nama" value="<?= $anggota['nama']; ?>" placeholder="Nama Lengkap" /><br/>
              <input type="hidden" name="id" value="<?= $anggota['id_anggota'];?>"/>
            </td>
            </tr>
             <tr><td>Minat dan Bakat</td>
              <!-- <td colspan="3"><input required="required" class="form-control" type="text" name="status_alumni" value="<?= $anggota['minat_bakat'];?>" placeholder="Status Alumni" /></td> -->
              <td colspan="3"> <select class="form-control" name="minat_bakat" id="minat_bakat">
									<option value="<?= $anggota['minat_bakat'];?>"><?= $anggota['minat_bakat'];?></option>
									<option value=""><b>----Pilih Untuk Edit-----</b></option>
									<option value="Seni dan Kreativitas"> Seni dan Kreativitas</option>
									<option value="Musik"> Musik</option>
                  <option value="Tari dan Pertunjukan"> Tari dan Pertunjukan</option>
                  <option value="Penulisan dan Literasi"> Penulisan dan Literasi</option>
                  <option value="Olahraga dan Kesehatan"> Olahraga dan Kesehatan</option>
                  <option value="Ilmu Pengetahuan dan Teknologi"> Ilmu Pengetahuan dan Teknologi</option>
                  <option value="Kepemimpinan dan Kepanitiaan"> Kepemimpinan dan Kepanitiaan</option>
                  <option value="Bisnis dan Kewirausahaan"> Bisnis dan Kewirausahaan</option>
                  <option value="Budaya dan Bahasa"> Budaya dan Bahasa</option>
                  <option value="Media"> Media</option>
                  <option value="Keterampilan Praktis"> Keterampilan Praktis</option>
                  <option value="Kepedulian Sosial dan Lingkungan"> Kepedulian Sosial dan Lingkungan</option>
                  <option value="Lainnya"> Lainnya</option>
									</select></td>
             </tr>
             <tr>
              <td>Detail Minat dan Bakat</td>
                 <td colspan="3"><textarea class="form-control"  name="detail_minat" id="detail_minat"
                   style="height: 50px;width: 100%;"><?= $anggota['detail_minat'];?></textarea></td>
              </tr>
              <tr>
              <td>Prestasi</td>
                 <td colspan="3"><textarea class="form-control"  name="prestasi" id="prestasi"
                   style="height: 50px;width: 100%;"><?= $anggota['prestasi'];?></textarea></td>
              </tr>
                  <tr>
                <td></td>
                  <td colspan="3"><input class="btn btn-info"  type="submit" value="Save Update" /></td>
                  <input type="hidden" name="MM_insert" value="form1" />
                  </tr>
              </table>
             </form>
          </div>
          <!-- /.card-body -->
          <div class="card-footer">

          </div>
        </div>
        <!-- /.card -->
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
  <!-- /.content-wrapper -->
