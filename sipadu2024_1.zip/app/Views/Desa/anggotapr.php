<?php error_reporting(0); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Data Anggota</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Admin</a></li>
              <li class="breadcrumb-item active">Data Anggota</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <section class="content">
      <div class="row">
        <div class="col-12">
        <div class="card">
            <div class="card-body">

            <div class="card-header">
              <h3 class="card-title">Data Anggota <?= $get_rk['pimpinan_rk']; ?> <?= $get_rk['nama_pimpinan_rk']; ?> PAC <?= $get_pac['nama_pimpinan_ac']; ?> - <?= $get_pc['nama_pimpinan']; ?></h3>
              <a target="_blank" class="btn btn-warning" style="float:right;" href="<?=base_url(); ?>user/printanggotark?id=<?php echo $_GET['id']; ?>&id2=<?php echo $_GET['id2']; ?>&id3=<?php echo $_GET['id3']; ?>"><i class="fas fa-print"></i> Print</a>
              <a target="_blank" class="btn btn-info" style="float:right;margin-right:5px;" href="<?=base_url(); ?>user/exportanggotark?id=<?php echo $_GET['id']; ?>&id2=<?php echo $_GET['id2']; ?>&id3=<?php echo $_GET['id3']; ?>"><i class="fas fa-download"></i> Export Excel</a>
            </div>
            <!-- /.card-header -->
            <div class="card-body table-responsive p-o">
              <table id="example1" class="table">
                <thead>
                <tr>
                  <th>#</th>
                  <th>NIA</th>
                  <th>Nama</th>
                  <th>Keanggotaan</th>
                  <th>Alamat</th>
                  <th>Aksi</th>
                </tr>
                </thead>
                <tbody>
                  <?php $no=1; ?>
                <?php foreach ($anggota as $ang): ?>
                <tr>
                  <td><?php echo $no++; ?></td>
                  <td>
                    <?php if ($tingkatan ==='PC'){?>
                      <?= $ang['nia']; ?>
                    <?php } elseif ($tingkatan ==='PR'){?>
                        <?php if ($ang['status_verifikasi']=='sudah'){?>
                          <?= $ang['nia']; ?>
                        <?php }else { echo "<span style='padding-left:5px;padding-right:5px;font-size:14px;' class='btn-danger'>Belum Terverifikasi</span>"; } ?>
                        <?php } elseif ($tingkatan ==='PK'){?>
                        <?php if ($ang['status_verifikasi']=='sudah'){?>
                          <?= $ang['nia']; ?>
                        <?php }else { echo "<span style='padding-left:5px;padding-right:5px;font-size:14px;' class='btn-danger'>Belum Terverifikasi</span>"; } ?>
                        <?php }?>
                  </td>
                  <td><b><?= $ang['nama']; ?></b></td>
                  <td><?= $ang['nama_pimpinan_rk']; ?></td>
                  <td><?= $ang['alamat_lengkap']; ?></td>
                  <td><a class='btn btn-info btn-flat' title='view Detail' href='<?=base_url()?>rumah/viewanggota?id=<?= $ang['id_anggota']; ?>'>
                    <span class='fas fa-th-list'></span></a></td>
                </tr>
                <?php endforeach; ?>
                </tbody>

              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>

