<?php error_reporting(0); ?>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Transaksi Keuangan</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Keuangan</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
    <div class="flash-data" data-flashdata="<?= session()->getFlashdata('flash'); ?>"></div>
      <div class="row">
        <div class="col-12">

          <div class="card">
            <div class="card-header">
            <?php if($tingkatan=='PR'){ ?>
              <h3 class="card-title"><?php if($kategori_data==1){ echo 'PR IPNU'; }else{ echo'PR IPPNU';} ?> <b><?= $pimpinan_defaultrk['nama_pimpinan_rk']?></b></h3>
              <?php }else{ ?>
                <h3 class="card-title"><?php if($kategori_data==1){ echo 'PK IPNU'; }else{ echo'PK IPPNU';} ?> <b><?= $pimpinan_defaultrk['nama_pimpinan_rk']?></b></h3>
                <?php } ?>
              <div style="float:right;">
              <a target="_blank" class='btn btn-danger' title='Print' href='<?=base_url()?>admin/printkeuangan'>
                <span class='fas fa-print'> </span> Print</a>
              <a target="_blank" class="btn btn-warning"  href="<?=base_url(); ?>admin/exportkeuangan">
                  <i class="fas fa-download"></i> Export Excel</a>
              <a class='btn btn-info' title='Buat Surat' href='<?=base_url()?>rumah/inkeuangan'>
                   New Data</a>
              </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body table-responsive p-o">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Tanggal Transaksi</th>
                  <th>Keterangan</th>
                  <th>Masuk (Rp)</th>
                  <th>Keluar (Rp)</th>
                  <th>Saldo (Rp)</th>
                  <th>Aksi</th>
                </tr>
                </thead>
                <tbody>
                <?php $no=1; ?>
                <?php $saldo=0; ?>
                <?php $saldo=$saldo+$keuangan['masuk']; ?>
                  <?php $saldo=$saldo-$keuangan['keluar']; ?>
                <?php foreach ($keuangan as $uang): ?>
                <tr>
                  <td><?php echo $no++; ?></td>
                  <td><?= date('d M Y', strtotime($uang['tanggal_transaksi'])); ?></td>
                  <td><?= $uang['keterangan']; ?></td>
                  <td><?= number_format(floatval($uang['masuk'])); ?></td>
                    <td><?= number_format(floatval($uang['keluar'])); ?></td>
                  
				    <?php $saldo = $saldo + floatval($uang['masuk']); ?>
                    <?php $saldo = $saldo - floatval($uang['keluar']); ?>
                    <td><?= number_format($saldo); ?></td>
                  <td>
                    <a class='btn btn-warning' title='Detail' href='<?=base_url()?>rumah/viewkeuangan?id=<?= $uang['id_keuangan']; ?>'>
                    <span class='fas fa-th-list'></span></a>
                    <a class='btn btn-info' title='Edit Data' href='<?=base_url()?>rumah/editkeuangan?id=<?= $uang['id_keuangan']; ?>'><span class='fa fa-edit'></span></a>
                  <a class='btn btn-danger tombol-hapus' title='Hapus Data' href='<?=base_url()?>rumah/deletekeuangan?id=<?= $uang['id_keuangan']; ?>'><span class='fas fa-trash'></span></a></td>
                </tr>
                <?php endforeach; ?>
                <td></td><td colspan="2">Jumlah</td><td>Rp <?= number_format($masuk['masuk']);?>,-</td><td>Rp <?= number_format($keluar['keluar']);?>,-</td><td><b>Rp <?= number_format($masuk['masuk']-$keluar['keluar']);?>,-</b></td><td></td>

                </tbody>
              </table>
							<br/>
							
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
