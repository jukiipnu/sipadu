<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Daftar Peserta <?= $daftar_kegiatan['nama_kegiatan'];?></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Admin</a></li>
              <li class="breadcrumb-item active">Kegiatan</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
    <div class="flash-data" data-flashdata="<?= session()->getFlashdata('flash'); ?>"></div>
      <div class="row">
        <div class="col-12"> 

          <div class="card">
            <div class="card-header">
              <h3 class="card-title"><?php if($kategori_data==1){ echo 'PW IPNU'; }else{ echo'PW IPPNU';} ?> Provinsi Jawa Tengah</h3>
              <div style="float:right;">
              <a target="_blank" class='btn btn-danger' title='Print' href='<?=base_url()?>admin/printdaftarpeserta?id=<?= $daftar_kegiatan['id_daftar_kegiatan']; ?>'>
                <span class='fas fa-print'> </span> Print</a>
              <a target="_blank" class="btn btn-warning"  href="<?=base_url(); ?>admin/exportdaftarpeserta?id=<?= $daftar_kegiatan['id_daftar_kegiatan']; ?>">
                    <i class="fas fa-download"></i> Export Excel</a>
              
              </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body table-responsive p-o">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No</th>
                  <th>NIA</th>
                  <th>Nama</th>
                  
                  <th>Alamat</th>
                  <th>Status</th>
                  <th>Detail</th>
                  <th>Aksi</th>
                </tr>
                </thead>
                <tbody>
                <?php $no=1; ?>
                <?php foreach ($data_peserta as $ang): ?>
                <tr>
                  <td><?php echo $no++; ?></td>
                  <td><?= $ang['nia']; ?></td>
                  <td><b><?= $ang['nama']; ?></b></td>
                  
                  <td><?= $ang['alamat_lengkap']; ?></td>
                  <td><?php if ($ang['status']=='2'){ echo"<span style='padding-left:5px;padding-right:5px;font-size:14px;' class='btn-success'>Diterima</span>" ;}
                            elseif ($ang['status']=='1'){ echo"<span style='padding-left:5px;padding-right:5px;font-size:14px;' class='btn-info'>Belum Diverifikasi</span>" ;}
                            else{ echo "<span style='padding-left:5px;padding-right:5px;font-size:14px;' class='btn-danger'>Gagal</span>";} ?></td>
                 
                  <td>
                  <a class='btn btn-warning' title='view Detail' href='<?=base_url()?>admin/viewanggota?id=<?= $ang['id_anggota']; ?>'>
                      <span class='fas fa-th-list'></span></a>
                </td>
                <td>
                <?php if (!empty($ang['id_daftar_kegiatan'])): ?>
                    <form action="<?=base_url()?>admin/updatekelulusan" method="post">                    
                        <input type="hidden" name="id" value="<?= $ang['id_peserta']; ?>"/>
                        <input type="hidden" name="status" value="0"/>                     
                        <input type="hidden" name="id_daftar_kegiatan" value="<?= $ang['id_daftar_kegiatan']; ?>"/>                  
                        <button style="border:none;" type="submit">
                            <span class='btn btn-danger'><i class="fas fa-trash"></i></span>
                        </button>
                    </form>
                    <form action="<?=base_url()?>admin/updatekelulusan1" method="post">                    
                        <input type="hidden" name="id" value="<?= $ang['id_peserta']; ?>"/>                     
                        <input type="hidden" name="status" value="2"/>
                        <input type="hidden" name="id_daftar_kegiatan" value="<?= $ang['id_daftar_kegiatan']; ?>"/>                  
                        <button style="border:none;" type="submit">
                            <span class='btn btn-success'><i class="fas fa-check"></i></span>
                        </button>
                    </form>
                <?php endif; ?>

                    </td>
                <?php endforeach; ?> 

                </tbody>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <form action="<?=base_url()?>admin/daftarkegiatan" method="post">
          <button style="border:none;" type="submit">
                            <span class='btn btn-danger'>Back</span>
                        </button></form>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
