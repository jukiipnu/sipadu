<style type="text/css">
	.fileUpload {
	    position: relative;
	    overflow: hidden;
	    border-radius: 0px;
	    margin-left: -4px;
	    margin-top: -2px;
	}
	.fileUpload input.upload {
	    position: absolute;
	    top: 0;
	    right: 0;
	    margin: 0;
	    padding: 0;
	    font-size: 20px;
	    cursor: pointer;
	    opacity: 0;
	    filter: alpha(opacity=0);
	}
</style>

<script type="text/javascript">
	$(document).ready(function(){
		document.getElementById("uploadBtn").onchange = function () {
			document.getElementById("uploadFile").value = this.value;
		};
	});
</script>


  <!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Statistik Organisasi</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Pengurus</a></li>
              <li class="breadcrumb-item active">Statistik</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- SELECT2 EXAMPLE -->
        <div class="card card-default">
          <div class="card-header">
            <h3 class="card-title">Statistik Organisasi</h3>

            <div class="card-tools">
              <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
              <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <div class="row">
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-danger">
                  <div class="inner">
                    <h3><?= $banjarnegara;?></h3>
                    <p>Banjarnegara</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-info">
                  <div class="inner">
                    <h3><?= $banyumas;?></h3>
                    <p>Banyumas</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-success">
                  <div class="inner">
                    <h3><?= $batang;?></h3>
                    <p>Batang</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-warning">
                  <div class="inner">
                    <h3><?= $blora;?></h3>
                    <p>Blora</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-danger">
                  <div class="inner">
                    <h3><?= $boyolali;?></h3>
                    <p>Boyolali</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-info">
                  <div class="inner">
                    <h3><?= $brebes;?></h3>
                    <p>Brebes</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>

              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-success">
                  <div class="inner">
                    <h3><?= $cilacap;?></h3>
                    <p>Cilacap</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-warning">
                  <div class="inner">
                    <h3><?= $demak;?></h3>
                    <p>Demak</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-danger">
                  <div class="inner">
                    <h3><?= $grobogan;?></h3>
                    <p>Grobogan</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-info">
                  <div class="inner">
                    <h3><?= $jepara;?></h3>
                    <p>Jepara</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-success">
                  <div class="inner">
                    <h3><?= $karanganyar;?></h3>
                    <p>Karanganyar</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-warning">
                  <div class="inner">
                    <h3><?= $kebumen;?></h3>
                    <p>Kebumen</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-info">
                  <div class="inner">
                    <h3><?= $kendal;?></h3>
                    <p>Kendal</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-success">
                  <div class="inner">
                    <h3><?= $klaten;?></h3>
                    <p>Klaten</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-warning">
                  <div class="inner">
                    <h3><?= $kudus;?></h3>
                    <p>Kudus</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-danger">
                  <div class="inner">
                    <h3><?= $magelang;?></h3>
                    <p>Magelang</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-info">
                  <div class="inner">
                    <h3><?= $pati;?></h3>
                    <p>Pati</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>

              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-success">
                  <div class="inner">
                    <h3><?= $pekalongan;?></h3>
                    <p>Pekalongan</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-warning">
                  <div class="inner">
                    <h3><?= $pemalang;?></h3>
                    <p>Pemalang</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-danger">
                  <div class="inner">
                    <h3><?= $purbalingga;?></h3>
                    <p>Purbalingga</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-info">
                  <div class="inner">
                    <h3><?= $purworejo;?></h3>
                    <p>Purworejo</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-success">
                  <div class="inner">
                    <h3><?= $rembang;?></h3>
                    <p>Rembang</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-warning">
                  <div class="inner">
                    <h3><?= $semarang;?></h3>
                    <p>Semarang</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-danger">
                  <div class="inner">
                    <h3><?= $sragen;?></h3>
                    <p>Sragen</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>

              
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-success">
                  <div class="inner">
                    <h3><?= $sukoharjo;?></h3>
                    <p>Sukoharjo</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-warning">
                  <div class="inner">
                    <h3><?= $tegal;?></h3>
                    <p>Tegal</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-danger">
                  <div class="inner">
                    <h3><?= $temanggung;?></h3>
                    <p>Temanggung</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-info">
                  <div class="inner">
                    <h3><?= $wonogiri;?></h3>
                    <p>Wonogiri</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>

              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-success">
                  <div class="inner">
                    <h3><?= $wonosobo;?></h3>
                    <p>Wonosobo</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-warning">
                  <div class="inner">
                    <h3><?= $kmagelang;?></h3>
                    <p>K. Magelang</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-danger">
                  <div class="inner">
                    <h3><?= $kpekalongan;?></h3>
                    <p>K. Pekalongan</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-info">
                  <div class="inner">
                    <h3><?= $salatiga;?></h3>
                    <p>Salatiga</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-success">
                  <div class="inner">
                    <h3><?= $ksemarang;?></h3>
                    <p>K. Semarang</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-warning">
                  <div class="inner">
                    <h3><?= $surakarta;?></h3>
                    <p>Surakarta</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-danger">
                  <div class="inner">
                    <h3><?= $ktegal;?></h3>
                    <p>Kota Tegal</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-1 col-6">
                <!-- small box -->
                <div class="small-box bg-info">
                  <div class="inner">
                    <h3><?= $lasem;?></h3>
                    <p>Lasem</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                </div>
              </div>
				
          </div>
          <!-- /.card-body -->
          <div class="card-footer">

          </div>
          <div id="container"></div>
  <div class="card-body table-responsive p-o">  
    <script src="https://cdn.syncfusion.com/ej2/dist/ej2.min.js" type="text/javascript"></script>
    <script>

     var chart = new ej.charts.Chart({
                  tooltip: {enable: true},
         //Initializing Primary X Axis
         primaryXAxis: {
             valueType: 'Category',
             title: 'Pimpinan',
         },
         //Initializing Primary Y Axis
          primaryYAxis: {
             title: 'Jumlah'
         },

         //Initializing Chart Series
         series: [
             {
                 type: 'Column',
                 dataSource: [
                     
                     { country: "Banjarnegara", medal: <?= $banjarnegara;?> },
                     { country: "Banyumas", medal: <?= $banyumas;?> },
                     { country: "Batang", medal: <?= $batang; ?> },
                     { country: "Blora", medal: <?= $blora;?> },
                     { country: "Boyolali", medal: <?= $boyolali;?> },
                     { country: "Brebes", medal: <?= $brebes;?> },
                     { country: "Cilacap", medal: <?= $cilacap;?> },
                     { country: "Demak", medal: <?= $demak; ?> },
                     { country: "Grobogan", medal: <?= $grobogan;?> },
                     { country: "Jepara", medal: <?= $jepara;?> },
                     { country: "Karanganyar", medal: <?= $karanganyar;?> },
                     { country: "Kebumen", medal: <?= $kebumen;?> },
                     { country: "Kendal", medal: <?= $kendal; ?> },
                     { country: "Klaten", medal: <?= $klaten;?> },
                     { country: "Kudus", medal: <?= $kudus;?> },
                     { country: "Magelang", medal: <?= $magelang;?> },
                     { country: "Pati", medal: <?= $pati;?> },
                     { country: "Pekalongan", medal: <?= $pekalongan; ?> },
                     { country: "Pemalang", medal: <?= $pemalang;?> },
                     { country: "Purbalingga", medal: <?= $purbalingga;?> },
                     { country: "Purworejo", medal: <?= $purworejo;?> },
                     { country: "Rembang", medal: <?= $rembang;?> },
                     { country: "Semarang", medal: <?= $semarang; ?> },
                     { country: "Sragen", medal: <?= $sragen;?> },
                     { country: "Sukoharjo", medal: <?= $sukoharjo;?> },
                     { country: "Tegal", medal: <?= $tegal;?> },
                     { country: "Temanggung", medal: <?= $temanggung;?> },
                     { country: "Wonogiri", medal: <?= $wonogiri; ?> },
                     { country: "Wonosobo", medal: <?= $wonosobo;?> },
                     { country: "Kota Magelang", medal: <?= $kmagelang;?> },
                     { country: "Kota Pekalongan", medal: <?= $kpekalongan;?> },
                     { country: "Kota Surakarta", medal: <?= $salatiga;?> },
                     { country: "Kota Semarang", medal: <?= $ksemarang; ?> },
                     { country: "Kota Surakarta", medal: <?= $surakarta;?> },
                     { country: "Kota Tegal", medal: <?= $ktegal;?> },
                     { country: "Lasem", medal: <?= $lasem;?> },
                 ],
                 xName: 'country',
                 yName: 'medal',
             }
         ],
     });
     chart.appendTo('#container');
    </script>

    </div>
  </div>
        </div>
        <!-- /.card -->
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    
    <!-- /.content -->
    </section>
  <!-- /.content-wrapper -->
  

</div>
    