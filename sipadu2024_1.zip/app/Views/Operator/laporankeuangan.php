<?php error_reporting(0); ?>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Laporan Keuangan Keuangan</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Keuangan</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
    <div class="flash-data" data-flashdata="<?= session()->getFlashdata('flash'); ?>"></div>
      <div class="row">
        <div class="col-12">

          <div class="card">
            <div class="card-header">
            <?php if($tingkatan=='PC'){ ?>
              <h3 class="card-title"><?php if($kategori_data==1){ echo 'PC IPNU'; }else{ echo'PC IPPNU';} ?> <b><?= $pimpinan_default['nama_pimpinan']?></b></h3>
              <?php }else{ ?>
                <h3 class="card-title"><?php if($kategori_data==1){ echo 'PAC IPNU'; }else{ echo'PAC IPPNU';} ?> <b><?= $pimpinan_defaultpac['nama_pimpinan_ac']?></b></h3>
                <?php } ?>
              <div style="float:right;">
              <a target="_blank" class='btn btn-danger' title='Print' href='<?=base_url()?>admin/printlaporankeuangan'>
                <span class='fas fa-print'> </span> Print</a>
              <a target="_blank" class="btn btn-warning"  href="<?=base_url(); ?>admin/exportlaporankeuangan">
                  <i class="fas fa-download"></i> Export Excel</a>
              </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body table-responsive p-o">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr align="center">
                  <th>No.</th>
                  <th>Rincian</th>
                  <th>Jumlah (Rp)</th>
                  <th>Total (Rp)</th>
                </tr>
                </thead>
                
                <tbody>
                <?php $no=1; ?>
                <td></td><td colspan="3">Pemasukan</td>
                <?php foreach ($keuangan as $uang): ?>
                <tr>
                    <td align="center"><?php echo $no++; ?></td>
                    <td><?= $uang['keterangan']; ?></td>
                    <td>Rp <?= number_format(floatval($uang['masuk'])); ?>,-</td>
                    <td></td>
                </tr>
                <?php endforeach; ?>
                <td></td><td colspan="2">Jumlah Pemasukan</td><td><b>Rp <?= number_format(floatval($uang['masuk'])); ?>,-</b></td>
                </tbody>
                <tbody>
                <?php $no=1; ?>
                <td></td><td colspan="3">Pengeluaran</td>
                <?php foreach ($keuangan0 as $uang): ?>
                <tr>
                    <td align="center"><?php echo $no++; ?></td>
                    <td><?= $uang['keterangan']; ?></td>
                    <td>Rp <?= number_format(floatval($uang['keluar'])); ?>,-</td>
                    <td></td>
                </tr>
                    <?php endforeach; ?>
                    <td></td><td colspan="2">Jumlah Pengeluaran</td><td><b>Rp <?= number_format(floatval($uang['keluar'])); ?>,-</b></td>
                </tr>
                <td></td><td colspan="2"><b>Jumlah Saldo</b></td><td><b>Rp <?= number_format(floatval($masuk['masuk']-$keluar['keluar']));?>,-</b></td>
                </tbody>
              </table>
							
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
