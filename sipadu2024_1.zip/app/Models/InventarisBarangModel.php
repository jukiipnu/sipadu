<?php

namespace App\Models;

use CodeIgniter\Model;

class InventarisBarangModel extends Model
{
    protected $table = 'inventaris_barang';
    protected $primaryKey = 'id_inventaris_barang';
    protected $allowedFields = ['id_pimpinan', 'kategori_data', 'index_barang', 'nama_barang', 'jumlah', 'asal_barang', 'harga_satuan', 'tanggal_dipakai', 'tanggal_tidak_dipakai', 'keterangan'];
}