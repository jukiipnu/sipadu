<?php

namespace App\Models;

use CodeIgniter\Model;

class PengaturanPimpinanModel extends Model
{
    protected $table = 'pengaturan_pimpinan';
    protected $primaryKey = 'id_pengaturan_pimpinan';
    protected $allowedFields = ['id_pimpinan', 'kop_surat', 'nama_ketua', 'nia_ketua', 'ttd_ketua', 'nama_sekretaris', 'nia_sekretaris', 'ttd_sekretaris', 'stempel', 'masa_khidmat', 'no_sp', 'file_sp', 'tingkatan', 'tgl_sp', 'email', 'website', 'facebook', 'instagram', 'twitter', 'no_hp', 'alamat_sekretariat'];
}