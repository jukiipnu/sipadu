<?php

namespace App\Models;

use CodeIgniter\Model;

class DataPendaftarModel extends Model
{
    protected $table = 'data_pendaftar';
    protected $primaryKey = 'id_peserta';
    protected $allowedFields = ['kategori_data', 'id_daftar_kegiatan', 'id_anggota', 'status'];
}