<?php

namespace App\Models;

use CodeIgniter\Model;

class KaderisasiModel extends Model
{
    protected $table = 'kaderisasi';
    protected $primaryKey = 'id_kaderisasi';
    protected $allowedFields = ['kategori_kaderisasi', 'id_pimpinan', 'penyelenggara', 'waktu_pelaksana', 'tempat_pelaksana', 'nama_panitia', 'ttd_panitia'];
}