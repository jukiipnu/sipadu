<?php

namespace App\Models;

use CodeIgniter\Model;

class KeuanganModel extends Model
{
    protected $table = 'keuangan';
    protected $primaryKey = 'id_keuangan';
    protected $allowedFields = ['id_pimpinan', 'kategori_data', 'jenis_transaksi', 'masuk', 'keluar', 'tanggal_transaksi', 'keterangan'];
}