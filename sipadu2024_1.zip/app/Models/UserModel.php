<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'admin_users';
    protected $primaryKey = 'id_user';
    protected $allowedFields = ['id_pimpinan', 'username', 'password', 'kategori_user', 'tingkatan', 'sekretariat', 'email', 'no_telpon', 'nama_lengkap', 'level', 'aktif', 'foto', 'ket', 'pac'];
    public function updateLastLoginAndIP($userId, $ipAddress)
    {
        // Memperbarui waktu login terakhir dan IP pengguna
        $this->set([
            'last_login' => date('Y-m-d H:i:s'),
            'ip_address' => $ipAddress
        ])->where('id_user', $userId)->update();
    }
}