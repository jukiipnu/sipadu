<?php

namespace App\Models;

use CodeIgniter\Model;

class SuratMasukModel extends Model
{
    protected $table = 'surat_masuk';
    protected $primaryKey = 'id_surat_masuk';
    protected $allowedFields = ['id_pimpinan', 'kategori_data', 'nomor_surat_masuk', 'tanggal_surat_diterima', 'pengirim', 'perihal', 'isi', 'tanggal_surat', 'tembusan', 'catatan_disposisi', 'keterangan', 'file_surat'];
}