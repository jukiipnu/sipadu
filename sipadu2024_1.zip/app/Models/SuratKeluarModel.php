<?php

namespace App\Models;

use CodeIgniter\Model;

class SuratKeluarModel extends Model
{
    protected $table = 'surat_keluar';
    protected $primaryKey = 'id_surat_keluar';
    protected $allowedFields = ['id_pimpinan', 'kategori_data', 'index_surat', 'nomor_surat', 'perihal', 'lampiran', 'tujuan_surat', 'uraian_singkat', 'isi_surat', 'tanggal_surat', 'sifat_surat', 'keterangan', 'file_surat'];
}