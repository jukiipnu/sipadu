<?php

namespace App\Models;

use CodeIgniter\Model;

class PerpustakaanModel extends Model
{
    protected $table = 'perpustakaan';
    protected $primaryKey = 'id_materi';
    protected $allowedFields = ['nama_materi', 'kategori_data', 'materi', 'kategori_materi'];
}