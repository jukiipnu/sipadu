<?php

namespace App\Models;

use CodeIgniter\Model;

class PimpinanRkModel extends Model
{
    protected $table = 'pimpinan_rk';
    protected $primaryKey = 'id_pimpinan_rk';
    protected $allowedFields = ['id_pimpinan_ac', 'id_pimpinan', 'pimpinan_rk', 'kategori_data', 'kd_pimpinan_rk', 'nama_pimpinan_rk', 'status_aktif'];

    // public function getByPimpinanRkId($id)
    // {
    //     return $this->where('id_pimpinan_rk', $id)->first();
    // }
}