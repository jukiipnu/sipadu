<?php

namespace App\Models;

use CodeIgniter\Model;

class KategoriDataModel extends Model
{
    protected $table = 'kategori_data';
    protected $primaryKey = 'id_kategori_data';
    protected $allowedFields = ['kategori', 'kode_kategori'];
    public function updateLastLoginAndIP($userId, $ipAddress)
    {
        // Memperbarui waktu login terakhir dan IP pengguna
        $this->set([
            'last_login' => date('Y-m-d H:i:s'),
            'ip_address' => $ipAddress
        ])->where('id_user', $userId)->update();
    }
}