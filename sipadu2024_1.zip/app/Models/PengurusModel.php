<?php

namespace App\Models;

use CodeIgniter\Model;

class PengurusModel extends Model
{
    protected $table = 'user_pengurus';
    protected $primaryKey = 'id_pengurus';
    protected $allowedFields = ['id_pimpinan', 'email', 'password', 'kategori_data', 'nama_bidang'];
    public function updateLastLoginAndIP($userId, $ipAddress)
    {
        // Memperbarui waktu login terakhir dan IP pengguna
        $this->set([
            'last_login' => date('Y-m-d H:i:s'),
            'ip_address' => $ipAddress
        ])->where('id_pengurus', $userId)->update();
    }
}