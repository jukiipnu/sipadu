<?php

namespace App\Models;

use CodeIgniter\Model;

class DaftarKegiatanModel extends Model
{
    protected $table = 'daftar_kegiatan';
    protected $primaryKey = 'id_daftar_kegiatan';
    protected $allowedFields = ['kategori_data', 'id_pimpinan', 'kategori_kegiatan', 'pelaksana_kegiatan', 'nama_kegiatan', 'hari', 'tanggal', 'waktu', 'tempat', 'informasi', 'browsur'];
}