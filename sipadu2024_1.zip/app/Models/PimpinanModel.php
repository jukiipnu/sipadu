<?php

namespace App\Models;

use CodeIgniter\Model;

class PimpinanModel extends Model
{
    protected $table = 'pimpinan';
    protected $primaryKey = 'id_pimpinan';
    protected $allowedFields = ['pimpinan', 'kategori_data', 'kd_pimpinan', 'nama_pimpinan'];
}