<?php

namespace App\Models;

use CodeIgniter\Model;

class PengaturanKtaModel extends Model
{
    protected $table = 'pengaturan_kta';
    protected $primaryKey = 'id';
    protected $allowedFields = ['nama_organisasi', 'alamt_sekretariat', 'nama_ketua', 'nia_ketua', 'nama_sekretaris', 'nia_sekretaris', 'stempel', 'tanda_tangan_ketua'];
}