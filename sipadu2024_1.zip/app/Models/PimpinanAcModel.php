<?php

namespace App\Models;

use CodeIgniter\Model;

class PimpinanAcModel extends Model
{
    protected $table = 'pimpinan_ac';
    protected $primaryKey = 'id_pimpinan_ac';
    protected $allowedFields = ['id_pimpinan', 'pimpinan_ac', 'kategori_data', 'kd_pimpinan_ac', 'nama_pimpinan_ac', 'status_aktif'];
}