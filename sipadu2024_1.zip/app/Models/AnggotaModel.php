<?php

namespace App\Models;

use CodeIgniter\Model;

class AnggotaModel extends Model
{
    protected $table = 'anggota';
    protected $primaryKey = 'id_anggota';
    protected $allowedFields = ['nia', 'nama', 'kategori_data', 'tempat_lahir', 'tanggal_lahir', 'nama_ayah', 'pekerjaan_ayah', 'penghasilan_ayah', 'nama_ibu', 'pekerjaan_ibu', 'penghasilan_ibu', 'jumlah_saudara', 'id_pw', 'id_pimpinan', 'id_pimpinan_ac', 'id_pimpinan_rk', 'aktif_kepengurusan', 'alamat_lengkap', 'rt', 'rw', 'kode_pos', 'pendidikan_terakhir', 'pendidikan_sd', 'pendidikan_smp', 'pendidikan_sma', 'pendidikan_pt', 'pendidikan_nonformal', 'pelatihan_formal', 'makesta', 'penyelenggara_makesta', 'waktu_makesta', 'tempat_makesta', 'lakmud', 'penyelenggara_lakmud', 'waktu_lakmud', 'tempat_lakmud', 'lakut', 'penyelenggara_lakut', 'waktu_lakut', 'tempat_lakut', 'pelatihan_nonformal', 'status_cbp', 'tanggal_masuk', 'email', 'no_hp', 'fb', 'ig', 'twitter', 'tempat_input_kta', 'tanggal_input_kta', 'foto', 'pekerjaan_usaha', 'penghasilan_pribadi', 'password', 'status_verifikasi', 'keterangan', 'program_studi_s1', 'pascasarjana', 'program_studi_s2', 'pengalaman_organisasi', 'nik', 'ktp', 'bakat', 'jabatan', 'status_alumni', 'minat_bakat', 'detail_minat', 'prestasi'];
    public function updateLastLoginAndIP($userId, $ipAddress)
    {
        // Memperbarui waktu login terakhir dan IP pengguna
        $this->set([
            'last_login' => date('Y-m-d H:i:s'),
            'ip_address' => $ipAddress
        ])->where('id_anggota', $userId)->update();
    }
}